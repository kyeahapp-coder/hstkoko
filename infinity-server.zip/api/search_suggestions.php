<?php
session_start();
require_once '../config/database.php';
require_once '../includes/security.php';

header('Content-Type: application/json');

if (!isset($_GET['q']) || strlen($_GET['q']) < 2) {
    echo json_encode([]);
    exit();
}

$query = sanitizeInput($_GET['q']);

try {
    $stmt = $conn->prepare("
        SELECT DISTINCT title 
        FROM images 
        WHERE status = 'approved' 
        AND (title LIKE ? OR tags LIKE ?) 
        ORDER BY title 
        LIMIT 10
    ");
    $searchTerm = '%' . $query . '%';
    $stmt->bind_param("ss", $searchTerm, $searchTerm);
    $stmt->execute();
    $result = $stmt->get_result();
    
    $suggestions = [];
    while ($row = $result->fetch_assoc()) {
        $suggestions[] = $row['title'];
    }
    
    echo json_encode($suggestions);
    
} catch (Exception $e) {
    error_log("Search suggestions error: " . $e->getMessage());
    echo json_encode([]);
}
?>
