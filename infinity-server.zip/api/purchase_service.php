<?php
require_once '../includes/functions.php';

if (!isLoggedIn()) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit();
}

$input = json_decode(file_get_contents('php://input'), true);

if (!$input || !isset($input['service_id']) || !isset($input['phone'])) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Invalid input']);
    exit();
}

$database = new Database();
$db = $database->getConnection();

try {
    $service_id = $input['service_id'];
    $phone = trim($input['phone']);
    $notes = trim($input['notes'] ?? '');
    $user_id = $_SESSION['user_id'];
    
    // Get service details
    $service_query = "SELECT * FROM services WHERE id = ? AND is_active = 1";
    $service_stmt = $db->prepare($service_query);
    $service_stmt->execute([$service_id]);
    $service = $service_stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$service) {
        echo json_encode(['success' => false, 'message' => 'Service not found']);
        exit();
    }
    
    // Create service order
    $order_uid = generateOrderUID();
    $currency = 'MMK'; // Default currency for services
    $total = $service['price_mmk'];
    
    $order_query = "INSERT INTO orders (user_id, order_uid, total_mmk, currency, payment_method, payment_status) 
                    VALUES (?, ?, ?, ?, 'pending', 'pending')";
    $order_stmt = $db->prepare($order_query);
    $order_stmt->execute([$user_id, $order_uid, $total, $currency]);
    $order_id = $db->lastInsertId();
    
    // Add service order details to a separate table
    $service_order_query = "INSERT INTO service_orders (order_id, service_id, phone_number, notes) 
                           VALUES (?, ?, ?, ?)";
    $service_order_stmt = $db->prepare($service_order_query);
    $service_order_stmt->execute([$order_id, $service_id, $phone, $notes]);
    
    // Add notification
    addNotification($user_id, 'ဝန်ဆောင်မှု အော်ဒါ', "ဝန်ဆောင်မှု {$service['service_name']} အတွက် အော်ဒါ {$order_uid} ကို ဖန်တီးပြီးပါပြီ။", 'info');
    
    echo json_encode([
        'success' => true,
        'order_id' => $order_id,
        'order_uid' => $order_uid,
        'total' => $total,
        'currency' => $currency
    ]);
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Database error']);
}
?>
