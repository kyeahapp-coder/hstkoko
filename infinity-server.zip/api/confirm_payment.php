<?php
session_start();
require_once '../config/database.php';
require_once '../includes/functions.php';
require_once '../includes/security.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit();
}

if (!isLoggedIn()) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Please login first']);
    exit();
}

$input = json_decode(file_get_contents('php://input'), true);

if (!isset($input['order_id']) || !is_numeric($input['order_id'])) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Invalid order ID']);
    exit();
}

$order_id = (int)$input['order_id'];
$user_id = $_SESSION['user_id'];

try {
    // Verify order belongs to user and is pending
    $stmt = $conn->prepare("SELECT id, status FROM orders WHERE id = ? AND user_id = ?");
    $stmt->bind_param("ii", $order_id, $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows === 0) {
        echo json_encode(['success' => false, 'message' => 'Order not found']);
        exit();
    }
    
    $order = $result->fetch_assoc();
    
    if ($order['status'] !== 'pending') {
        echo json_encode(['success' => false, 'message' => 'Order cannot be confirmed']);
        exit();
    }
    
    // Update order status to payment_submitted
    $stmt = $conn->prepare("UPDATE orders SET status = 'payment_submitted', payment_submitted_at = NOW() WHERE id = ?");
    $stmt->bind_param("i", $order_id);
    
    if ($stmt->execute()) {
        // Clear user's cart
        $stmt = $conn->prepare("DELETE FROM cart WHERE user_id = ?");
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        
        // Add notification for admin
        $stmt = $conn->prepare("INSERT INTO notifications (user_id, title, message, type, created_at) VALUES (0, 'Payment Submitted', 'Order #' + ? + ' payment has been submitted for review', 'info', NOW())");
        $stmt->bind_param("i", $order_id);
        $stmt->execute();
        
        echo json_encode([
            'success' => true,
            'message' => 'Payment confirmation submitted successfully'
        ]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to confirm payment']);
    }
    
} catch (Exception $e) {
    error_log("Confirm payment error: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'Server error']);
}
?>
