<?php
require_once '../includes/functions.php';
require_once '../includes/security.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit;
}

if (!isLoggedIn()) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Please login first']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);

if (!$input || !isset($input['payment_method']) || !isset($input['currency'])) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Invalid input']);
    exit;
}

$payment_method = Security::sanitizeInput($input['payment_method']);
$currency = Security::sanitizeInput($input['currency']);
$notes = Security::sanitizeInput($input['notes'] ?? '');

try {
    $database = new Database();
    $db = $database->getConnection();
    
    // Get cart items
    $cart_items = getCartItems();
    
    if (empty($cart_items)) {
        echo json_encode(['success' => false, 'message' => 'Cart is empty']);
        exit;
    }
    
    $db->beginTransaction();
    
    // Calculate totals
    $subtotal_mmk = 0;
    $subtotal_thb = 0;
    
    foreach ($cart_items as $item) {
        $subtotal_mmk += $item['price_mmk'] * $item['quantity'];
        $subtotal_thb += $item['price_thb'] * $item['quantity'];
    }
    
    $discount_percent = calculateDiscount(count($cart_items));
    $discount_mmk = $subtotal_mmk * ($discount_percent / 100);
    $discount_thb = $subtotal_thb * ($discount_percent / 100);
    
    $total_mmk = $subtotal_mmk - $discount_mmk;
    $total_thb = $subtotal_thb - $discount_thb;
    
    // Generate order ID
    $order_uid = generateOrderUID();
    
    // Create order
    $order_query = "INSERT INTO orders (user_id, order_uid, total_mmk, total_thb, currency, 
                    payment_method, subtotal_mmk, subtotal_thb, discount_amount_mmk, 
                    discount_amount_thb, notes, status) 
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending')";
    
    $order_stmt = $db->prepare($order_query);
    $order_stmt->execute([
        $_SESSION['user_id'],
        $order_uid,
        $total_mmk,
        $total_thb,
        $currency,
        $payment_method,
        $subtotal_mmk,
        $subtotal_thb,
        $discount_mmk,
        $discount_thb,
        $notes
    ]);
    
    $order_id = $db->lastInsertId();
    
    // Add order items
    $item_query = "INSERT INTO order_items (order_id, image_id, quantity, price_mmk, price_thb) 
                   VALUES (?, ?, ?, ?, ?)";
    $item_stmt = $db->prepare($item_query);
    
    foreach ($cart_items as $item) {
        $item_stmt->execute([
            $order_id,
            $item['image_id'],
            $item['quantity'],
            $item['price_mmk'],
            $item['price_thb']
        ]);
    }
    
    // Clear cart
    clearCart();
    
    // Add notification
    addNotification(
        $_SESSION['user_id'],
        'Order Created',
        "Your order #{$order_uid} has been created successfully.",
        'success',
        'order',
        $order_id
    );
    
    $db->commit();
    
    echo json_encode([
        'success' => true,
        'message' => 'Order created successfully',
        'order_id' => $order_id,
        'order_uid' => $order_uid,
        'total' => $currency === 'MMK' ? $total_mmk : $total_thb,
        'currency' => $currency
    ]);
    
} catch (Exception $e) {
    $db->rollBack();
    error_log("Create order error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Failed to create order']);
}
?>
