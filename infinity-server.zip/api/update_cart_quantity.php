<?php
session_start();
require_once '../config/database.php';
require_once '../includes/security.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit();
}

if (!isLoggedIn()) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Please login first']);
    exit();
}

$input = json_decode(file_get_contents('php://input'), true);

if (!isset($input['cart_id']) || !isset($input['quantity']) || 
    !is_numeric($input['cart_id']) || !is_numeric($input['quantity'])) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Invalid parameters']);
    exit();
}

$cart_id = (int)$input['cart_id'];
$quantity = (int)$input['quantity'];
$user_id = $_SESSION['user_id'];

if ($quantity < 1 || $quantity > 10) {
    echo json_encode(['success' => false, 'message' => 'Quantity must be between 1 and 10']);
    exit();
}

try {
    // Update quantity (only user's own items)
    $stmt = $conn->prepare("UPDATE cart SET quantity = ? WHERE id = ? AND user_id = ?");
    $stmt->bind_param("iii", $quantity, $cart_id, $user_id);
    
    if ($stmt->execute() && $stmt->affected_rows > 0) {
        // Get updated cart total
        $stmt = $conn->prepare("
            SELECT SUM(c.quantity * i.price) as total 
            FROM cart c 
            JOIN images i ON c.image_id = i.id 
            WHERE c.user_id = ?
        ");
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $total = $result->fetch_assoc()['total'] ?? 0;
        
        echo json_encode([
            'success' => true, 
            'message' => 'Quantity updated successfully',
            'total' => number_format($total, 2)
        ]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to update quantity']);
    }
    
} catch (Exception $e) {
    error_log("Update cart quantity error: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'Server error']);
}
?>
