<?php
session_start();
require_once '../config/database.php';
require_once '../includes/security.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit();
}

if (!isLoggedIn()) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Please login first']);
    exit();
}

$input = json_decode(file_get_contents('php://input'), true);

if (!isset($input['image_id']) || !is_numeric($input['image_id'])) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Invalid image ID']);
    exit();
}

$image_id = (int)$input['image_id'];
$user_id = $_SESSION['user_id'];

try {
    // Check if already in wishlist
    $stmt = $conn->prepare("SELECT id FROM wishlist WHERE user_id = ? AND image_id = ?");
    $stmt->bind_param("ii", $user_id, $image_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        // Remove from wishlist
        $stmt = $conn->prepare("DELETE FROM wishlist WHERE user_id = ? AND image_id = ?");
        $stmt->bind_param("ii", $user_id, $image_id);
        $stmt->execute();
        
        echo json_encode([
            'success' => true, 
            'message' => 'Removed from wishlist',
            'in_wishlist' => false
        ]);
    } else {
        // Add to wishlist
        $stmt = $conn->prepare("INSERT INTO wishlist (user_id, image_id, added_at) VALUES (?, ?, NOW())");
        $stmt->bind_param("ii", $user_id, $image_id);
        $stmt->execute();
        
        echo json_encode([
            'success' => true, 
            'message' => 'Added to wishlist',
            'in_wishlist' => true
        ]);
    }
    
} catch (Exception $e) {
    error_log("Toggle wishlist error: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'Server error']);
}
?>
