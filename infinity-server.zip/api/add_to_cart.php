<?php
session_start();
require_once '../config/database.php';
require_once '../includes/security.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit();
}

if (!isLoggedIn()) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Please login first']);
    exit();
}

$input = json_decode(file_get_contents('php://input'), true);

if (!isset($input['image_id']) || !is_numeric($input['image_id'])) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Invalid image ID']);
    exit();
}

$image_id = (int)$input['image_id'];
$user_id = $_SESSION['user_id'];

try {
    // Check if image exists and is approved
    $stmt = $conn->prepare("SELECT id, title, price FROM images WHERE id = ? AND status = 'approved'");
    $stmt->bind_param("i", $image_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows === 0) {
        echo json_encode(['success' => false, 'message' => 'Image not found or not available']);
        exit();
    }
    
    $image = $result->fetch_assoc();
    
    // Check if already in cart
    $stmt = $conn->prepare("SELECT id FROM cart WHERE user_id = ? AND image_id = ?");
    $stmt->bind_param("ii", $user_id, $image_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        echo json_encode(['success' => false, 'message' => 'Item already in cart']);
        exit();
    }
    
    // Add to cart
    $stmt = $conn->prepare("INSERT INTO cart (user_id, image_id, quantity, added_at) VALUES (?, ?, 1, NOW())");
    $stmt->bind_param("ii", $user_id, $image_id);
    
    if ($stmt->execute()) {
        // Get cart count
        $stmt = $conn->prepare("SELECT COUNT(*) as count FROM cart WHERE user_id = ?");
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $cart_count = $result->fetch_assoc()['count'];
        
        echo json_encode([
            'success' => true, 
            'message' => 'Added to cart successfully',
            'cart_count' => $cart_count
        ]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to add to cart']);
    }
    
} catch (Exception $e) {
    error_log("Add to cart error: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'Server error']);
}
?>
