<?php
require_once '../includes/functions.php';

if (!isLoggedIn()) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit();
}

$input = json_decode(file_get_contents('php://input'), true);

if (!$input || !isset($input['notification_ids']) || !is_array($input['notification_ids'])) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Invalid input']);
    exit();
}

$database = new Database();
$db = $database->getConnection();

try {
    $user_id = $_SESSION['user_id'];
    $notification_ids = $input['notification_ids'];
    
    if (!empty($notification_ids)) {
        $placeholders = str_repeat('?,', count($notification_ids) - 1) . '?';
        $query = "UPDATE notifications SET is_read = 1 WHERE id IN ($placeholders) AND user_id = ?";
        $params = array_merge($notification_ids, [$user_id]);
        
        $stmt = $db->prepare($query);
        $stmt->execute($params);
    }
    
    echo json_encode(['success' => true]);
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Database error']);
}
?>
