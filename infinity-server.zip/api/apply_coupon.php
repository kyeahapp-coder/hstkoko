<?php
session_start();
require_once '../config/database.php';
require_once '../includes/functions.php';
require_once '../includes/security.php';

header('Content-Type: application/json');

if (!isLoggedIn()) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);
$coupon_code = Security::sanitizeInput($input['coupon_code'] ?? '');
$cart_total = floatval($input['cart_total'] ?? 0);

if (empty($coupon_code) || $cart_total <= 0) {
    echo json_encode(['success' => false, 'message' => 'Invalid coupon code or cart total']);
    exit;
}

try {
    // Check if coupon exists and is valid
    $stmt = $pdo->prepare("
        SELECT * FROM coupons 
        WHERE code = ? AND is_active = 1 
        AND valid_from <= NOW() AND valid_until >= NOW()
        AND (usage_limit IS NULL OR used_count < usage_limit)
    ");
    $stmt->execute([$coupon_code]);
    $coupon = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$coupon) {
        echo json_encode(['success' => false, 'message' => 'Invalid or expired coupon']);
        exit;
    }
    
    // Check minimum amount
    if ($cart_total < $coupon['minimum_amount']) {
        echo json_encode([
            'success' => false, 
            'message' => 'Minimum order amount of ' . number_format($coupon['minimum_amount']) . ' MMK required'
        ]);
        exit;
    }
    
    // Check if user already used this coupon
    $stmt = $pdo->prepare("
        SELECT COUNT(*) FROM coupon_usage 
        WHERE coupon_id = ? AND user_id = ?
    ");
    $stmt->execute([$coupon['id'], $_SESSION['user_id']]);
    $usage_count = $stmt->fetchColumn();
    
    if ($usage_count > 0) {
        echo json_encode(['success' => false, 'message' => 'You have already used this coupon']);
        exit;
    }
    
    // Calculate discount
    $discount_amount = 0;
    if ($coupon['type'] === 'percentage') {
        $discount_amount = ($cart_total * $coupon['value']) / 100;
    } else {
        $discount_amount = $coupon['value'];
    }
    
    // Ensure discount doesn't exceed cart total
    $discount_amount = min($discount_amount, $cart_total);
    
    $new_total = $cart_total - $discount_amount;
    
    // Store coupon in session for checkout
    $_SESSION['applied_coupon'] = [
        'id' => $coupon['id'],
        'code' => $coupon['code'],
        'discount_amount' => $discount_amount
    ];
    
    echo json_encode([
        'success' => true,
        'message' => 'Coupon applied successfully',
        'discount_amount' => $discount_amount,
        'new_total' => $new_total,
        'coupon_code' => $coupon['code']
    ]);
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Server error']);
}
?>
