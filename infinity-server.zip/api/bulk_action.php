<?php
require_once '../includes/functions.php';

if (!isAdmin()) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit();
}

$input = json_decode(file_get_contents('php://input'), true);

if (!$input || !isset($input['action']) || !isset($input['items']) || !is_array($input['items'])) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Invalid input']);
    exit();
}

$database = new Database();
$db = $database->getConnection();

try {
    $action = $input['action'];
    $items = $input['items'];
    
    if (empty($items)) {
        echo json_encode(['success' => false, 'message' => 'No items selected']);
        exit();
    }
    
    $placeholders = str_repeat('?,', count($items) - 1) . '?';
    
    switch ($action) {
        case 'approve_orders':
            $query = "UPDATE orders SET admin_approved = 1 WHERE id IN ($placeholders) AND payment_status = 'paid'";
            $stmt = $db->prepare($query);
            $stmt->execute($items);
            
            // Send notifications to users
            $order_query = "SELECT o.user_id, o.order_uid FROM orders WHERE id IN ($placeholders)";
            $order_stmt = $db->prepare($order_query);
            $order_stmt->execute($items);
            $orders = $order_stmt->fetchAll(PDO::FETCH_ASSOC);
            
            foreach ($orders as $order) {
                addNotification($order['user_id'], 'အော်ဒါ အတည်ပြုပြီး', "အော်ဒါ {$order['order_uid']} ကို အတည်ပြုပြီးပါပြီ။", 'success');
            }
            break;
            
        case 'delete_images':
            // Get image paths first
            $image_query = "SELECT original_path, watermark_path FROM images WHERE id IN ($placeholders)";
            $image_stmt = $db->prepare($image_query);
            $image_stmt->execute($items);
            $images = $image_stmt->fetchAll(PDO::FETCH_ASSOC);
            
            // Delete files
            foreach ($images as $image) {
                if (file_exists($image['original_path'])) unlink($image['original_path']);
                if (file_exists($image['watermark_path'])) unlink($image['watermark_path']);
            }
            
            // Delete from database
            $query = "DELETE FROM images WHERE id IN ($placeholders)";
            $stmt = $db->prepare($query);
            $stmt->execute($items);
            break;
            
        case 'ban_users':
            $query = "UPDATE users SET is_banned = 1 WHERE id IN ($placeholders)";
            $stmt = $db->prepare($query);
            $stmt->execute($items);
            break;
            
        case 'unban_users':
            $query = "UPDATE users SET is_banned = 0 WHERE id IN ($placeholders)";
            $stmt = $db->prepare($query);
            $stmt->execute($items);
            break;
            
        case 'activate_services':
            $query = "UPDATE services SET is_active = 1 WHERE id IN ($placeholders)";
            $stmt = $db->prepare($query);
            $stmt->execute($items);
            break;
            
        case 'deactivate_services':
            $query = "UPDATE services SET is_active = 0 WHERE id IN ($placeholders)";
            $stmt = $db->prepare($query);
            $stmt->execute($items);
            break;
            
        default:
            echo json_encode(['success' => false, 'message' => 'Invalid action']);
            exit();
    }
    
    echo json_encode(['success' => true]);
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Database error']);
}
?>
