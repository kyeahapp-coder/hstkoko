<?php
session_start();
require_once '../includes/functions.php';
require_once '../includes/security.php';
require_once '../includes/image_processor.php';
require_once '../config/config.php';
require_once '../includes/logger.php';

header('Content-Type: application/json');

if (!isLoggedIn()) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit;
}

// Validate CSRF token
if (!Security::checkCSRF($_POST['csrf_token'] ?? '')) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Invalid CSRF token']);
    exit;
}

// Check rate limiting
if (!Security::rateLimitCheck('upload_' . $_SESSION['user_id'], 10, 3600)) {
    http_response_code(429);
    echo json_encode(['success' => false, 'message' => 'Too many uploads. Please try again later.']);
    exit;
}

try {
    if (!isset($_FILES['image']) || $_FILES['image']['error'] !== UPLOAD_ERR_OK) {
        throw new Exception('No file uploaded or upload error');
    }
    
    // Validate file
    $validation_errors = Security::validateFileUpload($_FILES['image']);
    if (!empty($validation_errors)) {
        throw new Exception(implode(', ', $validation_errors));
    }
    
    // Sanitize input
    $title = Security::sanitizeInput($_POST['title'] ?? '');
    $description = Security::sanitizeInput($_POST['description'] ?? '');
    $category = Security::sanitizeInput($_POST['category'] ?? '');
    $tags = Security::sanitizeInput($_POST['tags'] ?? '');
    $price = floatval($_POST['price'] ?? 0);
    $is_free = isset($_POST['is_free']) ? 1 : 0;
    
    if (empty($title) || empty($category)) {
        throw new Exception('Title and category are required');
    }
    
    if (!$is_free && $price <= 0) {
        throw new Exception('Price must be greater than 0 for paid images');
    }
    
    // Generate unique filename
    $file_extension = strtolower(pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION));
    $filename = uniqid() . '_' . time() . '.' . $file_extension;
    $upload_path = UPLOAD_PATH . $filename;
    $thumb_path = THUMB_PATH . $filename;
    
    // Create directories if they don't exist
    if (!file_exists(UPLOAD_PATH)) {
        mkdir(UPLOAD_PATH, 0755, true);
    }
    if (!file_exists(THUMB_PATH)) {
        mkdir(THUMB_PATH, 0755, true);
    }
    
    // Move uploaded file
    if (!move_uploaded_file($_FILES['image']['tmp_name'], $upload_path)) {
        throw new Exception('Failed to save uploaded file');
    }
    
    // Create thumbnail
    if (!ImageProcessor::createThumbnail($upload_path, $thumb_path)) {
        Logger::warning('Failed to create thumbnail', ['file' => $filename]);
    }
    
    // Get image dimensions
    $image_info = getimagesize($upload_path);
    $width = $image_info[0] ?? 0;
    $height = $image_info[1] ?? 0;
    $file_size = filesize($upload_path);
    
    // Insert into database
    $database = new Database();
    $db = $database->getConnection();
    
    $stmt = $db->prepare("
        INSERT INTO images (title, description, filename, category, tags, price, is_free, 
                           width, height, file_size, uploaded_by, status) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending')
    ");
    
    $stmt->execute([
        $title, $description, $filename, $category, $tags, 
        $is_free ? 0 : $price, $is_free, $width, $height, 
        $file_size, $_SESSION['user_id']
    ]);
    
    $image_id = $db->lastInsertId();
    
    // Log activity
    Logger::activity($_SESSION['user_id'], 'image_upload', [
        'image_id' => $image_id,
        'filename' => $filename,
        'title' => $title
    ]);
    
    echo json_encode([
        'success' => true,
        'message' => 'Image uploaded successfully. It will be reviewed before being published.',
        'image_id' => $image_id
    ]);
    
} catch (Exception $e) {
    Logger::error('Image upload failed', [
        'user_id' => $_SESSION['user_id'],
        'error' => $e->getMessage()
    ]);
    
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
}
?>
