<?php
require_once 'includes/functions.php';

$database = new Database();
$db = $database->getConnection();

$search_query = isset($_GET['q']) ? trim($_GET['q']) : '';
$category = isset($_GET['category']) ? $_GET['category'] : 'all';
$sort = isset($_GET['sort']) ? $_GET['sort'] : 'newest';

$results = [];
$total_results = 0;

if (!empty($search_query)) {
    // Build search query
    $where_conditions = [];
    $params = [];
    
    // Search in title and description
    $where_conditions[] = "(title LIKE ? OR description LIKE ?)";
    $params[] = "%$search_query%";
    $params[] = "%$search_query%";
    
    // Category filter
    if ($category !== 'all') {
        // This would be implemented if you have categories
    }
    
    $where_clause = implode(' AND ', $where_conditions);
    
    // Sort options
    $order_clause = '';
    switch ($sort) {
        case 'newest':
            $order_clause = 'ORDER BY created_at DESC';
            break;
        case 'oldest':
            $order_clause = 'ORDER BY created_at ASC';
            break;
        case 'price_low':
            $order_clause = 'ORDER BY price_mmk ASC';
            break;
        case 'price_high':
            $order_clause = 'ORDER BY price_mmk DESC';
            break;
        case 'popular':
            $order_clause = 'ORDER BY views DESC';
            break;
    }
    
    // Get results
    $query = "SELECT * FROM images WHERE $where_clause $order_clause";
    $stmt = $db->prepare($query);
    $stmt->execute($params);
    $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    $total_results = count($results);
}
?>

<!DOCTYPE html>
<html lang="my">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ရှာဖွေမှု - Infinity Server</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/additional.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body data-user-logged-in="<?php echo isLoggedIn() ? 'true' : 'false'; ?>">
    <header class="header">
        <div class="container">
            <div class="nav-brand">
                <img src="<?php echo getSetting('site_logo'); ?>" alt="Logo" class="logo">
                <h1>Infinity Server</h1>
            </div>
            <nav class="nav-menu">
                <a href="index.php">ပင်မစာမျက်နှာ</a>
                <a href="services.php">ဝန်ဆောင်မှုများ</a>
                <a href="cart.php" class="cart-link">
                    <i class="fas fa-shopping-cart"></i>
                    <span id="cart-count">0</span>
                </a>
                <?php if (isLoggedIn()): ?>
                    <a href="profile.php">ကိုယ်ရေးအချက်အလက်</a>
                    <a href="logout.php">ထွက်ရန်</a>
                <?php else: ?>
                    <a href="login.php">ဝင်ရန်</a>
                    <a href="register.php">စာရင်းသွင်းရန်</a>
                <?php endif; ?>
            </nav>
        </div>
    </header>

    <main class="main-content">
        <div class="container">
            <div class="search-container">
                <h2><i class="fas fa-search"></i> ရှာဖွေမှု</h2>
                
                <!-- Search Form -->
                <form method="GET" class="search-form">
                    <div class="search-input-group">
                        <input type="text" name="q" value="<?php echo htmlspecialchars($search_query); ?>" 
                               placeholder="ဓာတ်ပုံများကို ရှာဖွေပါ..." class="search-input">
                        <button type="submit" class="search-btn">
                            <i class="fas fa-search"></i>
                        </button>
                    </div>
                    
                    <div class="search-filters">
                        <select name="category" class="filter-select">
                            <option value="all" <?php echo $category === 'all' ? 'selected' : ''; ?>>အားလုံး</option>
                            <option value="nature" <?php echo $category === 'nature' ? 'selected' : ''; ?>>သဘာဝ</option>
                            <option value="city" <?php echo $category === 'city' ? 'selected' : ''; ?>>မြို့ပြ</option>
                            <option value="portrait" <?php echo $category === 'portrait' ? 'selected' : ''; ?>>ပုံတူ</option>
                            <option value="abstract" <?php echo $category === 'abstract' ? 'selected' : ''; ?>>အနုပညာ</option>
                        </select>
                        
                        <select name="sort" class="filter-select">
                            <option value="newest" <?php echo $sort === 'newest' ? 'selected' : ''; ?>>အသစ်ဆုံး</option>
                            <option value="oldest" <?php echo $sort === 'oldest' ? 'selected' : ''; ?>>အဟောင်းဆုံး</option>
                            <option value="price_low" <?php echo $sort === 'price_low' ? 'selected' : ''; ?>>စျေးနှုန်း နည်း</option>
                            <option value="price_high" <?php echo $sort === 'price_high' ? 'selected' : ''; ?>>စျေးနှုန်း မြင့်</option>
                            <option value="popular" <?php echo $sort === 'popular' ? 'selected' : ''; ?>>လူကြိုက်များ</option>
                        </select>
                    </div>
                </form>
                
                <!-- Search Results -->
                <?php if (!empty($search_query)): ?>
                    <div class="search-results-header">
                        <h3>"<?php echo htmlspecialchars($search_query); ?>" အတွက် ရလဒ် <?php echo $total_results; ?> ခု</h3>
                    </div>
                    
                    <?php if (!empty($results)): ?>
                        <div class="currency-selector">
                            <button class="currency-btn active" data-currency="MMK">မြန်မာကျပ်</button>
                            <button class="currency-btn" data-currency="THB">ထိုင်းဘတ်</button>
                        </div>
                        
                        <div class="image-grid">
                            <?php foreach ($results as $image): ?>
                                <div class="image-card" data-image-id="<?php echo $image['id']; ?>">
                                    <div class="image-container">
                                        <img src="<?php echo $image['watermark_path']; ?>" alt="<?php echo htmlspecialchars($image['title']); ?>" class="watermarked-image">
                                        <div class="image-overlay">
                                            <button class="btn-primary add-to-cart" data-image-id="<?php echo $image['id']; ?>">
                                                <i class="fas fa-cart-plus"></i> ခြင်းတောင်းထည့်ရန်
                                            </button>
                                        </div>
                                    </div>
                                    <div class="image-info">
                                        <h3><?php echo htmlspecialchars($image['title']); ?></h3>
                                        <p class="image-description"><?php echo htmlspecialchars($image['description']); ?></p>
                                        <div class="price-info">
                                            <span class="price mmk-price"><?php echo formatCurrency($image['price_mmk'], 'MMK'); ?></span>
                                            <span class="price thb-price" style="display: none;"><?php echo formatCurrency($image['price_thb'], 'THB'); ?></span>
                                        </div>
                                        <div class="image-stats">
                                            <span><i class="fas fa-eye"></i> <?php echo $image['views']; ?></span>
                                            <span><i class="fas fa-download"></i> <?php echo $image['downloads']; ?></span>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php else: ?>
                        <div class="no-results">
                            <i class="fas fa-search"></i>
                            <h3>ရလဒ်မရှိပါ</h3>
                            <p>သင်ရှာဖွေသော "<?php echo htmlspecialchars($search_query); ?>" နှင့် ကိုက်ညီသော ဓာတ်ပုံများ မတွေ့ရှိပါ။</p>
                            <p>အခြားစကားလုံးများဖြင့် ပြန်လည်ရှာဖွေကြည့်ပါ။</p>
                        </div>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
        </div>
    </main>

    <footer class="footer">
        <div class="container">
            <p>&copy; 2024 Infinity Server. All rights reserved.</p>
        </div>
    </footer>

    <script src="assets/js/main.js"></script>
    <script src="assets/js/notifications.js"></script>
</body>
</html>
