<?php
require_once '../includes/functions.php';

if (!isAdmin()) {
    redirect('../login.php?admin=1');
}

$order_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if (!$order_id) {
    redirect('orders.php');
}

$database = new Database();
$db = $database->getConnection();

// Get order details
$order_query = "SELECT o.*, u.username, u.email, u.phone FROM orders o 
                JOIN users u ON o.user_id = u.id 
                WHERE o.id = ?";
$order_stmt = $db->prepare($order_query);
$order_stmt->execute([$order_id]);
$order = $order_stmt->fetch(PDO::FETCH_ASSOC);

if (!$order) {
    redirect('orders.php');
}

// Get order items (images)
$items_query = "SELECT oi.*, i.title, i.watermark_path, i.original_path 
                FROM order_items oi 
                JOIN images i ON oi.image_id = i.id 
                WHERE oi.order_id = ?";
$items_stmt = $db->prepare($items_query);
$items_stmt->execute([$order_id]);
$order_items = $items_stmt->fetchAll(PDO::FETCH_ASSOC);

// Check if it's a service order
$service_query = "SELECT so.*, s.service_name, s.service_type 
                  FROM service_orders so 
                  JOIN services s ON so.service_id = s.id 
                  WHERE so.order_id = ?";
$service_stmt = $db->prepare($service_query);
$service_stmt->execute([$order_id]);
$service_order = $service_stmt->fetch(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="my">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>အော်ဒါအသေးစိတ် - Admin Panel</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/admin.css">
    <link rel="stylesheet" href="../assets/css/additional.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body>
    <div class="admin-layout">
        <aside class="admin-sidebar">
            <div class="admin-brand">
                <h2><i class="fas fa-cog"></i> Admin Panel</h2>
            </div>
            <nav class="admin-nav">
                <a href="index.php"><i class="fas fa-dashboard"></i> Dashboard</a>
                <a href="images.php"><i class="fas fa-images"></i> ဓာတ်ပုံများ</a>
                <a href="orders.php" class="active"><i class="fas fa-shopping-bag"></i> အော်ဒါများ</a>
                <a href="users.php"><i class="fas fa-users"></i> အသုံးပြုသူများ</a>
                <a href="services.php"><i class="fas fa-concierge-bell"></i> ဝန်ဆောင်မှုများ</a>
                <a href="settings.php"><i class="fas fa-cog"></i> ဆက်တင်များ</a>
                <a href="../logout.php"><i class="fas fa-sign-out-alt"></i> ထွက်ရန်</a>
            </nav>
        </aside>
        
        <main class="admin-main">
            <header class="admin-header">
                <h1>အော်ဒါအသေးစိတ်</h1>
                <a href="orders.php" class="btn-back">
                    <i class="fas fa-arrow-left"></i> အော်ဒါများသို့ ပြန်သွားရန်
                </a>
            </header>
            
            <div class="admin-content">
                <div class="order-details-container">
                    <!-- Order Summary -->
                    <div class="order-info-card">
                        <div class="order-summary">
                            <h3>အော်ဒါ: <?php echo $order['order_uid']; ?></h3>
                            <div class="order-meta">
                                <div class="meta-item">
                                    <span class="label">အသုံးပြုသူ:</span>
                                    <span class="value"><?php echo htmlspecialchars($order['username']); ?></span>
                                </div>
                                <div class="meta-item">
                                    <span class="label">အီးမေးလ်:</span>
                                    <span class="value"><?php echo htmlspecialchars($order['email']); ?></span>
                                </div>
                                <div class="meta-item">
                                    <span class="label">ဖုန်းနံပါတ်:</span>
                                    <span class="value"><?php echo htmlspecialchars($order['phone'] ?: 'မရှိ'); ?></span>
                                </div>
                                <div class="meta-item">
                                    <span class="label">ရက်စွဲ:</span>
                                    <span class="value"><?php echo date('Y-m-d H:i', strtotime($order['created_at'])); ?></span>
                                </div>
                                <div class="meta-item">
                                    <span class="label">အခြေအနေ:</span>
                                    <span class="status-badge <?php echo $order['admin_approved'] ? 'approved' : ($order['payment_status'] === 'pending' ? 'pending' : 'paid'); ?>">
                                        <?php 
                                        if ($order['admin_approved']) {
                                            echo 'အတည်ပြုပြီး';
                                        } elseif ($order['payment_status'] === 'pending') {
                                            echo 'စောင့်ဆိုင်းနေသည်';
                                        } else {
                                            echo 'ငွေပေးချေပြီး';
                                        }
                                        ?>
                                    </span>
                                </div>
                                <div class="meta-item">
                                    <span class="label">ငွေပေးချေမှုနည်းလမ်း:</span>
                                    <span class="value"><?php echo ucfirst($order['payment_method']); ?></span>
                                </div>
                                <div class="meta-item">
                                    <span class="label">စုစုပေါင်း:</span>
                                    <span class="value total-amount">
                                        <?php 
                                        if ($order['currency'] === 'MMK') {
                                            echo formatCurrency($order['total_mmk'], 'MMK');
                                        } else {
                                            echo formatCurrency($order['total_thb'], 'THB');
                                        }
                                        ?>
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <?php if ($service_order): ?>
                        <!-- Service Order Details -->
                        <div class="service-details-card">
                            <h3><i class="fas fa-concierge-bell"></i> ဝန်ဆောင်မှုအသေးစိတ်</h3>
                            <div class="service-info">
                                <div class="service-item">
                                    <span class="label">ဝန်ဆောင်မှု:</span>
                                    <span class="value"><?php echo htmlspecialchars($service_order['service_name']); ?></span>
                                </div>
                                <div class="service-item">
                                    <span class="label">အမျိုးအစား:</span>
                                    <span class="value"><?php echo htmlspecialchars($service_order['service_type']); ?></span>
                                </div>
                                <div class="service-item">
                                    <span class="label">ဖုန်းနံပါတ်/Game ID:</span>
                                    <span class="value"><?php echo htmlspecialchars($service_order['phone_number']); ?></span>
                                </div>
                                <?php if ($service_order['notes']): ?>
                                    <div class="service-item">
                                        <span class="label">မှတ်ချက်:</span>
                                        <span class="value"><?php echo htmlspecialchars($service_order['notes']); ?></span>
                                    </div>
                                <?php endif; ?>
                                <div class="service-item">
                                    <span class="label">အခြေအနေ:</span>
                                    <span class="value">
                                        <span class="status-badge <?php echo $service_order['status']; ?>">
                                            <?php echo ucfirst($service_order['status']); ?>
                                        </span>
                                    </span>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>
                    
                    <?php if (!empty($order_items)): ?>
                        <!-- Image Order Details -->
                        <div class="items-details-card">
                            <h3><i class="fas fa-images"></i> ဓာတ်ပုံများ (<?php echo count($order_items); ?> ခု)</h3>
                            <div class="order-items-grid">
                                <?php foreach ($order_items as $item): ?>
                                    <div class="order-item-card">
                                        <img src="../<?php echo $item['watermark_path']; ?>" alt="<?php echo htmlspecialchars($item['title']); ?>">
                                        <div class="item-info">
                                            <h4><?php echo htmlspecialchars($item['title']); ?></h4>
                                            <p class="item-price">
                                                <?php echo formatCurrency($item['price'], $item['currency']); ?>
                                            </p>
                                            <div class="item-actions">
                                                <a href="../<?php echo $item['original_path']; ?>" target="_blank" class="btn-view">
                                                    <i class="fas fa-eye"></i> မူရင်းကြည့်ရန်
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    <?php endif; ?>
                    
                    <!-- Admin Actions -->
                    <div class="admin-actions-card">
                        <h3><i class="fas fa-tools"></i> Admin လုပ်ဆောင်ချက်များ</h3>
                        <div class="admin-actions">
                            <?php if (!$order['admin_approved'] && $order['payment_status'] === 'paid'): ?>
                                <form method="POST" action="orders.php" style="display: inline;">
                                    <input type="hidden" name="order_id" value="<?php echo $order['id']; ?>">
                                    <button type="submit" name="approve_order" class="btn-approve" onclick="return confirm('ဤအော်ဒါကို အတည်ပြုမှာ သေချာပါသလား?')">
                                        <i class="fas fa-check"></i> အော်ဒါ အတည်ပြုရန်
                                    </button>
                                </form>
                            <?php endif; ?>
                            
                            <button class="btn-primary" onclick="sendNotificationToUser(<?php echo $order['user_id']; ?>)">
                                <i class="fas fa-bell"></i> အသိပေးချက် ပို့ရန်
                            </button>
                            
                            <button class="btn-secondary" onclick="window.print()">
                                <i class="fas fa-print"></i> ပရင့်ထုတ်ရန်
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>

    <!-- Notification Modal -->
    <div id="notification-modal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="closeNotificationModal()">&times;</span>
            <h3>အသိပေးချက် ပို့ရန်</h3>
            <form id="notification-form">
                <div class="form-group">
                    <label for="notification-title">ခေါင်းစဉ်:</label>
                    <input type="text" id="notification-title" class="form-control" required>
                </div>
                <div class="form-group">
                    <label for="notification-message">မက်ဆေ့ချ်:</label>
                    <textarea id="notification-message" class="form-control" rows="4" required></textarea>
                </div>
                <div class="form-group">
                    <label for="notification-type">အမျိုးအစား:</label>
                    <select id="notification-type" class="form-control">
                        <option value="info">အချက်အလက်</option>
                        <option value="success">အောင်မြင်မှု</option>
                        <option value="warning">သတိပေးချက်</option>
                        <option value="error">အမှား</option>
                    </select>
                </div>
                <button type="submit" class="btn-primary">
                    <i class="fas fa-paper-plane"></i> ပို့ရန်
                </button>
            </form>
        </div>
    </div>

    <script src="../assets/js/admin.js"></script>
    <script>
        let currentUserId = null;
        
        function sendNotificationToUser(userId) {
            currentUserId = userId;
            document.getElementById('notification-modal').style.display = 'block';
        }
        
        function closeNotificationModal() {
            document.getElementById('notification-modal').style.display = 'none';
            document.getElementById('notification-form').reset();
        }
        
        document.getElementById('notification-form').addEventListener('submit', function(e) {
            e.preventDefault();
            
            const title = document.getElementById('notification-title').value;
            const message = document.getElementById('notification-message').value;
            const type = document.getElementById('notification-type').value;
            
            fetch('api/send_notification.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    user_id: currentUserId,
                    title: title,
                    message: message,
                    type: type
                })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    showAdminNotification('အသိပေးချက် ပို့ပြီးပါပြီ', 'success');
                    closeNotificationModal();
                } else {
                    showAdminNotification('အမှားတစ်ခု ဖြစ်ပွားခဲ့သည်', 'error');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                showAdminNotification('အမှားတစ်ခု ဖြစ်ပွားခဲ့သည်', 'error');
            });
        });
    </script>
</body>
</html>
