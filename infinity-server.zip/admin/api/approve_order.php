<?php
session_start();
require_once '../../includes/functions.php';
require_once '../../config/database.php';
require_once '../../includes/security.php';

header('Content-Type: application/json');

if (!isLoggedIn() || !isAdmin()) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit();
}

$input = json_decode(file_get_contents('php://input'), true);

if (!isset($input['order_id']) || !is_numeric($input['order_id'])) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Invalid order ID']);
    exit();
}

$order_id = (int)$input['order_id'];

try {
    // Get order details
    $stmt = $conn->prepare("SELECT o.*, u.email, u.first_name, u.last_name FROM orders o JOIN users u ON o.user_id = u.id WHERE o.id = ?");
    $stmt->bind_param("i", $order_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows === 0) {
        echo json_encode(['success' => false, 'message' => 'Order not found']);
        exit();
    }
    
    $order = $result->fetch_assoc();
    
    // Update order status to completed
    $stmt = $conn->prepare("UPDATE orders SET status = 'completed', approved_at = NOW(), approved_by = ? WHERE id = ?");
    $stmt->bind_param("ii", $_SESSION['user_id'], $order_id);
    
    if ($stmt->execute()) {
        // Add notification for user
        $stmt = $conn->prepare("INSERT INTO notifications (user_id, title, message, type, created_at) VALUES (?, 'Order Approved', 'Your order has been approved and is ready for download', 'success', NOW())");
        $stmt->bind_param("i", $order['user_id']);
        $stmt->execute();
        
        // Log the action
        logSecurityEvent('order_approved', "Order ID: $order_id approved by admin ID: " . $_SESSION['user_id']);
        
        echo json_encode([
            'success' => true,
            'message' => 'Order approved successfully'
        ]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to approve order']);
    }
    
} catch (Exception $e) {
    error_log("Approve order error: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'Server error']);
}
?>
