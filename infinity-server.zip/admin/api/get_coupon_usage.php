<?php
require_once '../../includes/functions.php';

if (!isAdmin()) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit();
}

$coupon_id = isset($_GET['coupon_id']) ? (int)$_GET['coupon_id'] : 0;

if (!$coupon_id) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Invalid coupon ID']);
    exit();
}

$database = new Database();
$db = $database->getConnection();

try {
    $query = "SELECT cu.*, u.username, o.order_uid, 
              DATE_FORMAT(cu.used_at, '%Y-%m-%d %H:%i') as used_at
              FROM coupon_usage cu
              JOIN users u ON cu.user_id = u.id
              JOIN orders o ON cu.order_id = o.id
              WHERE cu.coupon_id = ?
              ORDER BY cu.used_at DESC";
    
    $stmt = $db->prepare($query);
    $stmt->execute([$coupon_id]);
    $usage = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo json_encode([
        'success' => true,
        'usage' => $usage
    ]);
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Database error']);
}
?>
