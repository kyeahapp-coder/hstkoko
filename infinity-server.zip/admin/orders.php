<?php
require_once '../includes/functions.php';

if (!isAdmin()) {
    redirect('../login.php?admin=1');
}

$database = new Database();
$db = $database->getConnection();

$success = '';
$error = '';

// Handle order approval
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['approve_order'])) {
    $order_id = (int)$_POST['order_id'];
    
    $approve_query = "UPDATE orders SET admin_approved = 1 WHERE id = ?";
    $approve_stmt = $db->prepare($approve_query);
    
    if ($approve_stmt->execute([$order_id])) {
        // Get order details for notification
        $order_query = "SELECT o.*, u.username FROM orders o JOIN users u ON o.user_id = u.id WHERE o.id = ?";
        $order_stmt = $db->prepare($order_query);
        $order_stmt->execute([$order_id]);
        $order = $order_stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($order) {
            addNotification($order['user_id'], 'အော်ဒါ အတည်ပြုပြီး', "အော်ဒါ {$order['order_uid']} ကို အတည်ပြုပြီးပါပြီ။ ယခု ဒေါင်းလုဒ်လုပ်နိုင်ပါပြီ။", 'success');
        }
        
        $success = 'အော်ဒါကို အတည်ပြုပြီးပါပြီ';
    } else {
        $error = 'အမှားတစ်ခု ဖြစ်ပွားခဲ့သည်';
    }
}

// Get all orders with pagination
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$per_page = 20;
$offset = ($page - 1) * $per_page;

$filter = isset($_GET['filter']) ? $_GET['filter'] : 'all';
$where_clause = '';
$params = [];

switch ($filter) {
    case 'pending':
        $where_clause = 'WHERE o.payment_status = "pending"';
        break;
    case 'paid':
        $where_clause = 'WHERE o.payment_status = "paid" AND o.admin_approved = 0';
        break;
    case 'approved':
        $where_clause = 'WHERE o.admin_approved = 1';
        break;
}

$orders_query = "SELECT o.*, u.username, u.email,
                 (SELECT COUNT(*) FROM order_items oi WHERE oi.order_id = o.id) as item_count,
                 (SELECT s.service_name FROM service_orders so JOIN services s ON so.service_id = s.id WHERE so.order_id = o.id LIMIT 1) as service_name
                 FROM orders o 
                 JOIN users u ON o.user_id = u.id 
                 $where_clause
                 ORDER BY o.created_at DESC 
                 LIMIT ? OFFSET ?";

$params[] = $per_page;
$params[] = $offset;

$orders_stmt = $db->prepare($orders_query);
$orders_stmt->execute($params);
$orders = $orders_stmt->fetchAll(PDO::FETCH_ASSOC);

// Get total orders for pagination
$count_query = "SELECT COUNT(*) as total FROM orders o JOIN users u ON o.user_id = u.id $where_clause";
$count_stmt = $db->prepare($count_query);
$count_stmt->execute();
$total_orders = $count_stmt->fetch(PDO::FETCH_ASSOC)['total'];
$total_pages = ceil($total_orders / $per_page);
?>

<!DOCTYPE html>
<html lang="my">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>အော်ဒါများ - Admin Panel</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/admin.css">
    <link rel="stylesheet" href="../assets/css/additional.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body>
    <div class="admin-layout">
        <aside class="admin-sidebar">
            <div class="admin-brand">
                <h2><i class="fas fa-cog"></i> Admin Panel</h2>
            </div>
            <nav class="admin-nav">
                <a href="index.php"><i class="fas fa-dashboard"></i> Dashboard</a>
                <a href="images.php"><i class="fas fa-images"></i> ဓာတ်ပုံများ</a>
                <a href="orders.php" class="active"><i class="fas fa-shopping-bag"></i> အော်ဒါများ</a>
                <a href="users.php"><i class="fas fa-users"></i> အသုံးပြုသူများ</a>
                <a href="services.php"><i class="fas fa-concierge-bell"></i> ဝန်ဆောင်မှုများ</a>
                <a href="settings.php"><i class="fas fa-cog"></i> ဆက်တင်များ</a>
                <a href="../logout.php"><i class="fas fa-sign-out-alt"></i> ထွက်ရန်</a>
            </nav>
        </aside>
        
        <main class="admin-main">
            <header class="admin-header">
                <h1>အော်ဒါများ စီမံခန့်ခွဲမှု</h1>
            </header>
            
            <div class="admin-content">
                <?php if ($success): ?>
                    <div class="alert alert-success">
                        <i class="fas fa-check-circle"></i>
                        <?php echo $success; ?>
                    </div>
                <?php endif; ?>
                
                <?php if ($error): ?>
                    <div class="alert alert-error">
                        <i class="fas fa-exclamation-circle"></i>
                        <?php echo $error; ?>
                    </div>
                <?php endif; ?>
                
                <!-- Filter Tabs -->
                <div class="filter-tabs">
                    <a href="?filter=all" class="filter-tab <?php echo $filter === 'all' ? 'active' : ''; ?>">
                        <i class="fas fa-list"></i> အားလုံး
                    </a>
                    <a href="?filter=pending" class="filter-tab <?php echo $filter === 'pending' ? 'active' : ''; ?>">
                        <i class="fas fa-clock"></i> စောင့်ဆိုင်းနေသော
                    </a>
                    <a href="?filter=paid" class="filter-tab <?php echo $filter === 'paid' ? 'active' : ''; ?>">
                        <i class="fas fa-credit-card"></i> ငွေပေးချေပြီး
                    </a>
                    <a href="?filter=approved" class="filter-tab <?php echo $filter === 'approved' ? 'active' : ''; ?>">
                        <i class="fas fa-check-circle"></i> အတည်ပြုပြီး
                    </a>
                </div>
                
                <div class="orders-table-container">
                    <div class="table-container">
                        <table class="admin-table">
                            <thead>
                                <tr>
                                    <th>အော်ဒါ ID</th>
                                    <th>အသုံးပြုသူ</th>
                                    <th>အမျိုးအစား</th>
                                    <th>ပမာဏ</th>
                                    <th>ငွေပေးချေမှု</th>
                                    <th>အခြေအနေ</th>
                                    <th>ရက်စွဲ</th>
                                    <th>လုပ်ဆောင်ချက်</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($orders as $order): ?>
                                <tr>
                                    <td>
                                        <strong><?php echo $order['order_uid']; ?></strong>
                                    </td>
                                    <td>
                                        <div class="user-info">
                                            <strong><?php echo htmlspecialchars($order['username']); ?></strong>
                                            <small><?php echo htmlspecialchars($order['email']); ?></small>
                                        </div>
                                    </td>
                                    <td>
                                        <?php if ($order['service_name']): ?>
                                            <span class="order-type service">
                                                <i class="fas fa-concierge-bell"></i>
                                                <?php echo htmlspecialchars($order['service_name']); ?>
                                            </span>
                                        <?php else: ?>
                                            <span class="order-type images">
                                                <i class="fas fa-images"></i>
                                                <?php echo $order['item_count']; ?> ဓာတ်ပုံ
                                            </span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <strong>
                                            <?php 
                                            if ($order['currency'] === 'MMK') {
                                                echo formatCurrency($order['total_mmk'], 'MMK');
                                            } else {
                                                echo formatCurrency($order['total_thb'], 'THB');
                                            }
                                            ?>
                                        </strong>
                                    </td>
                                    <td>
                                        <span class="payment-method">
                                            <?php echo ucfirst($order['payment_method']); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <span class="status-badge <?php echo $order['admin_approved'] ? 'approved' : ($order['payment_status'] === 'pending' ? 'pending' : 'paid'); ?>">
                                            <?php 
                                            if ($order['admin_approved']) {
                                                echo 'အတည်ပြုပြီး';
                                            } elseif ($order['payment_status'] === 'pending') {
                                                echo 'စောင့်ဆိုင်းနေသည်';
                                            } else {
                                                echo 'ငွေပေးချေပြီး';
                                            }
                                            ?>
                                        </span>
                                    </td>
                                    <td>
                                        <div class="date-info">
                                            <strong><?php echo date('Y-m-d', strtotime($order['created_at'])); ?></strong>
                                            <small><?php echo date('H:i', strtotime($order['created_at'])); ?></small>
                                        </div>
                                    </td>
                                    <td>
                                        <div class="action-buttons">
                                            <a href="order_details.php?id=<?php echo $order['id']; ?>" class="btn-view" title="အသေးစိတ်ကြည့်ရန်">
                                                <i class="fas fa-eye"></i>
                                            </a>
                                            
                                            <?php if (!$order['admin_approved'] && $order['payment_status'] === 'paid'): ?>
                                                <form method="POST" style="display: inline;">
                                                    <input type="hidden" name="order_id" value="<?php echo $order['id']; ?>">
                                                    <button type="submit" name="approve_order" class="btn-approve" title="အတည်ပြုရန်" onclick="return confirm('ဤအော်ဒါကို အတည်ပြုမှာ သေချာပါသလား?')">
                                                        <i class="fas fa-check"></i>
                                                    </button>
                                                </form>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    
                    <?php if ($total_pages > 1): ?>
                        <div class="pagination">
                            <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                                <a href="?page=<?php echo $i; ?>&filter=<?php echo $filter; ?>" class="<?php echo $i == $page ? 'active' : ''; ?>">
                                    <?php echo $i; ?>
                                </a>
                            <?php endfor; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </main>
    </div>

    <script src="../assets/js/admin.js"></script>
</body>
</html>
