<?php
require_once '../includes/functions.php';

if (!isAdmin()) {
    redirect('../login.php?admin=1');
}

$success = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['update_settings'])) {
        $settings = [
            'images_per_page' => (int)$_POST['images_per_page'],
            'admin_commission' => (float)$_POST['admin_commission'],
            'bulk_discount_2' => (float)$_POST['bulk_discount_2'],
            'bulk_discount_5' => (float)$_POST['bulk_discount_5'],
            'bulk_discount_10' => (float)$_POST['bulk_discount_10']
        ];
        
        foreach ($settings as $key => $value) {
            updateSetting($key, $value);
        }
        
        // Handle logo upload
        if (isset($_FILES['site_logo']) && $_FILES['site_logo']['error'] === UPLOAD_ERR_OK) {
            $upload_dir = '../assets/images/';
            $file_extension = pathinfo($_FILES['site_logo']['name'], PATHINFO_EXTENSION);
            $new_filename = 'logo.' . $file_extension;
            $upload_path = $upload_dir . $new_filename;
            
            if (move_uploaded_file($_FILES['site_logo']['tmp_name'], $upload_path)) {
                updateSetting('site_logo', 'assets/images/' . $new_filename);
            }
        }
        
        // Handle QR code uploads
        if (isset($_FILES['wave_qr']) && $_FILES['wave_qr']['error'] === UPLOAD_ERR_OK) {
            $upload_dir = '../assets/qr/';
            if (!is_dir($upload_dir)) {
                mkdir($upload_dir, 0755, true);
            }
            $upload_path = $upload_dir . 'wave.png';
            
            if (move_uploaded_file($_FILES['wave_qr']['tmp_name'], $upload_path)) {
                updateSetting('wave_qr', 'assets/qr/wave.png');
            }
        }
        
        if (isset($_FILES['kpay_qr']) && $_FILES['kpay_qr']['error'] === UPLOAD_ERR_OK) {
            $upload_dir = '../assets/qr/';
            if (!is_dir($upload_dir)) {
                mkdir($upload_dir, 0755, true);
            }
            $upload_path = $upload_dir . 'kpay.png';
            
            if (move_uploaded_file($_FILES['kpay_qr']['tmp_name'], $upload_path)) {
                updateSetting('kpay_qr', 'assets/qr/kpay.png');
            }
        }
        
        $success = 'ဆက်တင်များကို ပြင်ဆင်ပြီးပါပြီ';
    }
}

// Get current settings
$current_settings = [
    'images_per_page' => getSetting('images_per_page') ?: 7,
    'admin_commission' => getSetting('admin_commission') ?: 10,
    'bulk_discount_2' => getSetting('bulk_discount_2') ?: 5,
    'bulk_discount_5' => getSetting('bulk_discount_5') ?: 10,
    'bulk_discount_10' => getSetting('bulk_discount_10') ?: 15,
    'site_logo' => getSetting('site_logo') ?: 'assets/images/logo.png',
    'wave_qr' => getSetting('wave_qr') ?: 'assets/qr/wave.png',
    'kpay_qr' => getSetting('kpay_qr') ?: 'assets/qr/kpay.png'
];
?>

<!DOCTYPE html>
<html lang="my">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ဆက်တင်များ - Admin Panel</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/admin.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body>
    <div class="admin-layout">
        <aside class="admin-sidebar">
            <div class="admin-brand">
                <h2><i class="fas fa-cog"></i> Admin Panel</h2>
            </div>
            <nav class="admin-nav">
                <a href="index.php"><i class="fas fa-dashboard"></i> Dashboard</a>
                <a href="images.php"><i class="fas fa-images"></i> ဓာတ်ပုံများ</a>
                <a href="orders.php"><i class="fas fa-shopping-bag"></i> အော်ဒါများ</a>
                <a href="users.php"><i class="fas fa-users"></i> အသုံးပြုသူများ</a>
                <a href="services.php"><i class="fas fa-concierge-bell"></i> ဝန်ဆောင်မှုများ</a>
                <a href="settings.php" class="active"><i class="fas fa-cog"></i> ဆက်တင်များ</a>
                <a href="../logout.php"><i class="fas fa-sign-out-alt"></i> ထွက်ရန်</a>
            </nav>
        </aside>
        
        <main class="admin-main">
            <header class="admin-header">
                <h1>ဆက်တင်များ</h1>
            </header>
            
            <div class="admin-content">
                <?php if ($success): ?>
                    <div class="alert alert-success">
                        <i class="fas fa-check-circle"></i>
                        <?php echo $success; ?>
                    </div>
                <?php endif; ?>
                
                <?php if ($error): ?>
                    <div class="alert alert-error">
                        <i class="fas fa-exclamation-circle"></i>
                        <?php echo $error; ?>
                    </div>
                <?php endif; ?>
                
                <form method="POST" enctype="multipart/form-data" class="admin-form">
                    <div class="settings-sections">
                        <!-- General Settings -->
                        <div class="settings-section">
                            <h3><i class="fas fa-cog"></i> အထွေထွေ ဆက်တင်များ</h3>
                            
                            <div class="form-group">
                                <label for="images_per_page">စာမျက်နှာတစ်ခုတွင် ပြသမည့် ဓာတ်ပုံအရေအတွက်:</label>
                                <input type="number" id="images_per_page" name="images_per_page" 
                                       value="<?php echo $current_settings['images_per_page']; ?>" 
                                       class="form-control" min="1" max="20" required>
                            </div>
                            
                            <div class="form-group">
                                <label for="admin_commission">Admin ကော်မရှင် (%):</label>
                                <input type="number" id="admin_commission" name="admin_commission" 
                                       value="<?php echo $current_settings['admin_commission']; ?>" 
                                       class="form-control" min="0" max="100" step="0.1" required>
                            </div>
                        </div>
                        
                        <!-- Discount Settings -->
                        <div class="settings-section">
                            <h3><i class="fas fa-percentage"></i> လျှော့စျေး ဆက်တင်များ</h3>
                            
                            <div class="form-group">
                                <label for="bulk_discount_2">၂ပုံ လျှော့စျေး (%):</label>
                                <input type="number" id="bulk_discount_2" name="bulk_discount_2" 
                                       value="<?php echo $current_settings['bulk_discount_2']; ?>" 
                                       class="form-control" min="0" max="100" step="0.1" required>
                            </div>
                            
                            <div class="form-group">
                                <label for="bulk_discount_5">၅ပုံ လျှော့စျေး (%):</label>
                                <input type="number" id="bulk_discount_5" name="bulk_discount_5" 
                                       value="<?php echo $current_settings['bulk_discount_5']; ?>" 
                                       class="form-control" min="0" max="100" step="0.1" required>
                            </div>
                            
                            <div class="form-group">
                                <label for="bulk_discount_10">၁၀ပုံ လျှော့စျေး (%):</label>
                                <input type="number" id="bulk_discount_10" name="bulk_discount_10" 
                                       value="<?php echo $current_settings['bulk_discount_10']; ?>" 
                                       class="form-control" min="0" max="100" step="0.1" required>
                            </div>
                        </div>
                        
                        <!-- Logo Settings -->
                        <div class="settings-section">
                            <h3><i class="fas fa-image"></i> လိုဂို ဆက်တင်များ</h3>
                            
                            <div class="form-group">
                                <label>လက်ရှိ လိုဂို:</label>
                                <div class="current-logo">
                                    <img src="../<?php echo $current_settings['site_logo']; ?>" alt="Current Logo" style="max-height: 100px;">
                                </div>
                            </div>
                            
                            <div class="form-group">
                                <label for="site_logo">လိုဂို အသစ် (ရွေးချယ်ခွင့်ရှိသော):</label>
                                <div class="image-upload">
                                    <input type="file" id="site_logo" name="site_logo" accept="image/*">
                                    <p><i class="fas fa-cloud-upload-alt"></i> ဓာတ်ပုံကို ရွေးချယ်ပါ သို့မဟုတ် ဆွဲထည့်ပါ</p>
                                </div>
                            </div>
                        </div>
                        
                        <!-- QR Code Settings -->
                        <div class="settings-section">
                            <h3><i class="fas fa-qrcode"></i> QR Code ဆက်တင်များ</h3>
                            
                            <div class="qr-codes-grid">
                                <div class="qr-code-item">
                                    <label>Wave Pay QR:</label>
                                    <div class="current-qr">
                                        <img src="../<?php echo $current_settings['wave_qr']; ?>" alt="Wave QR" style="max-height: 150px;">
                                    </div>
                                    <div class="form-group">
                                        <label for="wave_qr">Wave QR အသစ်:</label>
                                        <div class="image-upload">
                                            <input type="file" id="wave_qr" name="wave_qr" accept="image/*">
                                            <p><i class="fas fa-cloud-upload-alt"></i> QR Code ရွေးချယ်ပါ</p>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="qr-code-item">
                                    <label>KBZ Pay QR:</label>
                                    <div class="current-qr">
                                        <img src="../<?php echo $current_settings['kpay_qr']; ?>" alt="KPay QR" style="max-height: 150px;">
                                    </div>
                                    <div class="form-group">
                                        <label for="kpay_qr">KBZ Pay QR အသစ်:</label>
                                        <div class="image-upload">
                                            <input type="file" id="kpay_qr" name="kpay_qr" accept="image/*">
                                            <p><i class="fas fa-cloud-upload-alt"></i> QR Code ရွေးချယ်ပါ</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="form-actions">
                        <button type="submit" name="update_settings" class="btn-primary">
                            <i class="fas fa-save"></i> ဆက်တင်များ သိမ်းဆည်းရန်
                        </button>
                    </div>
                </form>
            </div>
        </main>
    </div>

    <script src="../assets/js/admin.js"></script>
</body>
</html>
