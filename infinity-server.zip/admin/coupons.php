<?php
require_once '../includes/functions.php';

if (!isAdmin()) {
    redirect('../login.php?admin=1');
}

$database = new Database();
$db = $database->getConnection();

$success = '';
$error = '';

// Handle coupon actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['add_coupon'])) {
        $code = strtoupper(trim($_POST['code']));
        $type = $_POST['type'];
        $value = (float)$_POST['value'];
        $minimum_amount = (float)$_POST['minimum_amount'];
        $usage_limit = !empty($_POST['usage_limit']) ? (int)$_POST['usage_limit'] : null;
        $expires_at = !empty($_POST['expires_at']) ? $_POST['expires_at'] : null;
        
        if (empty($code) || $value <= 0) {
            $error = 'ကျေးဇူးပြု၍ လိုအပ်သော အချက်အလက်များကို ဖြည့်စွက်ပါ';
        } else {
            // Check if code already exists
            $check_query = "SELECT id FROM coupons WHERE code = ?";
            $check_stmt = $db->prepare($check_query);
            $check_stmt->execute([$code]);
            
            if ($check_stmt->fetch()) {
                $error = 'ဤကူပွန်ကုဒ် ရှိနေပြီးဖြစ်ပါသည်';
            } else {
                $insert_query = "INSERT INTO coupons (code, type, value, minimum_amount, usage_limit, expires_at) 
                               VALUES (?, ?, ?, ?, ?, ?)";
                $insert_stmt = $db->prepare($insert_query);
                
                if ($insert_stmt->execute([$code, $type, $value, $minimum_amount, $usage_limit, $expires_at])) {
                    $success = 'ကူပွန်အသစ် ထည့်ပြီးပါပြီ';
                } else {
                    $error = 'ဒေတာဘေ့စ်တွင် သိမ်းဆည်းရာ အမှားတစ်ခု ဖြစ်ပွားခဲ့သည်';
                }
            }
        }
    } elseif (isset($_POST['toggle_coupon'])) {
        $coupon_id = (int)$_POST['coupon_id'];
        $is_active = (int)$_POST['is_active'];
        
        $update_query = "UPDATE coupons SET is_active = ? WHERE id = ?";
        $update_stmt = $db->prepare($update_query);
        
        if ($update_stmt->execute([!$is_active, $coupon_id])) {
            $success = 'ကူပွန်အခြေအနေ ပြောင်းလဲပြီးပါပြီ';
        } else {
            $error = 'ပြင်ဆင်ရာတွင် အမှားတစ်ခု ဖြစ်ပွားခဲ့သည်';
        }
    }
}

// Get all coupons
$coupons_query = "SELECT c.*, 
                  (SELECT COUNT(*) FROM coupon_usage cu WHERE cu.coupon_id = c.id) as total_used
                  FROM coupons c 
                  ORDER BY c.created_at DESC";
$coupons_stmt = $db->prepare($coupons_query);
$coupons_stmt->execute();
$coupons = $coupons_stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="my">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ကူပွန်များ - Admin Panel</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/admin.css">
    <link rel="stylesheet" href="../assets/css/coupon.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body>
    <div class="admin-layout">
        <aside class="admin-sidebar">
            <div class="admin-brand">
                <h2><i class="fas fa-cog"></i> Admin Panel</h2>
            </div>
            <nav class="admin-nav">
                <a href="index.php"><i class="fas fa-dashboard"></i> Dashboard</a>
                <a href="images.php"><i class="fas fa-images"></i> ဓာတ်ပုံများ</a>
                <a href="orders.php"><i class="fas fa-shopping-bag"></i> အော်ဒါများ</a>
                <a href="users.php"><i class="fas fa-users"></i> အသုံးပြုသူများ</a>
                <a href="services.php"><i class="fas fa-concierge-bell"></i> ဝန်ဆောင်မှုများ</a>
                <a href="coupons.php" class="active"><i class="fas fa-tags"></i> ကူပွန်များ</a>
                <a href="settings.php"><i class="fas fa-cog"></i> ဆက်တင်များ</a>
                <a href="../logout.php"><i class="fas fa-sign-out-alt"></i> ထွက်ရန်</a>
            </nav>
        </aside>
        
        <main class="admin-main">
            <header class="admin-header">
                <h1>ကူပွန်များ စီမံခန့်ခွဲမှု</h1>
            </header>
            
            <div class="admin-content">
                <?php if ($success): ?>
                    <div class="alert alert-success">
                        <i class="fas fa-check-circle"></i>
                        <?php echo $success; ?>
                    </div>
                <?php endif; ?>
                
                <?php if ($error): ?>
                    <div class="alert alert-error">
                        <i class="fas fa-exclamation-circle"></i>
                        <?php echo $error; ?>
                    </div>
                <?php endif; ?>
                
                <!-- Add Coupon Form -->
                <div class="add-coupon-section">
                    <h2>ကူပွန်အသစ် ထည့်ရန်</h2>
                    <form method="POST" class="admin-form">
                        <div class="form-row">
                            <div class="form-group">
                                <label for="code">ကူပွန်ကုဒ်:</label>
                                <input type="text" id="code" name="code" class="form-control" required style="text-transform: uppercase;">
                            </div>
                            <div class="form-group">
                                <label for="type">အမျိုးအစား:</label>
                                <select id="type" name="type" class="form-control" required>
                                    <option value="percentage">ရာခိုင်နှုန်း (%)</option>
                                    <option value="fixed">သတ်မှတ်ပမာဏ</option>
                                </select>
                            </div>
                        </div>
                        
                        <div class="form-row">
                            <div class="form-group">
                                <label for="value">တန်ဖိုး:</label>
                                <input type="number" id="value" name="value" class="form-control" step="0.01" required>
                            </div>
                            <div class="form-group">
                                <label for="minimum_amount">အနည်းဆုံး ပမာဏ (MMK):</label>
                                <input type="number" id="minimum_amount" name="minimum_amount" class="form-control" step="0.01" value="0">
                            </div>
                        </div>
                        
                        <div class="form-row">
                            <div class="form-group">
                                <label for="usage_limit">အသုံးပြုနိုင်သော အကြိမ်အရေအတွက်:</label>
                                <input type="number" id="usage_limit" name="usage_limit" class="form-control" placeholder="အကန့်အသတ်မရှိ">
                            </div>
                            <div class="form-group">
                                <label for="expires_at">သက်တမ်းကုန်ဆုံးရက်:</label>
                                <input type="datetime-local" id="expires_at" name="expires_at" class="form-control">
                            </div>
                        </div>
                        
                        <button type="submit" name="add_coupon" class="btn-primary">
                            <i class="fas fa-plus"></i> ကူပွန် ထည့်ရန်
                        </button>
                    </form>
                </div>
                
                <!-- Coupons List -->
                <div class="coupons-list-section">
                    <h2>ကူပွန်များ စာရင်း</h2>
                    
                    <?php if (empty($coupons)): ?>
                        <div class="no-coupons">
                            <i class="fas fa-tags"></i>
                            <h3>ကူပွန်များ မရှိသေးပါ</h3>
                            <p>ကူပွန်အသစ်များ ထည့်ပါ</p>
                        </div>
                    <?php else: ?>
                        <div class="coupons-grid">
                            <?php foreach ($coupons as $coupon): ?>
                                <div class="coupon-card">
                                    <div class="coupon-header">
                                        <div class="coupon-code"><?php echo htmlspecialchars($coupon['code']); ?></div>
                                        <div class="coupon-status-container">
                                            <?php
                                            $status = 'active';
                                            $statusText = 'အသုံးပြုနေ';
                                            
                                            if (!$coupon['is_active']) {
                                                $status = 'inactive';
                                                $statusText = 'ပိတ်ထား';
                                            } elseif ($coupon['expires_at'] && strtotime($coupon['expires_at']) < time()) {
                                                $status = 'expired';
                                                $statusText = 'သက်တမ်းကုန်';
                                            } elseif ($coupon['usage_limit'] && $coupon['total_used'] >= $coupon['usage_limit']) {
                                                $status = 'used-up';
                                                $statusText = 'အသုံးပြုပြီး';
                                            }
                                            ?>
                                            <span class="coupon-status <?php echo $status; ?>"><?php echo $statusText; ?></span>
                                        </div>
                                    </div>
                                    
                                    <div class="coupon-details">
                                        <div class="coupon-detail">
                                            <div class="label">အမျိုးအစား</div>
                                            <div class="value">
                                                <?php echo $coupon['type'] === 'percentage' ? 'ရာခိုင်နှုန်း' : 'သတ်မှတ်ပမာဏ'; ?>
                                            </div>
                                        </div>
                                        <div class="coupon-detail">
                                            <div class="label">တန်ဖိုး</div>
                                            <div class="value">
                                                <?php 
                                                if ($coupon['type'] === 'percentage') {
                                                    echo $coupon['value'] . '%';
                                                } else {
                                                    echo formatCurrency($coupon['value'], 'MMK');
                                                }
                                                ?>
                                            </div>
                                        </div>
                                        <div class="coupon-detail">
                                            <div class="label">အနည်းဆုံး ပမာဏ</div>
                                            <div class="value"><?php echo formatCurrency($coupon['minimum_amount'], 'MMK'); ?></div>
                                        </div>
                                        <div class="coupon-detail">
                                            <div class="label">အသုံးပြုမှု</div>
                                            <div class="value">
                                                <?php echo $coupon['total_used']; ?> / 
                                                <?php echo $coupon['usage_limit'] ? $coupon['usage_limit'] : '∞'; ?>
                                            </div>
                                        </div>
                                        <div class="coupon-detail">
                                            <div class="label">သက်တမ်းကုန်ဆုံးရက်</div>
                                            <div class="value">
                                                <?php 
                                                if ($coupon['expires_at']) {
                                                    echo date('Y-m-d H:i', strtotime($coupon['expires_at']));
                                                } else {
                                                    echo 'သက်တမ်းမရှိ';
                                                }
                                                ?>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <div class="coupon-actions">
                                        <form method="POST" style="display: inline;">
                                            <input type="hidden" name="coupon_id" value="<?php echo $coupon['id']; ?>">
                                            <input type="hidden" name="is_active" value="<?php echo $coupon['is_active']; ?>">
                                            <button type="submit" name="toggle_coupon" class="btn-<?php echo $coupon['is_active'] ? 'delete' : 'approve'; ?>">
                                                <i class="fas fa-<?php echo $coupon['is_active'] ? 'pause' : 'play'; ?>"></i>
                                                <?php echo $coupon['is_active'] ? 'ပိတ်ရန်' : 'ဖွင့်ရန်'; ?>
                                            </button>
                                        </form>
                                        <button class="btn-view" onclick="viewCouponUsage(<?php echo $coupon['id']; ?>)">
                                            <i class="fas fa-chart-bar"></i> အသုံးပြုမှု
                                        </button>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </main>
    </div>

    <!-- Coupon Usage Modal -->
    <div id="usage-modal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="closeUsageModal()">&times;</span>
            <h3>ကူပွန် အသုံးပြုမှု အသေးစိတ်</h3>
            <div id="usage-content">
                <!-- Usage details will be loaded here -->
            </div>
        </div>
    </div>

    <script src="../assets/js/admin.js"></script>
    <script>
        function viewCouponUsage(couponId) {
            fetch(`api/get_coupon_usage.php?coupon_id=${couponId}`)
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        displayCouponUsage(data.usage);
                        document.getElementById('usage-modal').style.display = 'block';
                    } else {
                        showAdminNotification('အချက်အလက်များ ရယူ၍မရပါ', 'error');
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    showAdminNotification('အမှားတစ်ခု ဖြစ်ပွားခဲ့သည်', 'error');
                });
        }
        
        function displayCouponUsage(usage) {
            const content = document.getElementById('usage-content');
            
            if (usage.length === 0) {
                content.innerHTML = '<p>ဤကူပွန်ကို မည်သူမျှ အသုံးမပြုရသေးပါ</p>';
                return;
            }
            
            let html = '<table class="admin-table"><thead><tr><th>အသုံးပြုသူ</th><th>အော်ဒါ</th><th>လျှော့စျေးပမာဏ</th><th>ရက်စွဲ</th></tr></thead><tbody>';
            
            usage.forEach(item => {
                html += `<tr>
                    <td>${item.username}</td>
                    <td>${item.order_uid}</td>
                    <td>${item.discount_amount} ကျပ်</td>
                    <td>${item.used_at}</td>
                </tr>`;
            });
            
            html += '</tbody></table>';
            content.innerHTML = html;
        }
        
        function closeUsageModal() {
            document.getElementById('usage-modal').style.display = 'none';
        }
        
        // Close modal when clicking outside
        window.onclick = function(event) {
            const modal = document.getElementById('usage-modal');
            if (event.target === modal) {
                closeUsageModal();
            }
        }
    </script>
</body>
</html>
