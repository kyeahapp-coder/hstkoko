<?php
require_once '../includes/functions.php';

if (!isAdmin()) {
    redirect('../login.php?admin=1');
}

$database = new Database();
$db = $database->getConnection();

$success = '';
$error = '';

// Handle image upload
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['upload_image'])) {
    $title = trim($_POST['title']);
    $description = trim($_POST['description']);
    $price_mmk = (float)$_POST['price_mmk'];
    $price_thb = (float)$_POST['price_thb'];
    
    if (empty($title) || !isset($_FILES['image']) || $_FILES['image']['error'] !== UPLOAD_ERR_OK) {
        $error = 'ကျေးဇူးပြု၍ လိုအပ်သော အချက်အလက်များကို ဖြည့်စွက်ပါ';
    } else {
        $upload_dir = '../uploads/';
        $watermark_dir = '../uploads/watermarked/';
        
        // Create directories if they don't exist
        if (!is_dir($upload_dir)) mkdir($upload_dir, 0755, true);
        if (!is_dir($watermark_dir)) mkdir($watermark_dir, 0755, true);
        
        $file_extension = pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION);
        $filename = uniqid() . '.' . $file_extension;
        $original_path = $upload_dir . $filename;
        $watermark_path = $watermark_dir . $filename;
        
        if (move_uploaded_file($_FILES['image']['tmp_name'], $original_path)) {
            // Create watermarked version (simple text overlay)
            createWatermarkedImage($original_path, $watermark_path);
            
            // Save to database
            $insert_query = "INSERT INTO images (filename, title, description, price_mmk, price_thb, watermark_path, original_path) 
                           VALUES (?, ?, ?, ?, ?, ?, ?)";
            $insert_stmt = $db->prepare($insert_query);
            
            if ($insert_stmt->execute([$filename, $title, $description, $price_mmk, $price_thb, $watermark_path, $original_path])) {
                $success = 'ဓာတ်ပုံ အပ်လုဒ်လုပ်ပြီးပါပြီ';
            } else {
                $error = 'ဒေတာဘေ့စ်တွင် သိမ်းဆည်းရာ အမှားတစ်ခု ဖြစ်ပွားခဲ့သည်';
            }
        } else {
            $error = 'ဓာတ်ပုံ အပ်လုဒ်လုပ်ရာတွင် အမှားတစ်ခု ဖြစ်ပွားခဲ့သည်';
        }
    }
}

// Handle image deletion
if (isset($_GET['delete']) && is_numeric($_GET['delete'])) {
    $image_id = (int)$_GET['delete'];
    
    // Get image paths
    $image_query = "SELECT * FROM images WHERE id = ?";
    $image_stmt = $db->prepare($image_query);
    $image_stmt->execute([$image_id]);
    $image = $image_stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($image) {
        // Delete files
        if (file_exists($image['original_path'])) unlink($image['original_path']);
        if (file_exists($image['watermark_path'])) unlink($image['watermark_path']);
        
        // Delete from database
        $delete_query = "DELETE FROM images WHERE id = ?";
        $delete_stmt = $db->prepare($delete_query);
        $delete_stmt->execute([$image_id]);
        
        $success = 'ဓာတ်ပုံကို ဖျက်ပြီးပါပြီ';
    }
}

// Get all images
$images_query = "SELECT * FROM images ORDER BY created_at DESC";
$images_stmt = $db->prepare($images_query);
$images_stmt->execute();
$images = $images_stmt->fetchAll(PDO::FETCH_ASSOC);

function createWatermarkedImage($source, $destination) {
    $image_info = getimagesize($source);
    $mime_type = $image_info['mime'];
    
    switch ($mime_type) {
        case 'image/jpeg':
            $image = imagecreatefromjpeg($source);
            break;
        case 'image/png':
            $image = imagecreatefrompng($source);
            break;
        case 'image/gif':
            $image = imagecreatefromgif($source);
            break;
        default:
            return false;
    }
    
    $width = imagesx($image);
    $height = imagesy($image);
    
    // Add watermark text
    $watermark_text = "INFINITY SERVER";
    $font_size = min($width, $height) / 20;
    $text_color = imagecolorallocatealpha($image, 255, 255, 255, 50);
    
    // Calculate text position (center)
    $text_box = imagettfbbox($font_size, 0, __DIR__ . '/../assets/fonts/arial.ttf', $watermark_text);
    $text_width = $text_box[4] - $text_box[0];
    $text_height = $text_box[1] - $text_box[7];
    $x = ($width - $text_width) / 2;
    $y = ($height - $text_height) / 2;
    
    // Add text watermark
    imagettftext($image, $font_size, 0, $x, $y, $text_color, __DIR__ . '/../assets/fonts/arial.ttf', $watermark_text);
    
    // Save watermarked image
    switch ($mime_type) {
        case 'image/jpeg':
            imagejpeg($image, $destination, 90);
            break;
        case 'image/png':
            imagepng($image, $destination);
            break;
        case 'image/gif':
            imagegif($image, $destination);
            break;
    }
    
    imagedestroy($image);
    return true;
}
?>

<!DOCTYPE html>
<html lang="my">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ဓာတ်ပုံများ - Admin Panel</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/admin.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body>
    <div class="admin-layout">
        <aside class="admin-sidebar">
            <div class="admin-brand">
                <h2><i class="fas fa-cog"></i> Admin Panel</h2>
            </div>
            <nav class="admin-nav">
                <a href="index.php"><i class="fas fa-dashboard"></i> Dashboard</a>
                <a href="images.php" class="active"><i class="fas fa-images"></i> ဓာတ်ပုံများ</a>
                <a href="orders.php"><i class="fas fa-shopping-bag"></i> အော်ဒါများ</a>
                <a href="users.php"><i class="fas fa-users"></i> အသုံးပြုသူများ</a>
                <a href="services.php"><i class="fas fa-concierge-bell"></i> ဝန်ဆောင်မှုများ</a>
                <a href="settings.php"><i class="fas fa-cog"></i> ဆက်တင်များ</a>
                <a href="../logout.php"><i class="fas fa-sign-out-alt"></i> ထွက်ရန်</a>
            </nav>
        </aside>
        
        <main class="admin-main">
            <header class="admin-header">
                <h1>ဓာတ်ပုံများ စီမံခန့်ခွဲမှု</h1>
            </header>
            
            <div class="admin-content">
                <?php if ($success): ?>
                    <div class="alert alert-success">
                        <i class="fas fa-check-circle"></i>
                        <?php echo $success; ?>
                    </div>
                <?php endif; ?>
                
                <?php if ($error): ?>
                    <div class="alert alert-error">
                        <i class="fas fa-exclamation-circle"></i>
                        <?php echo $error; ?>
                    </div>
                <?php endif; ?>
                
                <!-- Upload Form -->
                <div class="upload-section">
                    <h2>ဓာတ်ပုံအသစ် အပ်လုဒ်လုပ်ရန်</h2>
                    <form method="POST" enctype="multipart/form-data" class="admin-form">
                        <div class="form-row">
                            <div class="form-group">
                                <label for="title">ခေါင်းစဉ်:</label>
                                <input type="text" id="title" name="title" class="form-control" required>
                            </div>
                            <div class="form-group">
                                <label for="description">ဖော်ပြချက်:</label>
                                <textarea id="description" name="description" class="form-control" rows="3"></textarea>
                            </div>
                        </div>
                        
                        <div class="form-row">
                            <div class="form-group">
                                <label for="price_mmk">စျေးနှုန်း (MMK):</label>
                                <input type="number" id="price_mmk" name="price_mmk" class="form-control" step="0.01" value="20" required>
                            </div>
                            <div class="form-group">
                                <label for="price_thb">စျေးနှုန်း (THB):</label>
                                <input type="number" id="price_thb" name="price_thb" class="form-control" step="0.01" value="20" required>
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <label for="image">ဓာတ်ပုံ:</label>
                            <div class="image-upload">
                                <input type="file" id="image" name="image" accept="image/*" required>
                                <p><i class="fas fa-cloud-upload-alt"></i> ဓာတ်ပုံကို ရွေးချယ်ပါ သို့မဟုတ် ဆွဲထည့်ပါ</p>
                            </div>
                        </div>
                        
                        <button type="submit" name="upload_image" class="btn-primary">
                            <i class="fas fa-upload"></i> အပ်လုဒ်လုပ်ရန်
                        </button>
                    </form>
                </div>
                
                <!-- Images List -->
                <div class="images-section">
                    <h2>ဓာတ်ပုံများ စာရင်း</h2>
                    <div class="images-grid">
                        <?php foreach ($images as $image): ?>
                            <div class="image-admin-card">
                                <div class="image-preview">
                                    <img src="../<?php echo $image['watermark_path']; ?>" alt="<?php echo htmlspecialchars($image['title']); ?>">
                                </div>
                                <div class="image-details">
                                    <h4><?php echo htmlspecialchars($image['title']); ?></h4>
                                    <p><?php echo htmlspecialchars($image['description']); ?></p>
                                    <div class="image-prices">
                                        <span class="price"><?php echo formatCurrency($image['price_mmk'], 'MMK'); ?></span>
                                        <span class="price"><?php echo formatCurrency($image['price_thb'], 'THB'); ?></span>
                                    </div>
                                    <div class="image-stats">
                                        <span><i class="fas fa-eye"></i> <?php echo $image['views']; ?></span>
                                        <span><i class="fas fa-download"></i> <?php echo $image['downloads']; ?></span>
                                    </div>
                                </div>
                                <div class="image-actions">
                                    <button class="btn-edit" onclick="editImage(<?php echo $image['id']; ?>)">
                                        <i class="fas fa-edit"></i>
                                    </button>
                                    <a href="?delete=<?php echo $image['id']; ?>" class="btn-delete" onclick="return confirm('ဤဓာတ်ပုံကို ဖျက်မှာ သေချာပါသလား?')">
                                        <i class="fas fa-trash"></i>
                                    </a>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
        </main>
    </div>

    <script src="../assets/js/admin.js"></script>
</body>
</html>
