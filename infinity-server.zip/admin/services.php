<?php
require_once '../includes/functions.php';

if (!isAdmin()) {
    redirect('../login.php?admin=1');
}

$database = new Database();
$db = $database->getConnection();

$success = '';
$error = '';

// Handle service actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['add_service'])) {
        $service_type = trim($_POST['service_type']);
        $service_name = trim($_POST['service_name']);
        $price_mmk = (float)$_POST['price_mmk'];
        $price_thb = (float)$_POST['price_thb'];
        
        if (empty($service_type) || empty($service_name) || $price_mmk <= 0 || $price_thb <= 0) {
            $error = 'ကျေးဇူးပြု၍ လိုအပ်သော အချက်အလက်များကို ဖြည့်စွက်ပါ';
        } else {
            $insert_query = "INSERT INTO services (service_type, service_name, price_mmk, price_thb) VALUES (?, ?, ?, ?)";
            $insert_stmt = $db->prepare($insert_query);
            
            if ($insert_stmt->execute([$service_type, $service_name, $price_mmk, $price_thb])) {
                $success = 'ဝန်ဆောင်မှုအသစ် ထည့်ပြီးပါပြီ';
            } else {
                $error = 'ဒေတာဘေ့စ်တွင် သိမ်းဆည်းရာ အမှားတစ်ခု ဖြစ်ပွားခဲ့သည်';
            }
        }
    } elseif (isset($_POST['update_service'])) {
        $service_id = (int)$_POST['service_id'];
        $service_name = trim($_POST['service_name']);
        $price_mmk = (float)$_POST['price_mmk'];
        $price_thb = (float)$_POST['price_thb'];
        $is_active = isset($_POST['is_active']) ? 1 : 0;
        
        $update_query = "UPDATE services SET service_name = ?, price_mmk = ?, price_thb = ?, is_active = ? WHERE id = ?";
        $update_stmt = $db->prepare($update_query);
        
        if ($update_stmt->execute([$service_name, $price_mmk, $price_thb, $is_active, $service_id])) {
            $success = 'ဝန်ဆောင်မှုကို ပြင်ဆင်ပြီးပါပြီ';
        } else {
            $error = 'ပြင်ဆင်ရာတွင် အမှားတစ်ခု ဖြစ်ပွားခဲ့သည်';
        }
    } elseif (isset($_POST['delete_service'])) {
        $service_id = (int)$_POST['service_id'];
        
        $delete_query = "DELETE FROM services WHERE id = ?";
        $delete_stmt = $db->prepare($delete_query);
        
        if ($delete_stmt->execute([$service_id])) {
            $success = 'ဝန်ဆောင်မှုကို ဖျက်ပြီးပါပြီ';
        } else {
            $error = 'ဖျက်ရာတွင် အမှားတစ်ခု ဖြစ်ပွားခဲ့သည်';
        }
    }
}

// Get all services
$services_query = "SELECT * FROM services ORDER BY service_type, service_name";
$services_stmt = $db->prepare($services_query);
$services_stmt->execute();
$services = $services_stmt->fetchAll(PDO::FETCH_ASSOC);

// Group services by type
$grouped_services = [];
foreach ($services as $service) {
    $grouped_services[$service['service_type']][] = $service;
}

$service_types = [
    'mobile_topup_mm' => 'မြန်မာ မိုဘိုင်းဖုန်းဖြည့်တင်းခြင်း',
    'mobile_topup_th' => 'ထိုင်း မိုဘိုင်းဖုန်းဖြည့်တင်းခြင်း',
    'pubg_uc' => 'PUBG UC',
    'nmb_diamond' => 'NMB Diamond',
    'freefire_diamond' => 'Free Fire Diamond',
    'mobile_legends' => 'Mobile Legends',
    'banking' => 'ဘဏ်ကင်ဝန်ဆောင်မှု'
];
?>

<!DOCTYPE html>
<html lang="my">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ဝန်ဆောင်မှုများ - Admin Panel</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/admin.css">
    <link rel="stylesheet" href="../assets/css/additional.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body>
    <div class="admin-layout">
        <aside class="admin-sidebar">
            <div class="admin-brand">
                <h2><i class="fas fa-cog"></i> Admin Panel</h2>
            </div>
            <nav class="admin-nav">
                <a href="index.php"><i class="fas fa-dashboard"></i> Dashboard</a>
                <a href="images.php"><i class="fas fa-images"></i> ဓာတ်ပုံများ</a>
                <a href="orders.php"><i class="fas fa-shopping-bag"></i> အော်ဒါများ</a>
                <a href="users.php"><i class="fas fa-users"></i> အသုံးပြုသူများ</a>
                <a href="services.php" class="active"><i class="fas fa-concierge-bell"></i> ဝန်ဆောင်မှုများ</a>
                <a href="settings.php"><i class="fas fa-cog"></i> ဆက်တင်များ</a>
                <a href="../logout.php"><i class="fas fa-sign-out-alt"></i> ထွက်ရန်</a>
            </nav>
        </aside>
        
        <main class="admin-main">
            <header class="admin-header">
                <h1>ဝန်ဆောင်မှုများ စီမံခန့်ခွဲမှု</h1>
            </header>
            
            <div class="admin-content">
                <?php if ($success): ?>
                    <div class="alert alert-success">
                        <i class="fas fa-check-circle"></i>
                        <?php echo $success; ?>
                    </div>
                <?php endif; ?>
                
                <?php if ($error): ?>
                    <div class="alert alert-error">
                        <i class="fas fa-exclamation-circle"></i>
                        <?php echo $error; ?>
                    </div>
                <?php endif; ?>
                
                <!-- Add Service Form -->
                <div class="add-service-section">
                    <h2>ဝန်ဆောင်မှုအသစ် ထည့်ရန်</h2>
                    <form method="POST" class="admin-form">
                        <div class="form-row">
                            <div class="form-group">
                                <label for="service_type">ဝန်ဆောင်မှုအမျိုးအစား:</label>
                                <select id="service_type" name="service_type" class="form-control" required>
                                    <option value="">ရွေးချယ်ပါ</option>
                                    <?php foreach ($service_types as $type => $name): ?>
                                        <option value="<?php echo $type; ?>"><?php echo $name; ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="service_name">ဝန်ဆောင်မှုအမည်:</label>
                                <input type="text" id="service_name" name="service_name" class="form-control" required>
                            </div>
                        </div>
                        
                        <div class="form-row">
                            <div class="form-group">
                                <label for="price_mmk">စျေးနှုန်း (MMK):</label>
                                <input type="number" id="price_mmk" name="price_mmk" class="form-control" step="0.01" required>
                            </div>
                            <div class="form-group">
                                <label for="price_thb">စျေးနှုန်း (THB):</label>
                                <input type="number" id="price_thb" name="price_thb" class="form-control" step="0.01" required>
                            </div>
                        </div>
                        
                        <button type="submit" name="add_service" class="btn-primary">
                            <i class="fas fa-plus"></i> ဝန်ဆောင်မှု ထည့်ရန်
                        </button>
                    </form>
                </div>
                
                <!-- Services List -->
                <div class="services-list-section">
                    <h2>ဝန်ဆောင်မှုများ စာရင်း</h2>
                    
                    <?php foreach ($grouped_services as $type => $type_services): ?>
                        <div class="service-category">
                            <h3>
                                <i class="fas fa-<?php echo $type === 'mobile_topup_mm' || $type === 'mobile_topup_th' ? 'mobile-alt' : ($type === 'banking' ? 'university' : 'gamepad'); ?>"></i>
                                <?php echo $service_types[$type] ?? $type; ?>
                            </h3>
                            
                            <div class="services-table">
                                <table class="admin-table">
                                    <thead>
                                        <tr>
                                            <th>ID</th>
                                            <th>ဝန်ဆောင်မှုအမည်</th>
                                            <th>စျေးနှုန်း (MMK)</th>
                                            <th>စျေးနှုန်း (THB)</th>
                                            <th>အခြေအနေ</th>
                                            <th>ရက်စွဲ</th>
                                            <th>လုပ်ဆောင်ချက်</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($type_services as $service): ?>
                                        <tr>
                                            <td><?php echo $service['id']; ?></td>
                                            <td><?php echo htmlspecialchars($service['service_name']); ?></td>
                                            <td><?php echo formatCurrency($service['price_mmk'], 'MMK'); ?></td>
                                            <td><?php echo formatCurrency($service['price_thb'], 'THB'); ?></td>
                                            <td>
                                                <span class="status-badge <?php echo $service['is_active'] ? 'active' : 'inactive'; ?>">
                                                    <?php echo $service['is_active'] ? 'အသုံးပြုနေ' : 'ပိတ်ထား'; ?>
                                                </span>
                                            </td>
                                            <td><?php echo date('Y-m-d', strtotime($service['created_at'])); ?></td>
                                            <td>
                                                <div class="action-buttons">
                                                    <button class="btn-edit" onclick="editService(<?php echo htmlspecialchars(json_encode($service)); ?>)">
                                                        <i class="fas fa-edit"></i>
                                                    </button>
                                                    <form method="POST" style="display: inline;">
                                                        <input type="hidden" name="service_id" value="<?php echo $service['id']; ?>">
                                                        <button type="submit" name="delete_service" class="btn-delete" onclick="return confirm('ဤဝန်ဆောင်မှုကို ဖျက်မှာ သေချာပါသလား?')">
                                                            <i class="fas fa-trash"></i>
                                                        </button>
                                                    </form>
                                                </div>
                                            </td>
                                        </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </main>
    </div>

    <!-- Edit Service Modal -->
    <div id="edit-service-modal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="closeEditModal()">&times;</span>
            <h3>ဝန်ဆောင်မှု ပြင်ဆင်ရန်</h3>
            <form method="POST" id="edit-service-form">
                <input type="hidden" id="edit-service-id" name="service_id">
                
                <div class="form-group">
                    <label for="edit-service-name">ဝန်ဆောင်မှုအမည်:</label>
                    <input type="text" id="edit-service-name" name="service_name" class="form-control" required>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="edit-price-mmk">စျေးနှုန်း (MMK):</label>
                        <input type="number" id="edit-price-mmk" name="price_mmk" class="form-control" step="0.01" required>
                    </div>
                    <div class="form-group">
                        <label for="edit-price-thb">စျေးနှုန်း (THB):</label>
                        <input type="number" id="edit-price-thb" name="price_thb" class="form-control" step="0.01" required>
                    </div>
                </div>
                
                <div class="form-group">
                    <label>
                        <input type="checkbox" id="edit-is-active" name="is_active" value="1">
                        အသုံးပြုနေသည်
                    </label>
                </div>
                
                <button type="submit" name="update_service" class="btn-primary">
                    <i class="fas fa-save"></i> သိမ်းဆည်းရန်
                </button>
            </form>
        </div>
    </div>

    <script src="../assets/js/admin.js"></script>
    <script>
        function editService(service) {
            document.getElementById('edit-service-id').value = service.id;
            document.getElementById('edit-service-name').value = service.service_name;
            document.getElementById('edit-price-mmk').value = service.price_mmk;
            document.getElementById('edit-price-thb').value = service.price_thb;
            document.getElementById('edit-is-active').checked = service.is_active == 1;
            
            document.getElementById('edit-service-modal').style.display = 'block';
        }
        
        function closeEditModal() {
            document.getElementById('edit-service-modal').style.display = 'none';
        }
        
        // Close modal when clicking outside
        window.onclick = function(event) {
            const modal = document.getElementById('edit-service-modal');
            if (event.target === modal) {
                closeEditModal();
            }
        }
    </script>
</body>
</html>
