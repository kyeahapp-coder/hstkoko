<?php
require_once '../includes/functions.php';
require_once '../includes/backup.php';

if (!isAdmin()) {
    redirect('../login.php?admin=1');
}

$backupManager = new BackupManager();
$success = '';
$error = '';

// Handle backup actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['create_db_backup'])) {
        $result = $backupManager->createDatabaseBackup();
        if ($result['success']) {
            $success = 'Database backup ဖန်တီးပြီးပါပြီ: ' . $result['filename'];
        } else {
            $error = 'Backup ဖန်တီးရာတွင် အမှားတစ်ခု ဖြစ်ပွားခဲ့သည်: ' . $result['error'];
        }
    } elseif (isset($_POST['create_files_backup'])) {
        $result = $backupManager->createFilesBackup();
        if ($result['success']) {
            $success = 'Files backup ဖန်တီးပြီးပါပြီ: ' . $result['filename'];
        } else {
            $error = 'Backup ဖန်တီးရာတွင် အမှားတစ်ခု ဖြစ်ပွားခဲ့သည်: ' . $result['error'];
        }
    } elseif (isset($_POST['delete_backup'])) {
        $filename = $_POST['filename'];
        if ($backupManager->deleteBackup($filename)) {
            $success = 'Backup ဖျက်ပြီးပါပြီ';
        } else {
            $error = 'Backup ဖျက်ရာတွင် အမှားတစ်ခု ဖြစ်ပွားခဲ့သည်';
        }
    } elseif (isset($_POST['clean_old_backups'])) {
        $deleted = $backupManager->cleanOldBackups();
        $success = "ဟောင်းနွမ်းသော backup $deleted ခု ဖျက်ပြီးပါပြီ";
    }
}

$backups = $backupManager->getBackups();
?>

<!DOCTYPE html>
<html lang="my">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Backup - Admin Panel</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/admin.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body>
    <div class="admin-layout">
        <aside class="admin-sidebar">
            <div class="admin-brand">
                <h2><i class="fas fa-cog"></i> Admin Panel</h2>
            </div>
            <nav class="admin-nav">
                <a href="index.php"><i class="fas fa-dashboard"></i> Dashboard</a>
                <a href="images.php"><i class="fas fa-images"></i> ဓာတ်ပုံများ</a>
                <a href="orders.php"><i class="fas fa-shopping-bag"></i> အော်ဒါများ</a>
                <a href="users.php"><i class="fas fa-users"></i> အသုံးပြုသူများ</a>
                <a href="services.php"><i class="fas fa-concierge-bell"></i> ဝန်ဆောင်မှုများ</a>
                <a href="coupons.php"><i class="fas fa-tags"></i> ကူပွန်များ</a>
                <a href="backup.php" class="active"><i class="fas fa-database"></i> Backup</a>
                <a href="settings.php"><i class="fas fa-cog"></i> ဆက်တင်များ</a>
                <a href="../logout.php"><i class="fas fa-sign-out-alt"></i> ထွက်ရန်</a>
            </nav>
        </aside>
        
        <main class="admin-main">
            <header class="admin-header">
                <h1>Backup စီမံခန့်ခွဲမှု</h1>
            </header>
            
            <div class="admin-content">
                <?php if ($success): ?>
                    <div class="alert alert-success">
                        <i class="fas fa-check-circle"></i>
                        <?php echo $success; ?>
                    </div>
                <?php endif; ?>
                
                <?php if ($error): ?>
                    <div class="alert alert-error">
                        <i class="fas fa-exclamation-circle"></i>
                        <?php echo $error; ?>
                    </div>
                <?php endif; ?>
                
                <!-- Create Backup Section -->
                <div class="backup-actions">
                    <h2>Backup ဖန်တီးရန်</h2>
                    <div class="backup-buttons">
                        <form method="POST" style="display: inline;">
                            <button type="submit" name="create_db_backup" class="btn-primary">
                                <i class="fas fa-database"></i> Database Backup ဖန်တီးရန်
                            </button>
                        </form>
                        
                        <form method="POST" style="display: inline;">
                            <button type="submit" name="create_files_backup" class="btn-primary">
                                <i class="fas fa-folder"></i> Files Backup ဖန်တီးရန်
                            </button>
                        </form>
                        
                        <form method="POST" style="display: inline;">
                            <button type="submit" name="clean_old_backups" class="btn-secondary" onclick="return confirm('ဟောင်းနွမ်းသော backup များကို ဖျက်မှာ သေချာပါသလား?')">
                                <i class="fas fa-broom"></i> ဟောင်းနွမ်းသော Backup များ ရှင်းလင်းရန်
                            </button>
                        </form>
                    </div>
                </div>
                
                <!-- Backups List -->
                <div class="backups-list">
                    <h2>Backup များ စာရင်း</h2>
                    
                    <?php if (empty($backups)): ?>
                        <div class="no-backups">
                            <i class="fas fa-database"></i>
                            <h3>Backup များ မရှိသေးပါ</h3>
                            <p>Backup များ ဖန်တီးပါ</p>
                        </div>
                    <?php else: ?>
                        <div class="table-container">
                            <table class="admin-table">
                                <thead>
                                    <tr>
                                        <th>ဖိုင်အမည်</th>
                                        <th>အမျိုးအစား</th>
                                        <th>ဖိုင်အရွယ်အစား</th>
                                        <th>ဖန်တီးရက်စွဲ</th>
                                        <th>လုပ်ဆောင်ချက်</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($backups as $backup): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($backup['filename']); ?></td>
                                        <td>
                                            <span class="backup-type <?php echo $backup['type']; ?>">
                                                <i class="fas fa-<?php echo $backup['type'] === 'database' ? 'database' : 'folder'; ?>"></i>
                                                <?php echo $backup['type'] === 'database' ? 'Database' : 'Files'; ?>
                                            </span>
                                        </td>
                                        <td><?php echo $this->formatFileSize($backup['size']); ?></td>
                                        <td><?php echo date('Y-m-d H:i:s', $backup['created']); ?></td>
                                        <td>
                                            <div class="action-buttons">
                                                <a href="../<?php echo BACKUP_PATH . $backup['filename']; ?>" class="btn-view" download>
                                                    <i class="fas fa-download"></i>
                                                </a>
                                                
                                                <?php if ($backup['type'] === 'database'): ?>
                                                    <button class="btn-approve" onclick="restoreBackup('<?php echo $backup['filename']; ?>')" title="Restore">
                                                        <i class="fas fa-undo"></i>
                                                    </button>
                                                <?php endif; ?>
                                                
                                                <form method="POST" style="display: inline;">
                                                    <input type="hidden" name="filename" value="<?php echo $backup['filename']; ?>">
                                                    <button type="submit" name="delete_backup" class="btn-delete" onclick="return confirm('ဤ backup ကို ဖျက်မှာ သေချာပါသလား?')" title="Delete">
                                                        <i class="fas fa-trash"></i>
                                                    </button>
                                                </form>
                                            </div>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </main>
    </div>

    <script src="../assets/js/admin.js"></script>
    <script>
        function restoreBackup(filename) {
            if (!confirm('Database ကို restore လုပ်မှာ သေချာပါသလား? လက်ရှိ data များ ပျောက်သွားနိုင်ပါသည်!')) {
                return;
            }
            
            fetch('api/restore_backup.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ filename: filename })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    showAdminNotification('Database restore အောင်မြင်ပါသည်', 'success');
                    setTimeout(() => {
                        location.reload();
                    }, 2000);
                } else {
                    showAdminNotification('Restore လုပ်ရာတွင် အမှားတစ်ခု ဖြစ်ပွားခဲ့သည်: ' + data.error, 'error');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                showAdminNotification('အမှားတစ်ခု ဖြစ်ပွားခဲ့သည်', 'error');
            });
        }
    </script>
</body>
</html>

<?php
// Helper function for file size formatting
function formatFileSize($size) {
    $units = ['B', 'KB', 'MB', 'GB'];
    $unit = 0;
    
    while ($size >= 1024 && $unit < count($units) - 1) {
        $size /= 1024;
        $unit++;
    }
    
    return round($size, 2) . ' ' . $units[$unit];
}
?>
