<?php
require_once '../includes/functions.php';

if (!isAdmin()) {
    redirect('../login.php?admin=1');
}

$database = new Database();
$db = $database->getConnection();

$success = '';
$error = '';

// Handle user actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['ban_user'])) {
        $user_id = (int)$_POST['user_id'];
        $ban_query = "UPDATE users SET is_banned = 1 WHERE id = ?";
        $ban_stmt = $db->prepare($ban_query);
        if ($ban_stmt->execute([$user_id])) {
            $success = 'အသုံးပြုသူကို ပိတ်ပင်ပြီးပါပြီ';
        }
    } elseif (isset($_POST['unban_user'])) {
        $user_id = (int)$_POST['user_id'];
        $unban_query = "UPDATE users SET is_banned = 0 WHERE id = ?";
        $unban_stmt = $db->prepare($unban_query);
        if ($unban_stmt->execute([$user_id])) {
            $success = 'အသုံးပြုသူ ပိတ်ပင်မှုကို ဖြေလွှတ်ပြီးပါပြီ';
        }
    } elseif (isset($_POST['add_bonus'])) {
        $user_id = (int)$_POST['user_id'];
        $bonus_points = (int)$_POST['bonus_points'];
        $bonus_query = "UPDATE users SET bonus_points = bonus_points + ? WHERE id = ?";
        $bonus_stmt = $db->prepare($bonus_query);
        if ($bonus_stmt->execute([$bonus_points, $user_id])) {
            $success = 'ဘောနပ်ပွိုင့်များ ထည့်ပေးပြီးပါပြီ';
        }
    }
}

// Get all users
$users_query = "SELECT u.*, 
                (SELECT COUNT(*) FROM orders WHERE user_id = u.id) as total_orders,
                (SELECT SUM(CASE WHEN currency = 'MMK' THEN total_mmk ELSE total_thb * 40 END) FROM orders WHERE user_id = u.id AND admin_approved = 1) as total_spent
                FROM users u 
                ORDER BY u.created_at DESC";
$users_stmt = $db->prepare($users_query);
$users_stmt->execute();
$users = $users_stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="my">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>အသုံးပြုသူများ - Admin Panel</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/admin.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body>
    <div class="admin-layout">
        <aside class="admin-sidebar">
            <div class="admin-brand">
                <h2><i class="fas fa-cog"></i> Admin Panel</h2>
            </div>
            <nav class="admin-nav">
                <a href="index.php"><i class="fas fa-dashboard"></i> Dashboard</a>
                <a href="images.php"><i class="fas fa-images"></i> ဓာတ်ပုံများ</a>
                <a href="orders.php"><i class="fas fa-shopping-bag"></i> အော်ဒါများ</a>
                <a href="users.php" class="active"><i class="fas fa-users"></i> အသုံးပြုသူများ</a>
                <a href="services.php"><i class="fas fa-concierge-bell"></i> ဝန်ဆောင်မှုများ</a>
                <a href="settings.php"><i class="fas fa-cog"></i> ဆက်တင်များ</a>
                <a href="../logout.php"><i class="fas fa-sign-out-alt"></i> ထွက်ရန်</a>
            </nav>
        </aside>
        
        <main class="admin-main">
            <header class="admin-header">
                <h1>အသုံးပြုသူများ စီမံခန့်ခွဲမှု</h1>
            </header>
            
            <div class="admin-content">
                <?php if ($success): ?>
                    <div class="alert alert-success">
                        <i class="fas fa-check-circle"></i>
                        <?php echo $success; ?>
                    </div>
                <?php endif; ?>
                
                <div class="users-table-container">
                    <div class="table-container">
                        <table class="admin-table">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>အသုံးပြုသူအမည်</th>
                                    <th>အီးမေးလ်</th>
                                    <th>ဖုန်းနံပါတ်</th>
                                    <th>လက်ကျန်ငွေ</th>
                                    <th>ဘောနပ်</th>
                                    <th>အော်ဒါများ</th>
                                    <th>စုစုပေါင်းသုံးစွဲ</th>
                                    <th>အခြေအနေ</th>
                                    <th>ရက်စွဲ</th>
                                    <th>လုပ်ဆောင်ချက်</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($users as $user): ?>
                                <tr>
                                    <td><?php echo $user['id']; ?></td>
                                    <td><?php echo htmlspecialchars($user['username']); ?></td>
                                    <td><?php echo htmlspecialchars($user['email']); ?></td>
                                    <td><?php echo htmlspecialchars($user['phone'] ?: '-'); ?></td>
                                    <td>
                                        <div class="balance-display">
                                            <div><?php echo formatCurrency($user['balance_mmk'], 'MMK'); ?></div>
                                            <div><?php echo formatCurrency($user['balance_thb'], 'THB'); ?></div>
                                        </div>
                                    </td>
                                    <td><?php echo number_format($user['bonus_points']); ?></td>
                                    <td><?php echo $user['total_orders'] ?: 0; ?></td>
                                    <td><?php echo formatCurrency($user['total_spent'] ?: 0, 'MMK'); ?></td>
                                    <td>
                                        <span class="status-badge <?php echo $user['is_banned'] ? 'banned' : 'active'; ?>">
                                            <?php echo $user['is_banned'] ? 'ပိတ်ပင်ထား' : 'အသုံးပြုနေ'; ?>
                                        </span>
                                    </td>
                                    <td><?php echo date('Y-m-d', strtotime($user['created_at'])); ?></td>
                                    <td>
                                        <div class="action-buttons">
                                            <?php if ($user['is_banned']): ?>
                                                <form method="POST" style="display: inline;">
                                                    <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                                                    <button type="submit" name="unban_user" class="btn-approve" title="ပိတ်ပင်မှု ဖြေလွှတ်ရန်">
                                                        <i class="fas fa-unlock"></i>
                                                    </button>
                                                </form>
                                            <?php else: ?>
                                                <form method="POST" style="display: inline;">
                                                    <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                                                    <button type="submit" name="ban_user" class="btn-delete" title="ပိတ်ပင်ရန်" onclick="return confirm('ဤအသုံးပြုသူကို ပိတ်ပင်မှာ သေချာပါသလား?')">
                                                        <i class="fas fa-ban"></i>
                                                    </button>
                                                </form>
                                            <?php endif; ?>
                                            
                                            <button class="btn-view" onclick="showBonusModal(<?php echo $user['id']; ?>, '<?php echo htmlspecialchars($user['username']); ?>')" title="ဘောနပ် ထည့်ပေးရန်">
                                                <i class="fas fa-gift"></i>
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </main>
    </div>

    <!-- Bonus Modal -->
    <div id="bonus-modal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="closeBonusModal()">&times;</span>
            <h3>ဘောနပ်ပွိုင့် ထည့်ပေးရန်</h3>
            <form method="POST" id="bonus-form">
                <input type="hidden" id="bonus-user-id" name="user_id">
                <div class="form-group">
                    <label>အသုံးပြုသူ:</label>
                    <span id="bonus-username"></span>
                </div>
                <div class="form-group">
                    <label for="bonus_points">ဘောနပ်ပွိုင့်:</label>
                    <input type="number" id="bonus_points" name="bonus_points" class="form-control" min="1" required>
                </div>
                <button type="submit" name="add_bonus" class="btn-primary">
                    <i class="fas fa-gift"></i> ထည့်ပေးရန်
                </button>
            </form>
        </div>
    </div>

    <script src="../assets/js/admin.js"></script>
    <script>
        function showBonusModal(userId, username) {
            document.getElementById('bonus-user-id').value = userId;
            document.getElementById('bonus-username').textContent = username;
            document.getElementById('bonus-modal').style.display = 'block';
        }
        
        function closeBonusModal() {
            document.getElementById('bonus-modal').style.display = 'none';
            document.getElementById('bonus-form').reset();
        }
        
        // Close modal when clicking outside
        window.onclick = function(event) {
            const modal = document.getElementById('bonus-modal');
            if (event.target === modal) {
                closeBonusModal();
            }
        }
    </script>
</body>
</html>
