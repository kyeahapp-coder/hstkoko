<?php
require_once 'includes/functions.php';

if (isLoggedIn()) {
    redirect('index.php');
}

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username']);
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    $phone = trim($_POST['phone']);
    
    // Validation
    if (empty($username) || empty($email) || empty($password) || empty($confirm_password)) {
        $error = 'လိုအပ်သော အချက်အလက်များ ဖြည့်စွက်ပါ';
    } elseif ($password !== $confirm_password) {
        $error = 'စကားဝှက်များ မတူညီပါ';
    } elseif (strlen($password) < 6) {
        $error = 'စကားဝှက်သည် အနည်းဆုံး ၆လုံး ရှိရပါမည်';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'အီးမေးလ် ပုံစံမှားယွင်းနေပါသည်';
    } else {
        $database = new Database();
        $db = $database->getConnection();
        
        // Check if username or email already exists
        $check_query = "SELECT id FROM users WHERE username = ? OR email = ?";
        $check_stmt = $db->prepare($check_query);
        $check_stmt->execute([$username, $email]);
        
        if ($check_stmt->fetch()) {
            $error = 'အသုံးပြုသူအမည် သို့မဟုတ် အီးမေးလ် ရှိနေပြီးဖြစ်ပါသည်';
        } else {
            // Create new user
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            $insert_query = "INSERT INTO users (username, email, password, phone) VALUES (?, ?, ?, ?)";
            $insert_stmt = $db->prepare($insert_query);
            
            if ($insert_stmt->execute([$username, $email, $hashed_password, $phone])) {
                $success = 'အကောင့်ဖွင့်ခြင်း အောင်မြင်ပါသည်။ ယခု ဝင်ရောက်နိုင်ပါပြီ။';
            } else {
                $error = 'အကောင့်ဖွင့်ရာတွင် အမှားတစ်ခု ဖြစ်ပွားခဲ့သည်';
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="my">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>စာရင်းသွင်းရန် - Infinity Server</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body>
    <div class="login-container">
        <div class="form-container">
            <div class="login-header">
                <img src="<?php echo getSetting('site_logo'); ?>" alt="Logo" class="logo">
                <h2>အကောင့်ဖွင့်ရန်</h2>
            </div>
            
            <?php if ($error): ?>
                <div class="alert alert-error">
                    <i class="fas fa-exclamation-circle"></i>
                    <?php echo $error; ?>
                </div>
            <?php endif; ?>
            
            <?php if ($success): ?>
                <div class="alert alert-success">
                    <i class="fas fa-check-circle"></i>
                    <?php echo $success; ?>
                </div>
            <?php endif; ?>
            
            <form method="POST" class="login-form">
                <div class="form-group">
                    <label for="username">
                        <i class="fas fa-user"></i>
                        အသုံးပြုသူအမည်
                    </label>
                    <input type="text" id="username" name="username" class="form-control" required value="<?php echo htmlspecialchars($_POST['username'] ?? ''); ?>">
                </div>
                
                <div class="form-group">
                    <label for="email">
                        <i class="fas fa-envelope"></i>
                        အီးမေးလ်
                    </label>
                    <input type="email" id="email" name="email" class="form-control" required value="<?php echo htmlspecialchars($_POST['email'] ?? ''); ?>">
                </div>
                
                <div class="form-group">
                    <label for="phone">
                        <i class="fas fa-phone"></i>
                        ဖုန်းနံပါတ် (ရွေးချယ်ခွင့်ရှိသော)
                    </label>
                    <input type="tel" id="phone" name="phone" class="form-control" value="<?php echo htmlspecialchars($_POST['phone'] ?? ''); ?>">
                </div>
                
                <div class="form-group">
                    <label for="password">
                        <i class="fas fa-lock"></i>
                        စကားဝှက်
                    </label>
                    <input type="password" id="password" name="password" class="form-control" required>
                </div>
                
                <div class="form-group">
                    <label for="confirm_password">
                        <i class="fas fa-lock"></i>
                        စကားဝှက် အတည်ပြုရန်
                    </label>
                    <input type="password" id="confirm_password" name="confirm_password" class="form-control" required>
                </div>
                
                <button type="submit" class="btn-primary login-btn">
                    <i class="fas fa-user-plus"></i>
                    အကောင့်ဖွင့်ရန်
                </button>
            </form>
            
            <div class="login-footer">
                <p>အကောင့်ရှိနေပြီးလား? <a href="login.php">ဝင်ရန်</a></p>
            </div>
        </div>
    </div>
    
    <script src="assets/js/main.js"></script>
</body>
</html>
