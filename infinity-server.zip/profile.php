<?php
session_start();
require_once 'config/database.php';
require_once 'includes/functions.php';
require_once 'includes/security.php';

requireLogin();

$user_id = $_SESSION['user_id'];
$message = '';
$error = '';

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['update_profile'])) {
        // Update profile
        $first_name = sanitizeInput($_POST['first_name']);
        $last_name = sanitizeInput($_POST['last_name']);
        $email = sanitizeInput($_POST['email']);
        $phone = sanitizeInput($_POST['phone']);
        $address = sanitizeInput($_POST['address']);
        $city = sanitizeInput($_POST['city']);
        $country = sanitizeInput($_POST['country']);
        
        // Validate email
        if (!validateEmail($email)) {
            $error = 'Please enter a valid email address';
        } else {
            // Check if email is already taken by another user
            $stmt = $conn->prepare("SELECT id FROM users WHERE email = ? AND id != ?");
            $stmt->bind_param("si", $email, $user_id);
            $stmt->execute();
            $result = $stmt->get_result();
            
            if ($result->num_rows > 0) {
                $error = 'Email address is already taken';
            } else {
                // Update user profile
                $stmt = $conn->prepare("UPDATE users SET first_name = ?, last_name = ?, email = ?, phone = ?, address = ?, city = ?, country = ?, updated_at = NOW() WHERE id = ?");
                $stmt->bind_param("sssssssi", $first_name, $last_name, $email, $phone, $address, $city, $country, $user_id);
                
                if ($stmt->execute()) {
                    $message = 'Profile updated successfully';
                    $_SESSION['username'] = $first_name . ' ' . $last_name;
                } else {
                    $error = 'Failed to update profile';
                }
            }
        }
    } elseif (isset($_POST['change_password'])) {
        // Change password
        $current_password = $_POST['current_password'];
        $new_password = $_POST['new_password'];
        $confirm_password = $_POST['confirm_password'];
        
        if (strlen($new_password) < 6) {
            $error = 'New password must be at least 6 characters long';
        } elseif ($new_password !== $confirm_password) {
            $error = 'New passwords do not match';
        } else {
            // Verify current password
            $stmt = $conn->prepare("SELECT password FROM users WHERE id = ?");
            $stmt->bind_param("i", $user_id);
            $stmt->execute();
            $result = $stmt->get_result();
            $user = $result->fetch_assoc();
            
            if (verifyPassword($current_password, $user['password'])) {
                // Update password
                $hashed_password = hashPassword($new_password);
                $stmt = $conn->prepare("UPDATE users SET password = ?, updated_at = NOW() WHERE id = ?");
                $stmt->bind_param("si", $hashed_password, $user_id);
                
                if ($stmt->execute()) {
                    $message = 'Password changed successfully';
                } else {
                    $error = 'Failed to change password';
                }
            } else {
                $error = 'Current password is incorrect';
            }
        }
    }
}

// Get user data
$stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();

// Get user statistics
$stmt = $conn->prepare("SELECT COUNT(*) as order_count FROM orders WHERE user_id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$order_count = $stmt->get_result()->fetch_assoc()['order_count'];

$stmt = $conn->prepare("SELECT COUNT(*) as cart_count FROM cart WHERE user_id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$cart_count = $stmt->get_result()->fetch_assoc()['cart_count'];

$stmt = $conn->prepare("SELECT COUNT(*) as wishlist_count FROM wishlist WHERE user_id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$wishlist_count = $stmt->get_result()->fetch_assoc()['wishlist_count'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile - Infinity Gallery</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/profile.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
    <?php include 'includes/header.php'; ?>

    <div class="profile-container">
        <div class="profile-content">
            <h1><i class="fas fa-user"></i> My Profile</h1>
            
            <?php if ($message): ?>
                <div class="alert alert-success">
                    <i class="fas fa-check-circle"></i>
                    <?php echo $message; ?>
                </div>
            <?php endif; ?>
            
            <?php if ($error): ?>
                <div class="alert alert-error">
                    <i class="fas fa-exclamation-circle"></i>
                    <?php echo $error; ?>
                </div>
            <?php endif; ?>
            
            <div class="profile-grid">
                <!-- Profile Stats -->
                <div class="profile-stats">
                    <h2>Account Overview</h2>
                    <div class="stats-grid">
                        <div class="stat-card">
                            <div class="stat-icon">
                                <i class="fas fa-shopping-bag"></i>
                            </div>
                            <div class="stat-info">
                                <h3><?php echo $order_count; ?></h3>
                                <p>Total Orders</p>
                            </div>
                        </div>
                        
                        <div class="stat-card">
                            <div class="stat-icon">
                                <i class="fas fa-shopping-cart"></i>
                            </div>
                            <div class="stat-info">
                                <h3><?php echo $cart_count; ?></h3>
                                <p>Items in Cart</p>
                            </div>
                        </div>
                        
                        <div class="stat-card">
                            <div class="stat-icon">
                                <i class="fas fa-heart"></i>
                            </div>
                            <div class="stat-info">
                                <h3><?php echo $wishlist_count; ?></h3>
                                <p>Wishlist Items</p>
                            </div>
                        </div>
                    </div>
                    
                    <div class="account-info">
                        <h3>Account Information</h3>
                        <p><strong>Member Since:</strong> <?php echo date('F j, Y', strtotime($user['created_at'])); ?></p>
                        <p><strong>Last Updated:</strong> <?php echo date('F j, Y', strtotime($user['updated_at'])); ?></p>
                        <p><strong>Account Status:</strong> 
                            <span class="status-badge <?php echo $user['status']; ?>">
                                <?php echo ucfirst($user['status']); ?>
                            </span>
                        </p>
                    </div>
                </div>

                <!-- Profile Forms -->
                <div class="profile-forms">
                    <!-- Update Profile Form -->
                    <div class="form-section">
                        <h2>Update Profile</h2>
                        <form method="POST" class="profile-form">
                            <input type="hidden" name="csrf_token" value="<?php echo generateCSRFToken(); ?>">
                            
                            <div class="form-grid">
                                <div class="form-group">
                                    <label for="first_name">First Name *</label>
                                    <input type="text" id="first_name" name="first_name" 
                                           value="<?php echo sanitizeOutput($user['first_name']); ?>" required>
                                </div>
                                
                                <div class="form-group">
                                    <label for="last_name">Last Name *</label>
                                    <input type="text" id="last_name" name="last_name" 
                                           value="<?php echo sanitizeOutput($user['last_name']); ?>" required>
                                </div>
                                
                                <div class="form-group full-width">
                                    <label for="email">Email Address *</label>
                                    <input type="email" id="email" name="email" 
                                           value="<?php echo sanitizeOutput($user['email']); ?>" required>
                                </div>
                                
                                <div class="form-group full-width">
                                    <label for="phone">Phone Number</label>
                                    <input type="tel" id="phone" name="phone" 
                                           value="<?php echo sanitizeOutput($user['phone']); ?>">
                                </div>
                                
                                <div class="form-group full-width">
                                    <label for="address">Address</label>
                                    <textarea id="address" name="address" rows="3"><?php echo sanitizeOutput($user['address']); ?></textarea>
                                </div>
                                
                                <div class="form-group">
                                    <label for="city">City</label>
                                    <input type="text" id="city" name="city" 
                                           value="<?php echo sanitizeOutput($user['city']); ?>">
                                </div>
                                
                                <div class="form-group">
                                    <label for="country">Country</label>
                                    <select id="country" name="country">
                                        <option value="">Select Country</option>
                                        <option value="MM" <?php echo $user['country'] === 'MM' ? 'selected' : ''; ?>>Myanmar</option>
                                        <option value="TH" <?php echo $user['country'] === 'TH' ? 'selected' : ''; ?>>Thailand</option>
                                        <option value="US" <?php echo $user['country'] === 'US' ? 'selected' : ''; ?>>United States</option>
                                        <option value="GB" <?php echo $user['country'] === 'GB' ? 'selected' : ''; ?>>United Kingdom</option>
                                    </select>
                                </div>
                            </div>
                            
                            <button type="submit" name="update_profile" class="btn-primary">
                                <i class="fas fa-save"></i> Update Profile
                            </button>
                        </form>
                    </div>

                    <!-- Change Password Form -->
                    <div class="form-section">
                        <h2>Change Password</h2>
                        <form method="POST" class="profile-form">
                            <input type="hidden" name="csrf_token" value="<?php echo generateCSRFToken(); ?>">
                            
                            <div class="form-group">
                                <label for="current_password">Current Password *</label>
                                <input type="password" id="current_password" name="current_password" required>
                            </div>
                            
                            <div class="form-group">
                                <label for="new_password">New Password *</label>
                                <input type="password" id="new_password" name="new_password" 
                                       minlength="6" required>
                                <small>Password must be at least 6 characters long</small>
                            </div>
                            
                            <div class="form-group">
                                <label for="confirm_password">Confirm New Password *</label>
                                <input type="password" id="confirm_password" name="confirm_password" 
                                       minlength="6" required>
                            </div>
                            
                            <button type="submit" name="change_password" class="btn-secondary">
                                <i class="fas fa-key"></i> Change Password
                            </button>
                        </form>
                    </div>
                </div>
            </div>
            
            <!-- Quick Actions -->
            <div class="quick-actions">
                <h2>Quick Actions</h2>
                <div class="actions-grid">
                    <a href="orders.php" class="action-card">
                        <i class="fas fa-shopping-bag"></i>
                        <h3>View Orders</h3>
                        <p>Check your order history and status</p>
                    </a>
                    
                    <a href="cart.php" class="action-card">
                        <i class="fas fa-shopping-cart"></i>
                        <h3>Shopping Cart</h3>
                        <p>Review items in your cart</p>
                    </a>
                    
                    <a href="wishlist.php" class="action-card">
                        <i class="fas fa-heart"></i>
                        <h3>Wishlist</h3>
                        <p>View your saved items</p>
                    </a>
                    
                    <a href="index.php" class="action-card">
                        <i class="fas fa-images"></i>
                        <h3>Browse Gallery</h3>
                        <p>Explore our image collection</p>
                    </a>
                </div>
            </div>
        </div>
    </div>

    <?php include 'includes/footer.php'; ?>

    <script src="assets/js/profile.js"></script>
</body>
</html>
