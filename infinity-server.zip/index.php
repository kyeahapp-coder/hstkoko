<?php
require_once 'includes/functions.php';

$database = new Database();
$db = $database->getConnection();

// Get page parameters
$page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
$category = isset($_GET['category']) ? Security::sanitizeInput($_GET['category']) : '';
$search = isset($_GET['search']) ? Security::sanitizeInput($_GET['search']) : '';

// Get images per page setting
$per_page = getSetting('images_per_page', 12);

// Get images based on filters
if (!empty($search)) {
    $images = searchImages($search, $category, 0, 0, $page, $per_page);
    $page_title = "Search Results for: $search";
} elseif (!empty($category)) {
    $images = searchImages('', $category, 0, 0, $page, $per_page);
    $page_title = "Category: $category";
} else {
    $images = getRecentImages($per_page);
    $page_title = "Latest Images";
}

// Get featured images for homepage
$featured_images = getFeaturedImages(8);

// Get popular images
$popular_images = getPopularImages(6);

// Get categories
$categories = getImageCategories();

// Get cart count
$cart_count = getCartCount();

// Get notification count
$notification_count = getNotificationCount();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?> - <?php echo getSetting('site_name', 'Infinity Server'); ?></title>
    <meta name="description" content="<?php echo getSetting('site_description', 'Premium digital marketplace'); ?>">
    <link rel="stylesheet" href="assets/css/style.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body>
    <!-- Header -->
    <header class="header">
        <div class="container">
            <div class="header-content">
                <div class="logo">
                    <a href="index.php">
                        <h1><?php echo getSetting('site_name', 'Infinity Server'); ?></h1>
                    </a>
                </div>
                
                <nav class="nav">
                    <a href="index.php" class="nav-link active">Home</a>
                    <a href="services.php" class="nav-link">Services</a>
                    <?php if (isLoggedIn()): ?>
                        <a href="profile.php" class="nav-link">Profile</a>
                        <a href="orders.php" class="nav-link">Orders</a>
                    <?php endif; ?>
                </nav>
                
                <div class="header-actions">
                    <!-- Search -->
                    <div class="search-box">
                        <form method="GET" action="index.php">
                            <input type="text" name="search" placeholder="Search images..." value="<?php echo htmlspecialchars($search); ?>">
                            <button type="submit"><i class="fas fa-search"></i></button>
                        </form>
                    </div>
                    
                    <!-- Cart -->
                    <a href="cart.php" class="cart-btn">
                        <i class="fas fa-shopping-cart"></i>
                        <?php if ($cart_count > 0): ?>
                            <span class="cart-count"><?php echo $cart_count; ?></span>
                        <?php endif; ?>
                    </a>
                    
                    <!-- User Menu -->
                    <?php if (isLoggedIn()): ?>
                        <div class="user-menu">
                            <button class="user-btn">
                                <i class="fas fa-user"></i>
                                <?php if ($notification_count > 0): ?>
                                    <span class="notification-badge"><?php echo $notification_count; ?></span>
                                <?php endif; ?>
                            </button>
                            <div class="user-dropdown">
                                <a href="profile.php"><i class="fas fa-user"></i> Profile</a>
                                <a href="orders.php"><i class="fas fa-shopping-bag"></i> Orders</a>
                                <a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
                            </div>
                        </div>
                    <?php else: ?>
                        <div class="auth-buttons">
                            <a href="login.php" class="btn-secondary">Login</a>
                            <a href="register.php" class="btn-primary">Register</a>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </header>

    <!-- Hero Section (only on homepage) -->
    <?php if (empty($search) && empty($category) && $page == 1): ?>
    <section class="hero">
        <div class="container">
            <div class="hero-content">
                <h2>Premium Stock Photos & Digital Services</h2>
                <p>Discover thousands of high-quality images and professional digital services</p>
                <div class="hero-search">
                    <form method="GET" action="index.php">
                        <input type="text" name="search" placeholder="What are you looking for?">
                        <button type="submit" class="btn-primary">Search</button>
                    </form>
                </div>
            </div>
        </div>
    </section>
    <?php endif; ?>

    <!-- Main Content -->
    <main class="main">
        <div class="container">
            <div class="content-wrapper">
                <!-- Sidebar -->
                <aside class="sidebar">
                    <div class="sidebar-section">
                        <h3>Categories</h3>
                        <ul class="category-list">
                            <li><a href="index.php" class="<?php echo empty($category) ? 'active' : ''; ?>">All Categories</a></li>
                            <?php foreach ($categories as $cat): ?>
                                <li>
                                    <a href="index.php?category=<?php echo urlencode($cat['category']); ?>" 
                                       class="<?php echo $category === $cat['category'] ? 'active' : ''; ?>">
                                        <?php echo htmlspecialchars($cat['category']); ?>
                                        <span class="count">(<?php echo $cat['count']; ?>)</span>
                                    </a>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                    
                    <?php if (!empty($popular_images)): ?>
                    <div class="sidebar-section">
                        <h3>Popular Images</h3>
                        <div class="popular-images">
                            <?php foreach ($popular_images as $img): ?>
                                <div class="popular-item">
                                    <a href="image_details.php?id=<?php echo $img['id']; ?>">
                                        <img src="<?php echo $img['thumbnail_path'] ?: $img['file_path']; ?>" 
                                             alt="<?php echo htmlspecialchars($img['title']); ?>">
                                        <div class="popular-info">
                                            <h4><?php echo htmlspecialchars($img['title']); ?></h4>
                                            <p><?php echo formatCurrency($img['price_mmk']); ?></p>
                                        </div>
                                    </a>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                    <?php endif; ?>
                </aside>

                <!-- Content Area -->
                <div class="content-area">
                    <!-- Featured Images (only on homepage) -->
                    <?php if (empty($search) && empty($category) && $page == 1 && !empty($featured_images)): ?>
                    <section class="featured-section">
                        <h2>Featured Images</h2>
                        <div class="featured-grid">
                            <?php foreach ($featured_images as $img): ?>
                                <div class="featured-item">
                                    <a href="image_details.php?id=<?php echo $img['id']; ?>">
                                        <img src="<?php echo $img['thumbnail_path'] ?: $img['file_path']; ?>" 
                                             alt="<?php echo htmlspecialchars($img['title']); ?>">
                                        <div class="featured-overlay">
                                            <h3><?php echo htmlspecialchars($img['title']); ?></h3>
                                            <p><?php echo formatCurrency($img['price_mmk']); ?></p>
                                        </div>
                                    </a>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </section>
                    <?php endif; ?>

                    <!-- Images Grid -->
                    <section class="images-section">
                        <div class="section-header">
                            <h2><?php echo $page_title; ?></h2>
                            <div class="view-options">
                                <button class="view-btn active" data-view="grid"><i class="fas fa-th"></i></button>
                                <button class="view-btn" data-view="list"><i class="fas fa-list"></i></button>
                            </div>
                        </div>

                        <?php if (!empty($images)): ?>
                            <div class="images-grid" id="images-container">
                                <?php foreach ($images as $image): ?>
                                    <div class="image-card">
                                        <div class="image-wrapper">
                                            <a href="image_details.php?id=<?php echo $image['id']; ?>">
                                                <img src="<?php echo $image['thumbnail_path'] ?: $image['file_path']; ?>" 
                                                     alt="<?php echo htmlspecialchars($image['title']); ?>"
                                                     loading="lazy">
                                            </a>
                                            <div class="image-overlay">
                                                <button class="btn-icon" onclick="addToCart(<?php echo $image['id']; ?>)">
                                                    <i class="fas fa-cart-plus"></i>
                                                </button>
                                                <button class="btn-icon" onclick="toggleWishlist(<?php echo $image['id']; ?>)">
                                                    <i class="fas fa-heart"></i>
                                                </button>
                                            </div>
                                        </div>
                                        <div class="image-info">
                                            <h3><a href="image_details.php?id=<?php echo $image['id']; ?>"><?php echo htmlspecialchars($image['title']); ?></a></h3>
                                            <p class="image-category"><?php echo htmlspecialchars($image['category']); ?></p>
                                            <div class="image-stats">
                                                <span><i class="fas fa-eye"></i> <?php echo number_format($image['views']); ?></span>
                                                <span><i class="fas fa-download"></i> <?php echo number_format($image['downloads']); ?></span>
                                            </div>
                                            <div class="image-price">
                                                <?php if ($image['is_free']): ?>
                                                    <span class="price-free">Free</span>
                                                <?php else: ?>
                                                    <span class="price-mmk"><?php echo formatCurrency($image['price_mmk']); ?></span>
                                                    <span class="price-thb"><?php echo formatCurrency($image['price_thb'], 'THB'); ?></span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>

                            <!-- Pagination -->
                            <div class="pagination-wrapper">
                                <?php
                                $base_url = 'index.php';
                                $query_params = [];
                                if (!empty($search)) $query_params['search'] = $search;
                                if (!empty($category)) $query_params['category'] = $category;
                                
                                if (!empty($query_params)) {
                                    $base_url .= '?' . http_build_query($query_params);
                                    $base_url .= '&';
                                } else {
                                    $base_url .= '?';
                                }
                                
                                // For simplicity, assuming we have total count
                                $total_images = 100; // This should be calculated based on actual query
                                echo paginate($total_images, $per_page, $page, rtrim($base_url, '?&'));
                                ?>
                            </div>
                        <?php else: ?>
                            <div class="no-results">
                                <i class="fas fa-search"></i>
                                <h3>No images found</h3>
                                <p>Try adjusting your search criteria or browse our categories.</p>
                                <a href="index.php" class="btn-primary">Browse All Images</a>
                            </div>
                        <?php endif; ?>
                    </section>
                </div>
            </div>
        </div>
    </main>

    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <div class="footer-content">
                <div class="footer-section">
                    <h3><?php echo getSetting('site_name', 'Infinity Server'); ?></h3>
                    <p><?php echo getSetting('site_description', 'Premium digital marketplace'); ?></p>
                    <div class="social-links">
                        <a href="#"><i class="fab fa-facebook"></i></a>
                        <a href="#"><i class="fab fa-twitter"></i></a>
                        <a href="#"><i class="fab fa-instagram"></i></a>
                    </div>
                </div>
                <div class="footer-section">
                    <h4>Quick Links</h4>
                    <ul>
                        <li><a href="index.php">Home</a></li>
                        <li><a href="services.php">Services</a></li>
                        <li><a href="about.php">About</a></li>
                        <li><a href="contact.php">Contact</a></li>
                    </ul>
                </div>
                <div class="footer-section">
                    <h4>Support</h4>
                    <ul>
                        <li><a href="help.php">Help Center</a></li>
                        <li><a href="terms.php">Terms of Service</a></li>
                        <li><a href="privacy.php">Privacy Policy</a></li>
                    </ul>
                </div>
                <div class="footer-section">
                    <h4>Contact Info</h4>
                    <p><i class="fas fa-envelope"></i> <?php echo getSetting('contact_email', 'contact@infinityserver.com'); ?></p>
                    <p><i class="fas fa-phone"></i> <?php echo getSetting('contact_phone', '+95912345678'); ?></p>
                </div>
            </div>
            <div class="footer-bottom">
                <p>&copy; <?php echo date('Y'); ?> <?php echo getSetting('site_name', 'Infinity Server'); ?>. All rights reserved.</p>
            </div>
        </div>
    </footer>

    <!-- Scripts -->
    <script src="assets/js/main.js"></script>
    <script>
        // Add to cart function
        function addToCart(imageId) {
            <?php if (!isLoggedIn()): ?>
                window.location.href = 'login.php';
                return;
            <?php endif; ?>
            
            fetch('api/add_to_cart.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    image_id: imageId,
                    quantity: 1
                })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    showNotification('Added to cart successfully!', 'success');
                    updateCartCount();
                } else {
                    showNotification(data.message || 'Failed to add to cart', 'error');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                showNotification('An error occurred', 'error');
            });
        }

        // Toggle wishlist function
        function toggleWishlist(imageId) {
            <?php if (!isLoggedIn()): ?>
                window.location.href = 'login.php';
                return;
            <?php endif; ?>
            
            fetch('api/toggle_wishlist.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    image_id: imageId
                })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    showNotification(data.message, 'success');
                } else {
                    showNotification(data.message || 'Failed to update wishlist', 'error');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                showNotification('An error occurred', 'error');
            });
        }
    </script>
</body>
</html>
