<?php
require_once 'includes/functions.php';

if (isLoggedIn()) {
    redirect('index.php');
}

$message = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email']);
    
    if (empty($email)) {
        $error = 'အီးမေးလ် ဖြည့်စွက်ပါ';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'အီးမေးလ် ပုံစံမှားယွင်းနေပါသည်';
    } else {
        $database = new Database();
        $db = $database->getConnection();
        
        // Check if email exists
        $query = "SELECT id, username FROM users WHERE email = ?";
        $stmt = $db->prepare($query);
        $stmt->execute([$email]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($user) {
            // Generate reset token
            $reset_token = bin2hex(random_bytes(32));
            $expires_at = date('Y-m-d H:i:s', strtotime('+1 hour'));
            
            // Store reset token
            $token_query = "INSERT INTO password_resets (user_id, token, expires_at) VALUES (?, ?, ?) 
                           ON DUPLICATE KEY UPDATE token = ?, expires_at = ?";
            $token_stmt = $db->prepare($token_query);
            $token_stmt->execute([$user['id'], $reset_token, $expires_at, $reset_token, $expires_at]);
            
            // In a real application, you would send an email here
            // For demo purposes, we'll just show a success message
            $message = 'စကားဝှက်ပြန်လည်သတ်မှတ်ရန် လင့်ခ်ကို သင့်အီးမေးလ်သို့ ပို့ပြီးပါပြီ';
        } else {
            $error = 'ဤအီးမေးလ်ဖြင့် အကောင့်မရှိပါ';
        }
    }
}
?>

<!DOCTYPE html>
<html lang="my">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>စကားဝှက်မေ့နေပါသလား - Infinity Server</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/login.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body>
    <div class="login-container">
        <div class="form-container">
            <div class="login-header">
                <img src="<?php echo getSetting('site_logo'); ?>" alt="Logo" class="logo">
                <h2>စကားဝှက်မေ့နေပါသလား</h2>
                <p>သင့်အီးမေးလ်လိပ်စာကို ထည့်ပါ။ စကားဝှက်ပြန်လည်သတ်မှတ်ရန် လင့်ခ်ကို ပို့ပေးပါမည်။</p>
            </div>
            
            <?php if ($error): ?>
                <div class="alert alert-error">
                    <i class="fas fa-exclamation-circle"></i>
                    <?php echo $error; ?>
                </div>
            <?php endif; ?>
            
            <?php if ($message): ?>
                <div class="alert alert-success">
                    <i class="fas fa-check-circle"></i>
                    <?php echo $message; ?>
                </div>
            <?php endif; ?>
            
            <form method="POST" class="login-form">
                <div class="form-group">
                    <label for="email">
                        <i class="fas fa-envelope"></i>
                        အီးမေးလ်လိပ်စာ
                    </label>
                    <input type="email" id="email" name="email" class="form-control" required value="<?php echo htmlspecialchars($_POST['email'] ?? ''); ?>">
                </div>
                
                <button type="submit" class="btn-primary login-btn">
                    <i class="fas fa-paper-plane"></i>
                    ပြန်လည်သတ်မှတ်ရန် လင့်ခ် ပို့ရန်
                </button>
            </form>
            
            <div class="login-footer">
                <p><a href="login.php">← ဝင်ရောက်ရန်သို့ ပြန်သွားရန်</a></p>
            </div>
        </div>
    </div>
    
    <script src="assets/js/main.js"></script>
</body>
</html>
