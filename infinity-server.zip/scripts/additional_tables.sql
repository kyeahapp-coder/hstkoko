-- Login attempts table for security
CREATE TABLE IF NOT EXISTS login_attempts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    identifier VARCHAR(255) NOT NULL,
    success BOOLEAN DEFAULT FALSE,
    ip_address VARCHAR(45),
    user_agent TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_identifier_time (identifier, created_at),
    INDEX idx_ip_time (ip_address, created_at)
);

-- System logs table
CREATE TABLE IF NOT EXISTS system_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    level VARCHAR(20) NOT NULL,
    message TEXT NOT NULL,
    context JSON,
    user_id INT NULL,
    ip_address VARCHAR(45),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL,
    INDEX idx_level_time (level, created_at),
    INDEX idx_user_time (user_id, created_at)
);

-- File uploads tracking
CREATE TABLE IF NOT EXISTS file_uploads (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    original_filename VARCHAR(255) NOT NULL,
    stored_filename VARCHAR(255) NOT NULL,
    file_path VARCHAR(500) NOT NULL,
    file_size INT NOT NULL,
    mime_type VARCHAR(100) NOT NULL,
    upload_status VARCHAR(20) DEFAULT 'completed',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_user_status (user_id, upload_status),
    INDEX idx_created (created_at)
);

-- Categories table for images
CREATE TABLE IF NOT EXISTS categories (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    slug VARCHAR(100) UNIQUE NOT NULL,
    description TEXT,
    is_active BOOLEAN DEFAULT TRUE,
    sort_order INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Image categories relationship
CREATE TABLE IF NOT EXISTS image_categories (
    id INT AUTO_INCREMENT PRIMARY KEY,
    image_id INT NOT NULL,
    category_id INT NOT NULL,
    FOREIGN KEY (image_id) REFERENCES images(id) ON DELETE CASCADE,
    FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE CASCADE,
    UNIQUE KEY unique_image_category (image_id, category_id)
);

-- User sessions table
CREATE TABLE IF NOT EXISTS user_sessions (
    id VARCHAR(128) PRIMARY KEY,
    user_id INT,
    ip_address VARCHAR(45),
    user_agent TEXT,
    last_activity TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_user_activity (user_id, last_activity),
    INDEX idx_last_activity (last_activity)
);

-- Coupons/Discount codes table
CREATE TABLE IF NOT EXISTS coupons (
    id INT AUTO_INCREMENT PRIMARY KEY,
    code VARCHAR(50) UNIQUE NOT NULL,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    type ENUM('percentage', 'fixed') NOT NULL,
    value DECIMAL(10,2) NOT NULL,
    minimum_amount DECIMAL(10,2) DEFAULT 0,
    maximum_discount DECIMAL(10,2) DEFAULT NULL,
    usage_limit INT DEFAULT NULL,
    used_count INT DEFAULT 0,
    user_limit INT DEFAULT 1,
    is_active BOOLEAN DEFAULT TRUE,
    starts_at DATETIME,
    expires_at DATETIME,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_code (code),
    INDEX idx_is_active (is_active),
    INDEX idx_expires_at (expires_at)
);

-- Coupon usage tracking
CREATE TABLE IF NOT EXISTS coupon_usage (
    id INT AUTO_INCREMENT PRIMARY KEY,
    coupon_id INT NOT NULL,
    user_id INT NOT NULL,
    order_id INT NOT NULL,
    discount_amount DECIMAL(10,2) NOT NULL,
    used_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (coupon_id) REFERENCES coupons(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
    INDEX idx_coupon_id (coupon_id),
    INDEX idx_user_id (user_id),
    INDEX idx_order_id (order_id)
);

-- Reviews table
CREATE TABLE IF NOT EXISTS reviews (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    image_id INT NOT NULL,
    rating INT NOT NULL CHECK (rating >= 1 AND rating <= 5),
    comment TEXT,
    is_approved BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (image_id) REFERENCES images(id) ON DELETE CASCADE,
    UNIQUE KEY unique_user_image_review (user_id, image_id),
    INDEX idx_image_id (image_id),
    INDEX idx_rating (rating),
    INDEX idx_is_approved (is_approved)
);

-- Wishlist table
CREATE TABLE IF NOT EXISTS wishlist (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    image_id INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (image_id) REFERENCES images(id) ON DELETE CASCADE,
    UNIQUE KEY unique_user_image (user_id, image_id),
    INDEX idx_user_id (user_id)
);

-- Download history
CREATE TABLE IF NOT EXISTS download_history (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    image_id INT NOT NULL,
    download_type ENUM('purchased', 'free', 'preview') DEFAULT 'purchased',
    ip_address VARCHAR(45),
    user_agent TEXT,
    downloaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (image_id) REFERENCES images(id) ON DELETE CASCADE,
    INDEX idx_user_id (user_id),
    INDEX idx_image_id (image_id),
    INDEX idx_downloaded_at (downloaded_at)
);

-- Site settings
CREATE TABLE IF NOT EXISTS site_settings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    setting_key VARCHAR(100) UNIQUE NOT NULL,
    setting_value TEXT,
    setting_type ENUM('text', 'number', 'boolean', 'json') DEFAULT 'text',
    description TEXT,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Insert default categories
INSERT INTO categories (name, slug, description, sort_order) VALUES
('သဘာဝ', 'nature', 'သဘာဝပတ်ဝန်းကျင် ဓာတ်ပုံများ', 1),
('မြို့ပြ', 'city', 'မြို့ပြ နှင့် အဆောက်အအုံများ', 2),
('ပုံတူ', 'portrait', 'လူပုဂ္ဂိုလ် ပုံတူများ', 3),
('အနုပညာ', 'abstract', 'အနုပညာ နှင့် ဒီဇိုင်းများ', 4),
('အစားအသောက်', 'food', 'အစားအသောက် ဓာတ်ပုံများ', 5),
('စီးပွားရေး', 'business', 'စီးပွားရေး နှင့် ရုံးခန်းများ', 6),
('နည်းပညာ', 'technology', 'နည်းပညာ နှင့် ကွန်ပျူတာများ', 7);

-- Insert default settings
INSERT INTO site_settings (setting_key, setting_value, setting_type, description) VALUES
('site_name', 'Infinity Gallery', 'text', 'Website name'),
('site_description', 'Premium stock photos and digital services', 'text', 'Website description'),
('contact_email', 'contact@infinitygallery.com', 'text', 'Contact email address'),
('maintenance_mode', '0', 'boolean', 'Enable maintenance mode'),
('registration_enabled', '1', 'boolean', 'Allow new user registration'),
('watermark_enabled', '1', 'boolean', 'Add watermark to images'),
('auto_approve_images', '0', 'boolean', 'Auto approve uploaded images'),
('commission_rate', '30', 'number', 'Commission rate percentage'),
('min_payout_amount', '50000', 'number', 'Minimum payout amount in MMK'),
('featured_images_count', '8', 'number', 'Number of featured images on homepage');

-- Insert sample coupons
INSERT INTO coupons (code, name, description, type, value, minimum_amount, usage_limit, starts_at, expires_at) VALUES
('WELCOME10', 'Welcome Discount', '10% off for new customers', 'percentage', 10.00, 10000, 100, NOW(), DATE_ADD(NOW(), INTERVAL 30 DAY)),
('SAVE20', 'Save 20%', '20% off on orders above 50,000 MMK', 'percentage', 20.00, 50000, 50, NOW(), DATE_ADD(NOW(), INTERVAL 15 DAY)),
('FIXED5000', 'Fixed Discount', '5,000 MMK off on orders above 30,000 MMK', 'fixed', 5000.00, 30000, 200, NOW(), DATE_ADD(NOW(), INTERVAL 60 DAY));

-- Update images table to add category support
ALTER TABLE images ADD COLUMN category_id INT DEFAULT NULL;
ALTER TABLE images ADD FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE SET NULL;

-- Add indexes for better performance
ALTER TABLE images ADD INDEX idx_category_created (category_id, created_at);
ALTER TABLE images ADD INDEX idx_price_mmk (price_mmk);
ALTER TABLE images ADD INDEX idx_price_thb (price_thb);
ALTER TABLE images ADD INDEX idx_views (views);
ALTER TABLE images ADD INDEX idx_downloads (downloads);

-- Update existing images with random categories
UPDATE images SET category_id = (SELECT id FROM categories ORDER BY RAND() LIMIT 1) WHERE category_id IS NULL;

-- Create indexes for better performance
CREATE INDEX idx_images_category ON images(category);
CREATE INDEX idx_images_price ON images(price);
CREATE INDEX idx_images_created_at ON images(created_at);
CREATE INDEX idx_orders_user_id ON orders(user_id);
CREATE INDEX idx_orders_status ON orders(status);
CREATE INDEX idx_notifications_user_id ON notifications(user_id);
CREATE INDEX idx_notifications_is_read ON notifications(is_read);
CREATE INDEX idx_download_history_user_id ON download_history(user_id);
CREATE INDEX idx_reviews_image_id ON reviews(image_id);
CREATE INDEX idx_wishlist_user_id ON wishlist(user_id);

-- Activity logs table
CREATE TABLE IF NOT EXISTS activity_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    admin_id INT,
    action VARCHAR(100) NOT NULL,
    details TEXT,
    ip_address VARCHAR(45),
    user_agent TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL,
    FOREIGN KEY (admin_id) REFERENCES admin_users(id) ON DELETE SET NULL,
    INDEX idx_user_id (user_id),
    INDEX idx_admin_id (admin_id),
    INDEX idx_action (action),
    INDEX idx_created_at (created_at)
);
