-- Create database
CREATE DATABASE IF NOT EXISTS infinity_server CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE infinity_server;

-- Users table
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    full_name VARCHAR(100),
    phone VARCHAR(20),
    address TEXT,
    profile_image VARCHAR(255),
    balance DECIMAL(10,2) DEFAULT 0.00,
    is_active BOOLEAN DEFAULT TRUE,
    email_verified BOOLEAN DEFAULT FALSE,
    verification_token VARCHAR(255),
    reset_token VARCHAR(255),
    reset_expires DATETIME,
    last_login DATETIME,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Admin users table
CREATE TABLE IF NOT EXISTS admin_users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    full_name VARCHAR(100),
    role ENUM('super_admin', 'admin', 'moderator') DEFAULT 'admin',
    is_active BOOLEAN DEFAULT TRUE,
    last_login DATETIME,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Images table
CREATE TABLE IF NOT EXISTS images (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    description TEXT,
    filename VARCHAR(255) NOT NULL,
    original_filename VARCHAR(255),
    file_path VARCHAR(500),
    thumbnail_path VARCHAR(500),
    watermark_path VARCHAR(500),
    category VARCHAR(100),
    tags TEXT,
    price_mmk DECIMAL(10,2) DEFAULT 0.00,
    price_thb DECIMAL(10,2) DEFAULT 0.00,
    is_free BOOLEAN DEFAULT FALSE,
    width INT,
    height INT,
    file_size INT,
    mime_type VARCHAR(100),
    downloads INT DEFAULT 0,
    views INT DEFAULT 0,
    likes INT DEFAULT 0,
    status ENUM('pending', 'approved', 'rejected') DEFAULT 'pending',
    featured BOOLEAN DEFAULT FALSE,
    uploaded_by INT,
    approved_by INT,
    approved_at DATETIME,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (uploaded_by) REFERENCES users(id) ON DELETE SET NULL,
    FOREIGN KEY (approved_by) REFERENCES admin_users(id) ON DELETE SET NULL,
    INDEX idx_category (category),
    INDEX idx_status (status),
    INDEX idx_featured (featured),
    INDEX idx_price_mmk (price_mmk),
    INDEX idx_created_at (created_at)
);

-- Orders table
CREATE TABLE IF NOT EXISTS orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_uid VARCHAR(50) UNIQUE NOT NULL,
    user_id INT NOT NULL,
    total_amount_mmk DECIMAL(10,2) NOT NULL,
    total_amount_thb DECIMAL(10,2) NOT NULL,
    currency VARCHAR(3) DEFAULT 'MMK',
    discount_amount DECIMAL(10,2) DEFAULT 0.00,
    final_amount DECIMAL(10,2) NOT NULL,
    payment_method VARCHAR(50),
    payment_status ENUM('pending', 'paid', 'failed', 'refunded') DEFAULT 'pending',
    payment_proof VARCHAR(255),
    order_status ENUM('pending', 'processing', 'completed', 'cancelled') DEFAULT 'pending',
    notes TEXT,
    admin_notes TEXT,
    processed_by INT,
    processed_at DATETIME,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (processed_by) REFERENCES admin_users(id) ON DELETE SET NULL,
    INDEX idx_user_id (user_id),
    INDEX idx_order_status (order_status),
    INDEX idx_payment_status (payment_status),
    INDEX idx_created_at (created_at)
);

-- Order items table
CREATE TABLE IF NOT EXISTS order_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT NOT NULL,
    image_id INT NOT NULL,
    price_mmk DECIMAL(10,2) NOT NULL,
    price_thb DECIMAL(10,2) NOT NULL,
    quantity INT DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
    FOREIGN KEY (image_id) REFERENCES images(id) ON DELETE CASCADE,
    INDEX idx_order_id (order_id),
    INDEX idx_image_id (image_id)
);

-- Services table
CREATE TABLE IF NOT EXISTS services (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    category VARCHAR(100),
    price_mmk DECIMAL(10,2) NOT NULL,
    price_thb DECIMAL(10,2) NOT NULL,
    service_type ENUM('mobile_topup', 'game_credit', 'design', 'development', 'other') NOT NULL,
    provider VARCHAR(100),
    is_active BOOLEAN DEFAULT TRUE,
    featured BOOLEAN DEFAULT FALSE,
    image VARCHAR(255),
    delivery_time VARCHAR(50),
    requirements TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_category (category),
    INDEX idx_service_type (service_type),
    INDEX idx_is_active (is_active)
);

-- Service orders table
CREATE TABLE IF NOT EXISTS service_orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_uid VARCHAR(50) UNIQUE NOT NULL,
    user_id INT NOT NULL,
    service_id INT NOT NULL,
    quantity INT DEFAULT 1,
    total_amount_mmk DECIMAL(10,2) NOT NULL,
    total_amount_thb DECIMAL(10,2) NOT NULL,
    currency VARCHAR(3) DEFAULT 'MMK',
    customer_info JSON,
    payment_method VARCHAR(50),
    payment_status ENUM('pending', 'paid', 'failed', 'refunded') DEFAULT 'pending',
    payment_proof VARCHAR(255),
    order_status ENUM('pending', 'processing', 'completed', 'cancelled') DEFAULT 'pending',
    delivery_info TEXT,
    notes TEXT,
    admin_notes TEXT,
    processed_by INT,
    processed_at DATETIME,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (service_id) REFERENCES services(id) ON DELETE CASCADE,
    FOREIGN KEY (processed_by) REFERENCES admin_users(id) ON DELETE SET NULL,
    INDEX idx_user_id (user_id),
    INDEX idx_service_id (service_id),
    INDEX idx_order_status (order_status)
);

-- Notifications table
CREATE TABLE IF NOT EXISTS notifications (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    admin_id INT,
    title VARCHAR(255) NOT NULL,
    message TEXT NOT NULL,
    type ENUM('info', 'success', 'warning', 'error') DEFAULT 'info',
    is_read BOOLEAN DEFAULT FALSE,
    related_type VARCHAR(50),
    related_id INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (admin_id) REFERENCES admin_users(id) ON DELETE CASCADE,
    INDEX idx_user_id (user_id),
    INDEX idx_admin_id (admin_id),
    INDEX idx_is_read (is_read),
    INDEX idx_created_at (created_at)
);

-- Cart table
CREATE TABLE IF NOT EXISTS cart (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    image_id INT NOT NULL,
    quantity INT DEFAULT 1,
    added_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (image_id) REFERENCES images(id) ON DELETE CASCADE,
    UNIQUE KEY unique_user_image (user_id, image_id),
    INDEX idx_user_id (user_id)
);

-- Site settings table
CREATE TABLE IF NOT EXISTS site_settings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    setting_key VARCHAR(100) UNIQUE NOT NULL,
    setting_value TEXT,
    setting_type ENUM('text', 'number', 'boolean', 'json', 'file') DEFAULT 'text',
    description TEXT,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Insert default admin user
INSERT INTO admin_users (username, email, password, full_name, role) VALUES 
('admin', 'admin@infinityserver.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'System Administrator', 'super_admin');

-- Insert default settings
INSERT INTO site_settings (setting_key, setting_value, setting_type, description) VALUES
('site_name', 'Infinity Server', 'text', 'Website name'),
('site_description', 'Premium digital marketplace for images and services', 'text', 'Website description'),
('contact_email', 'contact@infinityserver.com', 'text', 'Contact email'),
('contact_phone', '+95912345678', 'text', 'Contact phone number'),
('currency_mmk_rate', '1', 'number', 'MMK exchange rate'),
('currency_thb_rate', '0.025', 'number', 'THB exchange rate'),
('commission_rate', '30', 'number', 'Commission percentage'),
('min_withdrawal', '50000', 'number', 'Minimum withdrawal amount'),
('maintenance_mode', '0', 'boolean', 'Maintenance mode status'),
('registration_enabled', '1', 'boolean', 'User registration enabled'),
('email_verification', '0', 'boolean', 'Email verification required'),
('auto_approve_images', '0', 'boolean', 'Auto approve uploaded images'),
('watermark_enabled', '1', 'boolean', 'Add watermark to images'),
('max_file_size', '10485760', 'number', 'Maximum file size in bytes'),
('allowed_extensions', 'jpg,jpeg,png,gif,webp', 'text', 'Allowed file extensions'),
('images_per_page', '12', 'number', 'Images per page'),
('featured_images_count', '8', 'number', 'Featured images on homepage');

-- Insert sample services
INSERT INTO services (name, description, category, price_mmk, price_thb, service_type, provider, delivery_time, requirements) VALUES
('Ooredoo 1000 MMK Top-up', 'Ooredoo mobile phone top-up 1000 MMK', 'Mobile Top-up', 1000, 25, 'mobile_topup', 'Ooredoo', '5 minutes', 'Phone number required'),
('Telenor 1000 MMK Top-up', 'Telenor mobile phone top-up 1000 MMK', 'Mobile Top-up', 1000, 25, 'mobile_topup', 'Telenor', '5 minutes', 'Phone number required'),
('MPT 1000 MMK Top-up', 'MPT mobile phone top-up 1000 MMK', 'Mobile Top-up', 1000, 25, 'mobile_topup', 'MPT', '5 minutes', 'Phone number required'),
('PUBG Mobile 60 UC', 'PUBG Mobile 60 Unknown Cash', 'Game Credits', 1500, 37.5, 'game_credit', 'PUBG Mobile', '30 minutes', 'Player ID required'),
('Mobile Legends 86 Diamonds', 'Mobile Legends 86 Diamonds', 'Game Credits', 2000, 50, 'game_credit', 'Mobile Legends', '30 minutes', 'Player ID and Server ID required'),
('Free Fire 100 Diamonds', 'Free Fire 100 Diamonds', 'Game Credits', 1800, 45, 'game_credit', 'Free Fire', '30 minutes', 'Player ID required'),
('Logo Design Service', 'Professional logo design service', 'Design Services', 50000, 1250, 'design', 'Infinity Design', '3-5 days', 'Business details and preferences'),
('Website Development', 'Custom website development service', 'Development Services', 200000, 5000, 'development', 'Infinity Dev', '1-2 weeks', 'Requirements document'),
('KBZ Bank Account Opening', 'KBZ Bank account opening assistance', 'Banking Services', 10000, 250, 'other', 'KBZ Bank', '1-2 days', 'NRC and documents'),
('AYA Bank Account Opening', 'AYA Bank account opening assistance', 'Banking Services', 10000, 250, 'other', 'AYA Bank', '1-2 days', 'NRC and documents');

-- Create indexes for better performance
CREATE INDEX idx_images_category_status ON images(category, status);
CREATE INDEX idx_images_featured_status ON images(featured, status);
CREATE INDEX idx_orders_user_status ON orders(user_id, order_status);
CREATE INDEX idx_service_orders_user_status ON service_orders(user_id, order_status);
CREATE INDEX idx_notifications_user_read ON notifications(user_id, is_read);
