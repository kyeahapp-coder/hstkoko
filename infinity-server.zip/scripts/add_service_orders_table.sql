-- Add service orders table for handling service purchases
CREATE TABLE IF NOT EXISTS service_orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT NOT NULL,
    service_id INT NOT NULL,
    phone_number VARCHAR(50) NOT NULL,
    notes TEXT,
    status VARCHAR(20) DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
    FOREIGN KEY (service_id) REFERENCES services(id)
);

-- Add some sample images data
INSERT INTO images (filename, title, description, price_mmk, price_thb, watermark_path, original_path) VALUES
('sample1.jpg', 'Beautiful Landscape', 'A stunning mountain landscape photo', 1500, 35, 'uploads/watermarked/sample1.jpg', 'uploads/sample1.jpg'),
('sample2.jpg', 'City Skyline', 'Modern city skyline at sunset', 2000, 45, 'uploads/watermarked/sample2.jpg', 'uploads/sample2.jpg'),
('sample3.jpg', 'Nature Portrait', 'Beautiful nature portrait photography', 1800, 40, 'uploads/watermarked/sample3.jpg', 'uploads/sample3.jpg');

-- Create uploads directories (Note: This is just for reference, directories need to be created manually)
-- mkdir uploads/
-- mkdir uploads/watermarked/
-- chmod 755 uploads/
-- chmod 755 uploads/watermarked/
