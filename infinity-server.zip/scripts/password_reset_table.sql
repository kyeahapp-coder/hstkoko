-- Create password reset table
CREATE TABLE IF NOT EXISTS password_resets (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    token VARCHAR(255) NOT NULL,
    expires_at TIMESTAMP NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    UNIQUE KEY unique_user_reset (user_id),
    INDEX idx_token (token),
    INDEX idx_expires (expires_at)
);

-- Add indexes for better performance
ALTER TABLE orders ADD INDEX idx_user_created (user_id, created_at);
ALTER TABLE orders ADD INDEX idx_status (payment_status, admin_approved);
ALTER TABLE order_items ADD INDEX idx_order_image (order_id, image_id);
ALTER TABLE notifications ADD INDEX idx_user_read (user_id, is_read);
ALTER TABLE images ADD INDEX idx_created (created_at);
ALTER TABLE services ADD INDEX idx_type_active (service_type, is_active);

-- Add some sample data for testing
INSERT INTO images (filename, title, description, price_mmk, price_thb, watermark_path, original_path, views, downloads) VALUES
('nature1.jpg', 'Beautiful Mountain View', 'Stunning mountain landscape with clear blue sky', 2500, 60, 'uploads/watermarked/nature1.jpg', 'uploads/nature1.jpg', 45, 12),
('city1.jpg', 'Modern City Skyline', 'Amazing city skyline during golden hour', 3000, 75, 'uploads/watermarked/city1.jpg', 'uploads/city1.jpg', 67, 23),
('portrait1.jpg', 'Professional Portrait', 'High-quality professional portrait photography', 2000, 50, 'uploads/watermarked/portrait1.jpg', 'uploads/portrait1.jpg', 34, 8),
('abstract1.jpg', 'Abstract Art Design', 'Creative abstract design for modern use', 1800, 45, 'uploads/watermarked/abstract1.jpg', 'uploads/abstract1.jpg', 28, 5),
('nature2.jpg', 'Sunset Beach Scene', 'Peaceful beach sunset with palm trees', 2200, 55, 'uploads/watermarked/nature2.jpg', 'uploads/nature2.jpg', 52, 15),
('business1.jpg', 'Business Meeting', 'Professional business meeting photography', 2800, 70, 'uploads/watermarked/business1.jpg', 'uploads/business1.jpg', 41, 11),
('food1.jpg', 'Gourmet Food Photography', 'High-end food photography for restaurants', 2400, 60, 'uploads/watermarked/food1.jpg', 'uploads/food1.jpg', 38, 9);

-- Update services with more options
INSERT INTO services (service_type, service_name, price_mmk, price_thb, is_active) VALUES
('mobile_topup_mm', 'Ooredoo 5000 MMK Top-up', 5000, 125, 1),
('mobile_topup_mm', 'Telenor 3000 MMK Top-up', 3000, 75, 1),
('mobile_topup_mm', 'MPT 2000 MMK Top-up', 2000, 50, 1),
('mobile_topup_th', 'AIS 200 THB Top-up', 8000, 200, 1),
('mobile_topup_th', 'True 150 THB Top-up', 6000, 150, 1),
('pubg_uc', 'PUBG UC 1800', 36000, 900, 1),
('pubg_uc', 'PUBG UC 3850', 72000, 1800, 1),
('nmb_diamond', 'NMB Diamond 500', 10000, 250, 1),
('freefire_diamond', 'Free Fire 2180 Diamonds', 44000, 1100, 1),
('mobile_legends', 'Mobile Legends 2010 Diamonds', 40000, 1000, 1),
('banking', 'KBZ Bank Transfer Service', 500, 12, 1),
('banking', 'CB Bank Transfer Service', 500, 12, 1);
