<?php
require_once 'includes/functions.php';

$database = new Database();
$db = $database->getConnection();

// Get all active services
$services_query = "SELECT * FROM services WHERE is_active = 1 ORDER BY service_type, service_name";
$services_stmt = $db->prepare($services_query);
$services_stmt->execute();
$services = $services_stmt->fetchAll(PDO::FETCH_ASSOC);

// Group services by type
$grouped_services = [];
foreach ($services as $service) {
    $grouped_services[$service['service_type']][] = $service;
}
?>

<!DOCTYPE html>
<html lang="my">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ဝန်ဆောင်မှုများ - Infinity Server</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/login.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body data-user-logged-in="<?php echo isLoggedIn() ? 'true' : 'false'; ?>">
    <header class="header">
        <div class="container">
            <div class="nav-brand">
                <img src="<?php echo getSetting('site_logo'); ?>" alt="Logo" class="logo">
                <h1>Infinity Server</h1>
            </div>
            <nav class="nav-menu">
                <a href="index.php">ပင်မစာမျက်နှာ</a>
                <a href="services.php" class="active">ဝန်ဆောင်မှုများ</a>
                <?php if (isLoggedIn()): ?>
                    <a href="cart.php" class="cart-link">
                        <i class="fas fa-shopping-cart"></i>
                        <span id="cart-count">0</span>
                    </a>
                    <a href="profile.php">ကိုယ်ရေးအချက်အလက်</a>
                    <a href="logout.php">ထွက်ရန်</a>
                <?php else: ?>
                    <a href="login.php">ဝင်ရန်</a>
                    <a href="register.php">စာရင်းသွင်းရန်</a>
                <?php endif; ?>
            </nav>
        </div>
    </header>

    <main class="main-content">
        <div class="container">
            <div class="services-header">
                <h2><i class="fas fa-concierge-bell"></i> ဝန်ဆောင်မှုများ</h2>
                <p>ဂိမ်းများအတွက် လိုအပ်သော ဝန်ဆောင်မှုများကို ရယူပါ</p>
                
                <div class="currency-selector">
                    <button class="currency-btn active" data-currency="MMK">MMK</button>
                    <button class="currency-btn" data-currency="THB">THB</button>
                </div>
            </div>
            
            <div class="services-container">
                <?php foreach ($grouped_services as $type => $type_services): ?>
                    <div class="service-category">
                        <h3>
                            <i class="fas fa-<?php echo getServiceIcon($type); ?>"></i>
                            <?php echo getServiceTypeName($type); ?>
                        </h3>
                        
                        <div class="services-grid">
                            <?php foreach ($type_services as $service): ?>
                                <div class="service-card" data-service-id="<?php echo $service['id']; ?>">
                                    <div class="service-icon">
                                        <i class="fas fa-<?php echo getServiceIcon($service['service_type']); ?>"></i>
                                    </div>
                                    <div class="service-info">
                                        <h4><?php echo htmlspecialchars($service['service_name']); ?></h4>
                                        <p><?php echo htmlspecialchars($service['description']); ?></p>
                                        <div class="service-price">
                                            <span class="price mmk-price"><?php echo formatCurrency($service['price_mmk'], 'MMK'); ?></span>
                                            <span class="price thb-price" style="display: none;"><?php echo formatCurrency($service['price_thb'], 'THB'); ?></span>
                                        </div>
                                        <button class="btn-primary buy-service" data-service-id="<?php echo $service['id']; ?>">
                                            <i class="fas fa-shopping-cart"></i>
                                            ဝယ်ယူရန်
                                        </button>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </main>

    <!-- Service Purchase Modal -->
    <div id="service-modal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="closeServiceModal()">&times;</span>
            <h3>ဝန်ဆောင်မှု ဝယ်ယူရန်</h3>
            <div id="service-details"></div>
            <form id="service-form">
                <div class="form-group">
                    <label for="service-phone">ဖုန်းနံပါတ် သို့မဟုတ် Game ID:</label>
                    <input type="text" id="service-phone" class="form-control" required>
                </div>
                <div class="form-group">
                    <label for="service-notes">မှတ်ချက် (ရွေးချယ်ခွင့်ရှိသော):</label>
                    <textarea id="service-notes" class="form-control" rows="3"></textarea>
                </div>
                <button type="submit" class="btn-primary">
                    <i class="fas fa-check"></i> အတည်ပြုရန်
                </button>
            </form>
        </div>
    </div>

    <footer class="footer">
        <div class="container">
            <p>&copy; 2024 Infinity Server. All rights reserved.</p>
        </div>
    </footer>

    <script src="assets/js/main.js"></script>
    <script src="assets/js/services.js"></script>
</body>
</html>

<?php
function getServiceIcon($type) {
    $icons = [
        'mobile_legends' => 'shield-alt',
        'pubg' => 'crosshairs',
        'free_fire' => 'fire',
        'call_of_duty' => 'bomb',
        'other' => 'gamepad'
    ];
    return $icons[$type] ?? 'gamepad';
}

function getServiceTypeName($type) {
    $names = [
        'mobile_legends' => 'Mobile Legends',
        'pubg' => 'PUBG Mobile',
        'free_fire' => 'Free Fire',
        'call_of_duty' => 'Call of Duty Mobile',
        'other' => 'အခြားဂိမ်းများ'
    ];
    return $names[$type] ?? 'အခြားဝန်ဆောင်မှုများ';
}
?>
