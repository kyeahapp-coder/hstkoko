// Notifications management
class NotificationManager {
  constructor() {
    this.unreadCount = 0
    this.notifications = []
    this.init()
  }

  init() {
    this.loadNotifications()
    this.setupEventListeners()

    // Check for new notifications every 30 seconds
    setInterval(() => {
      this.loadNotifications()
    }, 30000)
  }

  setupEventListeners() {
    // Notification bell click
    const notificationBell = document.getElementById("notification-bell")
    if (notificationBell) {
      notificationBell.addEventListener("click", () => {
        this.toggleNotificationDropdown()
      })
    }

    // Close dropdown when clicking outside
    document.addEventListener("click", (e) => {
      const dropdown = document.getElementById("notification-dropdown")
      const bell = document.getElementById("notification-bell")

      if (dropdown && !dropdown.contains(e.target) && !bell.contains(e.target)) {
        dropdown.style.display = "none"
      }
    })
  }

  async loadNotifications() {
    try {
      const response = await fetch("api/get_notifications.php?limit=10")
      const data = await response.json()

      if (data.success) {
        this.notifications = data.notifications
        this.unreadCount = data.unread_count
        this.updateUI()
      }
    } catch (error) {
      console.error("Error loading notifications:", error)
    }
  }

  updateUI() {
    // Update notification count badge
    const countBadge = document.getElementById("notification-count")
    if (countBadge) {
      countBadge.textContent = this.unreadCount
      countBadge.style.display = this.unreadCount > 0 ? "block" : "none"
    }

    // Update notification dropdown
    this.updateNotificationDropdown()
  }

  updateNotificationDropdown() {
    const dropdown = document.getElementById("notification-dropdown")
    if (!dropdown) return

    const notificationsList = dropdown.querySelector(".notifications-list")
    if (!notificationsList) return

    if (this.notifications.length === 0) {
      notificationsList.innerHTML = `
                <div class="no-notifications">
                    <i class="fas fa-bell-slash"></i>
                    <p>အသိပေးချက်များ မရှိပါ</p>
                </div>
            `
      return
    }

    notificationsList.innerHTML = this.notifications
      .map(
        (notification) => `
            <div class="notification-item ${notification.is_read ? "read" : "unread"}" data-id="${notification.id}">
                <div class="notification-icon">
                    <i class="fas fa-${this.getNotificationIcon(notification.type)}"></i>
                </div>
                <div class="notification-content">
                    <h4>${this.escapeHtml(notification.title)}</h4>
                    <p>${this.escapeHtml(notification.message)}</p>
                    <small>${this.formatDate(notification.created_at)}</small>
                </div>
                ${!notification.is_read ? '<div class="unread-indicator"></div>' : ""}
            </div>
        `,
      )
      .join("")

    // Add click handlers for notifications
    notificationsList.querySelectorAll(".notification-item.unread").forEach((item) => {
      item.addEventListener("click", () => {
        this.markAsRead(item.dataset.id)
      })
    })
  }

  toggleNotificationDropdown() {
    const dropdown = document.getElementById("notification-dropdown")
    if (!dropdown) return

    dropdown.style.display = dropdown.style.display === "block" ? "none" : "block"

    // Mark notifications as read when dropdown is opened
    if (dropdown.style.display === "block") {
      this.markAllAsRead()
    }
  }

  async markAsRead(notificationId) {
    try {
      const response = await fetch("api/mark_notifications_read.php", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ notification_ids: [notificationId] }),
      })

      const data = await response.json()
      if (data.success) {
        this.loadNotifications()
      }
    } catch (error) {
      console.error("Error marking notification as read:", error)
    }
  }

  async markAllAsRead() {
    const unreadIds = this.notifications.filter((n) => !n.is_read).map((n) => n.id)

    if (unreadIds.length === 0) return

    try {
      const response = await fetch("api/mark_notifications_read.php", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ notification_ids: unreadIds }),
      })

      const data = await response.json()
      if (data.success) {
        this.loadNotifications()
      }
    } catch (error) {
      console.error("Error marking notifications as read:", error)
    }
  }

  getNotificationIcon(type) {
    const icons = {
      success: "check-circle",
      error: "exclamation-circle",
      warning: "exclamation-triangle",
      info: "info-circle",
    }
    return icons[type] || "bell"
  }

  formatDate(dateString) {
    const date = new Date(dateString)
    const now = new Date()
    const diff = now - date

    const minutes = Math.floor(diff / 60000)
    const hours = Math.floor(diff / 3600000)
    const days = Math.floor(diff / 86400000)

    if (minutes < 1) return "ယခုလေး"
    if (minutes < 60) return `${minutes} မိနစ်အကြာ`
    if (hours < 24) return `${hours} နာရီအကြာ`
    if (days < 7) return `${days} ရက်အကြာ`

    return date.toLocaleDateString("my-MM")
  }

  escapeHtml(text) {
    const div = document.createElement("div")
    div.textContent = text
    return div.innerHTML
  }

  // Add notification to page header
  addToHeader() {
    const header = document.querySelector(".nav-menu")
    if (!header) return

    const notificationHtml = `
            <div class="notification-wrapper">
                <button id="notification-bell" class="notification-bell">
                    <i class="fas fa-bell"></i>
                    <span id="notification-count" class="notification-count">0</span>
                </button>
                <div id="notification-dropdown" class="notification-dropdown">
                    <div class="notification-header">
                        <h3>အသိပေးချက်များ</h3>
                    </div>
                    <div class="notifications-list">
                        <!-- Notifications will be loaded here -->
                    </div>
                    <div class="notification-footer">
                        <a href="profile.php#notifications">အားလုံးကြည့်ရန်</a>
                    </div>
                </div>
            </div>
        `

    // Insert before profile link
    const profileLink = header.querySelector('a[href="profile.php"]')
    if (profileLink) {
      profileLink.insertAdjacentHTML("beforebegin", notificationHtml)
    }
  }
}

// Initialize notification manager when DOM is loaded
document.addEventListener("DOMContentLoaded", () => {
  if (document.body.dataset.userLoggedIn === "true") {
    const notificationManager = new NotificationManager()
    notificationManager.addToHeader()
  }
})
