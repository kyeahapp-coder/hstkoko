// Shopping Cart Management
const cart = JSON.parse(localStorage.getItem("cart")) || []
const currentUser = null
let cartCount = 0
const notificationCount = 0

// Update cart count on page load
document.addEventListener("DOMContentLoaded", () => {
  initializeApp()
})

// Initialize application
function initializeApp() {
  // Setup event listeners
  setupEventListeners()

  // Update cart count
  updateCartCount()

  // Setup view toggle
  setupViewToggle()

  // Setup infinite scroll
  setupInfiniteScroll()

  // Setup search functionality
  setupSearch()

  // Setup mobile menu
  setupMobileMenu()
}

// Setup event listeners
function setupEventListeners() {
  // User menu toggle
  const userBtn = document.querySelector(".user-btn")
  const userDropdown = document.querySelector(".user-dropdown")

  if (userBtn && userDropdown) {
    userBtn.addEventListener("click", (e) => {
      e.stopPropagation()
      userDropdown.style.display = userDropdown.style.display === "block" ? "none" : "block"
    })

    // Close dropdown when clicking outside
    document.addEventListener("click", () => {
      userDropdown.style.display = "none"
    })
  }

  // Search form
  const searchForm = document.querySelector(".search-box form")
  if (searchForm) {
    searchForm.addEventListener("submit", function (e) {
      const searchInput = this.querySelector("input")
      if (!searchInput.value.trim()) {
        e.preventDefault()
        showNotification("Please enter a search term", "warning")
      }
    })
  }

  // Image lazy loading
  setupLazyLoading()
}

// Setup view toggle (grid/list)
function setupViewToggle() {
  const viewBtns = document.querySelectorAll(".view-btn")
  const imagesContainer = document.getElementById("images-container")

  viewBtns.forEach((btn) => {
    btn.addEventListener("click", function () {
      const view = this.dataset.view

      // Update active button
      viewBtns.forEach((b) => b.classList.remove("active"))
      this.classList.add("active")

      // Update container class
      if (imagesContainer) {
        imagesContainer.className = view === "list" ? "images-list" : "images-grid"
      }

      // Save preference
      localStorage.setItem("viewPreference", view)
    })
  })

  // Load saved preference
  const savedView = localStorage.getItem("viewPreference")
  if (savedView) {
    const btn = document.querySelector(`[data-view="${savedView}"]`)
    if (btn) btn.click()
  }
}

// Setup infinite scroll
function setupInfiniteScroll() {
  let loading = false
  let currentPage = 1

  window.addEventListener("scroll", () => {
    if (loading) return

    const scrollTop = window.pageYOffset
    const windowHeight = window.innerHeight
    const documentHeight = document.documentElement.scrollHeight

    if (scrollTop + windowHeight >= documentHeight - 1000) {
      loadMoreImages()
    }
  })

  function loadMoreImages() {
    loading = true
    currentPage++

    const urlParams = new URLSearchParams(window.location.search)
    urlParams.set("page", currentPage)

    fetch(`${window.location.pathname}?${urlParams.toString()}`)
      .then((response) => response.text())
      .then((html) => {
        const parser = new DOMParser()
        const doc = parser.parseFromString(html, "text/html")
        const newImages = doc.querySelectorAll(".image-card")

        if (newImages.length > 0) {
          const container = document.getElementById("images-container")
          newImages.forEach((img) => container.appendChild(img))
          setupLazyLoading() // Re-setup lazy loading for new images
        } else {
          // No more images
          window.removeEventListener("scroll", arguments.callee)
        }

        loading = false
      })
      .catch((error) => {
        console.error("Error loading more images:", error)
        loading = false
      })
  }
}

// Setup lazy loading for images
function setupLazyLoading() {
  const images = document.querySelectorAll('img[loading="lazy"]')

  if ("IntersectionObserver" in window) {
    const imageObserver = new IntersectionObserver((entries, observer) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          const img = entry.target
          img.src = img.dataset.src || img.src
          img.classList.remove("lazy")
          observer.unobserve(img)
        }
      })
    })

    images.forEach((img) => imageObserver.observe(img))
  }
}

// Setup search functionality
function setupSearch() {
  const searchInput = document.querySelector(".search-box input")
  let searchTimeout

  if (searchInput) {
    searchInput.addEventListener("input", function () {
      clearTimeout(searchTimeout)
      const query = this.value.trim()

      if (query.length >= 3) {
        searchTimeout = setTimeout(() => {
          showSearchSuggestions(query)
        }, 300)
      } else {
        hideSearchSuggestions()
      }
    })

    // Hide suggestions when clicking outside
    document.addEventListener("click", (e) => {
      if (!e.target.closest(".search-box")) {
        hideSearchSuggestions()
      }
    })
  }
}

// Show search suggestions
function showSearchSuggestions(query) {
  fetch(`api/search_suggestions.php?q=${encodeURIComponent(query)}`)
    .then((response) => response.json())
    .then((data) => {
      if (data.success && data.suggestions.length > 0) {
        displaySearchSuggestions(data.suggestions)
      } else {
        hideSearchSuggestions()
      }
    })
    .catch((error) => {
      console.error("Error fetching suggestions:", error)
    })
}

// Display search suggestions
function displaySearchSuggestions(suggestions) {
  let suggestionsContainer = document.querySelector(".search-suggestions")

  if (!suggestionsContainer) {
    suggestionsContainer = document.createElement("div")
    suggestionsContainer.className = "search-suggestions"
    document.querySelector(".search-box").appendChild(suggestionsContainer)
  }

  suggestionsContainer.innerHTML = suggestions
    .map((suggestion) => `<div class="suggestion-item" onclick="selectSuggestion('${suggestion}')">${suggestion}</div>`)
    .join("")

  suggestionsContainer.style.display = "block"
}

// Hide search suggestions
function hideSearchSuggestions() {
  const suggestionsContainer = document.querySelector(".search-suggestions")
  if (suggestionsContainer) {
    suggestionsContainer.style.display = "none"
  }
}

// Select search suggestion
function selectSuggestion(suggestion) {
  const searchInput = document.querySelector(".search-box input")
  if (searchInput) {
    searchInput.value = suggestion
    searchInput.form.submit()
  }
}

// Setup mobile menu
function setupMobileMenu() {
  const mobileMenuBtn = document.querySelector(".mobile-menu-btn")
  const nav = document.querySelector(".nav")

  if (mobileMenuBtn && nav) {
    mobileMenuBtn.addEventListener("click", function () {
      nav.classList.toggle("active")
      this.classList.toggle("active")
    })
  }
}

// Update cart count
function updateCartCount() {
  fetch("api/get_cart_count.php")
    .then((response) => response.json())
    .then((data) => {
      if (data.success) {
        cartCount = data.count
        updateCartDisplay()
      }
    })
    .catch((error) => {
      console.error("Error updating cart count:", error)
    })
}

// Update cart display
function updateCartDisplay() {
  const cartCountElement = document.querySelector(".cart-count")

  if (cartCount > 0) {
    if (cartCountElement) {
      cartCountElement.textContent = cartCount
      cartCountElement.style.display = "flex"
    } else {
      // Create cart count element if it doesn't exist
      const cartBtn = document.querySelector(".cart-btn")
      if (cartBtn) {
        const countElement = document.createElement("span")
        countElement.className = "cart-count"
        countElement.textContent = cartCount
        cartBtn.appendChild(countElement)
      }
    }
  } else {
    if (cartCountElement) {
      cartCountElement.style.display = "none"
    }
  }
}

// Show notification
function showNotification(message, type = "info", duration = 5000) {
  // Remove existing notifications
  const existingNotifications = document.querySelectorAll(".notification")
  existingNotifications.forEach((n) => n.remove())

  // Create notification element
  const notification = document.createElement("div")
  notification.className = `notification ${type}`
  notification.textContent = message

  // Add to page
  document.body.appendChild(notification)

  // Show notification
  setTimeout(() => {
    notification.classList.add("show")
  }, 100)

  // Hide notification after duration
  setTimeout(() => {
    notification.classList.remove("show")
    setTimeout(() => {
      notification.remove()
    }, 300)
  }, duration)
}

// Add to cart function
function addToCart(imageId, quantity = 1) {
  // Check if user is logged in
  if (!document.body.classList.contains("logged-in")) {
    window.location.href = "login.php"
    return
  }

  const data = {
    image_id: imageId,
    quantity: quantity,
  }

  fetch("api/add_to_cart.php", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(data),
  })
    .then((response) => response.json())
    .then((data) => {
      if (data.success) {
        showNotification("Added to cart successfully!", "success")
        updateCartCount()
      } else {
        showNotification(data.message || "Failed to add to cart", "error")
      }
    })
    .catch((error) => {
      console.error("Error:", error)
      showNotification("An error occurred", "error")
    })
}

// Remove from cart function
function removeFromCart(imageId) {
  const data = {
    image_id: imageId,
  }

  fetch("api/remove_from_cart.php", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(data),
  })
    .then((response) => response.json())
    .then((data) => {
      if (data.success) {
        showNotification("Removed from cart", "info")
        updateCartCount()
        // Reload page to update cart display
        window.location.reload()
      } else {
        showNotification(data.message || "Failed to remove from cart", "error")
      }
    })
    .catch((error) => {
      console.error("Error:", error)
      showNotification("An error occurred", "error")
    })
}

// Toggle wishlist function
function toggleWishlist(imageId) {
  // Check if user is logged in
  if (!document.body.classList.contains("logged-in")) {
    window.location.href = "login.php"
    return
  }

  const data = {
    image_id: imageId,
  }

  fetch("api/toggle_wishlist.php", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(data),
  })
    .then((response) => response.json())
    .then((data) => {
      if (data.success) {
        showNotification(data.message, "success")

        // Update wishlist button appearance
        const wishlistBtn = document.querySelector(`[onclick="toggleWishlist(${imageId})"]`)
        if (wishlistBtn) {
          const icon = wishlistBtn.querySelector("i")
          if (data.added) {
            icon.classList.remove("far")
            icon.classList.add("fas")
            wishlistBtn.classList.add("active")
          } else {
            icon.classList.remove("fas")
            icon.classList.add("far")
            wishlistBtn.classList.remove("active")
          }
        }
      } else {
        showNotification(data.message || "Failed to update wishlist", "error")
      }
    })
    .catch((error) => {
      console.error("Error:", error)
      showNotification("An error occurred", "error")
    })
}

// Format currency
function formatCurrency(amount, currency = "MMK") {
  if (currency === "MMK") {
    return new Intl.NumberFormat("en-US").format(amount) + " ကျပ်"
  } else {
    return (
      new Intl.NumberFormat("en-US", {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2,
      }).format(amount) + " ฿"
    )
  }
}

// Convert currency
function convertCurrency(amount, from = "MMK", to = "THB") {
  const rates = {
    MMK: 1,
    THB: 0.025,
  }

  if (from === to) return amount

  // Convert to MMK first, then to target currency
  const mmkAmount = amount / rates[from]
  return mmkAmount * rates[to]
}

// Toggle currency display
function toggleCurrency() {
  const currentCurrency = localStorage.getItem("currency") || "MMK"
  const newCurrency = currentCurrency === "MMK" ? "THB" : "MMK"

  localStorage.setItem("currency", newCurrency)

  // Update all price displays
  const priceElements = document.querySelectorAll("[data-price-mmk]")
  priceElements.forEach((element) => {
    const mmkPrice = Number.parseFloat(element.dataset.priceMmk)
    const thbPrice = Number.parseFloat(element.dataset.priceThb)

    if (newCurrency === "MMK") {
      element.textContent = formatCurrency(mmkPrice, "MMK")
    } else {
      element.textContent = formatCurrency(thbPrice, "THB")
    }
  })

  // Update currency toggle button
  const currencyBtn = document.querySelector(".currency-toggle")
  if (currencyBtn) {
    currencyBtn.textContent = newCurrency
  }
}

// Initialize currency display
function initializeCurrency() {
  const savedCurrency = localStorage.getItem("currency") || "MMK"

  if (savedCurrency === "THB") {
    toggleCurrency()
  }
}

// Smooth scroll to top
function scrollToTop() {
  window.scrollTo({
    top: 0,
    behavior: "smooth",
  })
}

// Show scroll to top button
window.addEventListener("scroll", () => {
  const scrollBtn = document.querySelector(".scroll-to-top")
  if (scrollBtn) {
    if (window.pageYOffset > 300) {
      scrollBtn.style.display = "block"
    } else {
      scrollBtn.style.display = "none"
    }
  }
})

// Utility functions
const Utils = {
  // Debounce function
  debounce: (func, wait, immediate) => {
    let timeout
    return function executedFunction() {
      
      const args = arguments
      const later = () => {
        timeout = null
        if (!immediate) func.apply(this, args)
      }
      const callNow = immediate && !timeout
      clearTimeout(timeout)
      timeout = setTimeout(later, wait)
      if (callNow) func.apply(this, args)
    }
  },

  // Throttle function
  throttle: (func, limit) => {
    let inThrottle
    return function () {
      const args = arguments
      
      if (!inThrottle) {
        func.apply(this, args)
        inThrottle = true
        setTimeout(() => (inThrottle = false), limit)
      }
    }
  },

  // Format file size
  formatFileSize: (bytes) => {
    if (bytes === 0) return "0 Bytes"
    const k = 1024
    const sizes = ["Bytes", "KB", "MB", "GB"]
    const i = Math.floor(Math.log(bytes) / Math.log(k))
    return Number.parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + " " + sizes[i]
  },

  // Time ago function
  timeAgo: (date) => {
    const now = new Date()
    const diffInSeconds = Math.floor((now - new Date(date)) / 1000)

    const intervals = {
      year: 31536000,
      month: 2592000,
      week: 604800,
      day: 86400,
      hour: 3600,
      minute: 60,
    }

    for (const [unit, seconds] of Object.entries(intervals)) {
      const interval = Math.floor(diffInSeconds / seconds)
      if (interval >= 1) {
        return `${interval} ${unit}${interval > 1 ? "s" : ""} ago`
      }
    }

    return "Just now"
  },

  // Copy to clipboard
  copyToClipboard: (text) => {
    if (navigator.clipboard) {
      navigator.clipboard.writeText(text).then(() => {
        showNotification("Copied to clipboard!", "success")
      })
    } else {
      // Fallback for older browsers
      const textArea = document.createElement("textarea")
      textArea.value = text
      document.body.appendChild(textArea)
      textArea.select()
      document.execCommand("copy")
      document.body.removeChild(textArea)
      showNotification("Copied to clipboard!", "success")
    }
  },
}

// Export functions for global use
window.addToCart = addToCart
window.removeFromCart = removeFromCart
window.toggleWishlist = toggleWishlist
window.showNotification = showNotification
window.formatCurrency = formatCurrency
window.convertCurrency = convertCurrency
window.toggleCurrency = toggleCurrency
window.scrollToTop = scrollToTop
window.Utils = Utils
