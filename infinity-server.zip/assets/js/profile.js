// Profile page JavaScript
document.addEventListener("DOMContentLoaded", () => {
  initializeProfileNavigation()
  markNotificationsAsRead()
  initializeProfileForms()
  initializePasswordValidation()
  initializeFormValidation()
  initializeProfilePictureUpload()
})

function initializeProfileNavigation() {
  const navLinks = document.querySelectorAll(".profile-nav-link")
  const sections = document.querySelectorAll(".profile-section")

  navLinks.forEach((link) => {
    link.addEventListener("click", function (e) {
      e.preventDefault()

      const targetId = this.getAttribute("href").substring(1)

      // Update active nav link
      navLinks.forEach((l) => l.classList.remove("active"))
      this.classList.add("active")

      // Show target section
      sections.forEach((section) => {
        section.classList.remove("active")
        if (section.id === targetId) {
          section.classList.add("active")
        }
      })
    })
  })
}

function markNotificationsAsRead() {
  const unreadNotifications = document.querySelectorAll(".notification-item.unread")

  if (unreadNotifications.length > 0) {
    const notificationIds = Array.from(unreadNotifications)
      .map((item) => item.dataset.notificationId)
      .filter(Boolean)

    if (notificationIds.length > 0) {
      fetch("api/mark_notifications_read.php", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ notification_ids: notificationIds }),
      })
        .then((response) => response.json())
        .then((data) => {
          if (data.success) {
            unreadNotifications.forEach((item) => {
              item.classList.remove("unread")
              item.classList.add("read")
            })
          }
        })
        .catch((error) => {
          console.error("Error marking notifications as read:", error)
        })
    }
  }
}

function initializeProfileForms() {
  // Auto-save form data
  const forms = document.querySelectorAll(".profile-form")

  forms.forEach((form) => {
    const inputs = form.querySelectorAll("input, select, textarea")

    inputs.forEach((input) => {
      input.addEventListener("input", () => {
        saveFormData(form)
      })
    })

    // Load saved data
    loadFormData(form)
  })
}

function initializePasswordValidation() {
  const newPasswordInput = document.getElementById("new_password")
  const confirmPasswordInput = document.getElementById("confirm_password")

  if (newPasswordInput && confirmPasswordInput) {
    // Real-time password validation
    newPasswordInput.addEventListener("input", validatePassword)
    confirmPasswordInput.addEventListener("input", validatePasswordMatch)

    // Show password strength
    newPasswordInput.addEventListener("input", showPasswordStrength)
  }
}

function validatePassword() {
  const password = document.getElementById("new_password").value
  const feedback = document.getElementById("password-feedback") || createPasswordFeedback()

  const requirements = [
    { test: password.length >= 6, text: "At least 6 characters" },
    { test: /[A-Z]/.test(password), text: "One uppercase letter" },
    { test: /[a-z]/.test(password), text: "One lowercase letter" },
    { test: /\d/.test(password), text: "One number" },
    { test: /[!@#$%^&*]/.test(password), text: "One special character" },
  ]

  let strength = 0
  let feedbackHTML = '<div class="password-requirements">'

  requirements.forEach((req) => {
    const status = req.test ? "valid" : "invalid"
    const icon = req.test ? "check" : "times"
    feedbackHTML += `<div class="requirement ${status}">
            <i class="fas fa-${icon}"></i> ${req.text}
        </div>`
    if (req.test) strength++
  })

  feedbackHTML += "</div>"

  // Add strength indicator
  const strengthText = ["Very Weak", "Weak", "Fair", "Good", "Strong"][Math.min(strength, 4)]
  const strengthClass = ["very-weak", "weak", "fair", "good", "strong"][Math.min(strength, 4)]

  feedbackHTML += `<div class="password-strength">
        <div class="strength-bar">
            <div class="strength-fill ${strengthClass}" style="width: ${(strength / 5) * 100}%"></div>
        </div>
        <span class="strength-text ${strengthClass}">${strengthText}</span>
    </div>`

  feedback.innerHTML = feedbackHTML
}

function validatePasswordMatch() {
  const newPassword = document.getElementById("new_password").value
  const confirmPassword = document.getElementById("confirm_password").value
  const confirmInput = document.getElementById("confirm_password")

  if (confirmPassword && newPassword !== confirmPassword) {
    confirmInput.setCustomValidity("Passwords do not match")
    confirmInput.classList.add("error")
  } else {
    confirmInput.setCustomValidity("")
    confirmInput.classList.remove("error")
  }
}

function createPasswordFeedback() {
  const passwordInput = document.getElementById("new_password")
  const feedback = document.createElement("div")
  feedback.id = "password-feedback"
  feedback.className = "password-feedback"

  passwordInput.parentNode.appendChild(feedback)
  return feedback
}

function showPasswordStrength() {
  const feedback = document.getElementById("password-feedback")
  if (feedback) {
    feedback.style.display = "block"
  }
}

function initializeFormValidation() {
  const forms = document.querySelectorAll(".profile-form")

  forms.forEach((form) => {
    form.addEventListener("submit", function (e) {
      if (!validateForm(this)) {
        e.preventDefault()
      }
    })

    // Real-time validation
    const inputs = form.querySelectorAll("input, select, textarea")
    inputs.forEach((input) => {
      input.addEventListener("blur", function () {
        validateField(this)
      })

      input.addEventListener("input", function () {
        if (this.classList.contains("error")) {
          validateField(this)
        }
      })
    })
  })
}

function validateForm(form) {
  let isValid = true
  const inputs = form.querySelectorAll("input[required], select[required], textarea[required]")

  inputs.forEach((input) => {
    if (!validateField(input)) {
      isValid = false
    }
  })

  // Special validation for password form
  if (form.querySelector("#new_password")) {
    const newPassword = form.querySelector("#new_password").value
    const confirmPassword = form.querySelector("#confirm_password").value

    if (newPassword !== confirmPassword) {
      showNotification("Passwords do not match", "error")
      isValid = false
    }
  }

  return isValid
}

function validateField(field) {
  const value = field.value.trim()
  let isValid = true

  // Remove existing error styling
  field.classList.remove("error")
  removeFieldError(field)

  // Required field validation
  if (field.hasAttribute("required") && !value) {
    showFieldError(field, "This field is required")
    isValid = false
  }

  // Email validation
  if (field.type === "email" && value) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
    if (!emailRegex.test(value)) {
      showFieldError(field, "Please enter a valid email address")
      isValid = false
    }
  }

  // Phone validation
  if (field.type === "tel" && value) {
    const phoneRegex = /^[0-9+\-\s()]+$/
    if (!phoneRegex.test(value)) {
      showFieldError(field, "Please enter a valid phone number")
      isValid = false
    }
  }

  // Password validation
  if (field.type === "password" && field.id === "new_password" && value) {
    if (value.length < 6) {
      showFieldError(field, "Password must be at least 6 characters long")
      isValid = false
    }
  }

  return isValid
}

function showFieldError(field, message) {
  field.classList.add("error")

  const errorElement = document.createElement("div")
  errorElement.className = "field-error"
  errorElement.textContent = message

  field.parentNode.appendChild(errorElement)
}

function removeFieldError(field) {
  const existingError = field.parentNode.querySelector(".field-error")
  if (existingError) {
    existingError.remove()
  }
}

function saveFormData(form) {
  const formData = new FormData(form)
  const data = {}

  for (const [key, value] of formData.entries()) {
    if (key !== "csrf_token" && !key.includes("password")) {
      data[key] = value
    }
  }

  const formId = form.querySelector("[name]").name
  localStorage.setItem(`profile_form_${formId}`, JSON.stringify(data))
}

function loadFormData(form) {
  const formId = form.querySelector("[name]").name
  const savedData = localStorage.getItem(`profile_form_${formId}`)

  if (savedData) {
    try {
      const data = JSON.parse(savedData)

      Object.keys(data).forEach((key) => {
        const field = form.querySelector(`[name="${key}"]`)
        if (field && field.type !== "password") {
          field.value = data[key]
        }
      })
    } catch (e) {
      console.error("Error loading saved form data:", e)
    }
  }
}

function showNotification(message, type = "info") {
  // Remove existing notifications
  const existingNotifications = document.querySelectorAll(".notification")
  existingNotifications.forEach((notification) => notification.remove())

  // Create notification element
  const notification = document.createElement("div")
  notification.className = `notification ${type}`
  notification.innerHTML = `
        <div class="notification-content">
            <i class="fas fa-${getNotificationIcon(type)}"></i>
            <span>${message}</span>
            <button class="notification-close" onclick="this.parentElement.parentElement.remove()">
                <i class="fas fa-times"></i>
            </button>
        </div>
    `

  // Add to page
  document.body.appendChild(notification)

  // Show notification
  setTimeout(() => {
    notification.classList.add("show")
  }, 100)

  // Auto remove after 5 seconds
  setTimeout(() => {
    if (notification.parentNode) {
      notification.classList.remove("show")
      setTimeout(() => {
        if (notification.parentNode) {
          notification.remove()
        }
      }, 300)
    }
  }, 5000)
}

function getNotificationIcon(type) {
  const icons = {
    success: "check-circle",
    error: "exclamation-circle",
    warning: "exclamation-triangle",
    info: "info-circle",
  }
  return icons[type] || icons.info
}

// Profile picture upload (if implemented)
function initializeProfilePictureUpload() {
  const uploadButton = document.getElementById("upload-profile-picture")
  const fileInput = document.getElementById("profile-picture-input")
  const preview = document.getElementById("profile-picture-preview")

  if (uploadButton && fileInput) {
    uploadButton.addEventListener("click", () => {
      fileInput.click()
    })

    fileInput.addEventListener("change", function () {
      if (this.files && this.files[0]) {
        const file = this.files[0]

        // Validate file
        if (!file.type.startsWith("image/")) {
          showNotification("Please select an image file", "error")
          return
        }

        if (file.size > 5 * 1024 * 1024) {
          // 5MB limit
          showNotification("File size must be less than 5MB", "error")
          return
        }

        // Show preview
        const reader = new FileReader()
        reader.onload = (e) => {
          if (preview) {
            preview.src = e.target.result
          }
        }
        reader.readAsDataURL(file)

        // Upload file
        uploadProfilePicture(file)
      }
    })
  }
}

function uploadProfilePicture(file) {
  const formData = new FormData()
  formData.append("profile_picture", file)

  fetch("api/upload_profile_picture.php", {
    method: "POST",
    body: formData,
  })
    .then((response) => response.json())
    .then((data) => {
      if (data.success) {
        showNotification("Profile picture updated successfully", "success")
      } else {
        showNotification(data.message || "Failed to upload profile picture", "error")
      }
    })
    .catch((error) => {
      console.error("Error:", error)
      showNotification("Failed to upload profile picture", "error")
    })
}
