// Services page JavaScript
document.addEventListener("DOMContentLoaded", () => {
  initializeServices()
  initializeCurrencyToggle()
  initializeServicePurchase()
})

function initializeServices() {
  // Load cart count
  updateCartCount()

  // Initialize service cards
  const serviceCards = document.querySelectorAll(".service-card")
  serviceCards.forEach((card) => {
    card.addEventListener("click", function () {
      const serviceId = this.dataset.serviceId
      if (serviceId) {
        showServiceModal(serviceId)
      }
    })
  })

  // Initialize buy buttons
  const buyButtons = document.querySelectorAll(".buy-service")
  buyButtons.forEach((button) => {
    button.addEventListener("click", function (e) {
      e.stopPropagation()
      const serviceId = this.dataset.serviceId
      if (serviceId) {
        showServiceModal(serviceId)
      }
    })
  })
}

function initializeCurrencyToggle() {
  const currencyButtons = document.querySelectorAll(".currency-btn")
  const mmkPrices = document.querySelectorAll(".mmk-price")
  const thbPrices = document.querySelectorAll(".thb-price")

  currencyButtons.forEach((button) => {
    button.addEventListener("click", function () {
      const currency = this.dataset.currency

      // Update active button
      currencyButtons.forEach((btn) => btn.classList.remove("active"))
      this.classList.add("active")

      // Show/hide prices
      if (currency === "MMK") {
        mmkPrices.forEach((price) => (price.style.display = "inline"))
        thbPrices.forEach((price) => (price.style.display = "none"))
      } else {
        mmkPrices.forEach((price) => (price.style.display = "none"))
        thbPrices.forEach((price) => (price.style.display = "inline"))
      }

      // Store preference
      localStorage.setItem("preferred_currency", currency)
    })
  })

  // Load saved preference
  const savedCurrency = localStorage.getItem("preferred_currency") || "MMK"
  const savedButton = document.querySelector(`[data-currency="${savedCurrency}"]`)
  if (savedButton) {
    savedButton.click()
  }
}

function initializeServicePurchase() {
  const serviceForm = document.getElementById("service-form")
  if (serviceForm) {
    serviceForm.addEventListener("submit", function (e) {
      e.preventDefault()

      const formData = new FormData(this)
      const serviceId = document.getElementById("service-id").value
      const phoneNumber = document.getElementById("service-phone").value
      const notes = document.getElementById("service-notes").value

      if (!phoneNumber.trim()) {
        showNotification("ကျေးဇူးပြု၍ ဖုန်းနံပါတ် သို့မဟုတ် Game ID ထည့်ပါ", "error")
        return
      }

      purchaseService(serviceId, phoneNumber, notes)
    })
  }
}

function showServiceModal(serviceId) {
  // Get service data
  const serviceCard = document.querySelector(`[data-service-id="${serviceId}"]`)
  if (!serviceCard) return

  const serviceName = serviceCard.querySelector("h4").textContent
  const servicePrice = serviceCard.querySelector(".price").textContent

  // Update modal content
  document.getElementById("service-id").value = serviceId
  document.getElementById("service-name").textContent = serviceName
  document.getElementById("service-price").textContent = servicePrice

  // Show modal
  document.getElementById("service-modal").style.display = "block"
}

function closeServiceModal() {
  document.getElementById("service-modal").style.display = "none"

  // Reset form
  const form = document.getElementById("service-form")
  if (form) {
    form.reset()
  }
}

function purchaseService(serviceId, phoneNumber, notes) {
  const submitButton = document.querySelector('#service-form button[type="submit"]')
  const originalText = submitButton.innerHTML

  // Show loading state
  submitButton.disabled = true
  submitButton.innerHTML = '<i class="fas fa-spinner fa-spin"></i> လုပ်ဆောင်နေသည်...'

  const requestData = {
    service_id: serviceId,
    phone_number: phoneNumber,
    notes: notes,
  }

  fetch("api/purchase_service.php", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(requestData),
  })
    .then((response) => response.json())
    .then((data) => {
      if (data.success) {
        showNotification("ဝန်ဆောင်မှု အမှာစာ အောင်မြင်ပါသည်", "success")
        closeServiceModal()

        // Redirect to orders page after 2 seconds
        setTimeout(() => {
          window.location.href = "orders.php"
        }, 2000)
      } else {
        showNotification(data.message || "အမှားတစ်ခု ဖြစ်ပွားခဲ့သည်", "error")
      }
    })
    .catch((error) => {
      console.error("Error:", error)
      showNotification("အမှားတစ်ခု ဖြစ်ပွားခဲ့သည်", "error")
    })
    .finally(() => {
      // Reset button
      submitButton.disabled = false
      submitButton.innerHTML = originalText
    })
}

function updateCartCount() {
  fetch("api/get_cart_count.php")
    .then((response) => response.json())
    .then((data) => {
      const cartCountElement = document.getElementById("cart-count")
      if (cartCountElement && data.count !== undefined) {
        cartCountElement.textContent = data.count
        cartCountElement.style.display = data.count > 0 ? "inline" : "none"
      }
    })
    .catch((error) => {
      console.error("Error updating cart count:", error)
    })
}

function showNotification(message, type = "info") {
  // Remove existing notifications
  const existingNotifications = document.querySelectorAll(".notification")
  existingNotifications.forEach((notification) => notification.remove())

  // Create notification element
  const notification = document.createElement("div")
  notification.className = `notification ${type}`
  notification.innerHTML = `
    <div class="notification-content">
      <i class="fas fa-${getNotificationIcon(type)}"></i>
      <span>${message}</span>
      <button class="notification-close" onclick="this.parentElement.parentElement.remove()">
        <i class="fas fa-times"></i>
      </button>
    </div>
  `

  // Add styles
  notification.style.cssText = `
    position: fixed;
    top: 20px;
    right: 20px;
    padding: 15px 20px;
    border-radius: 8px;
    color: white;
    font-weight: 500;
    z-index: 10000;
    transform: translateX(400px);
    transition: transform 0.3s ease;
    max-width: 400px;
    box-shadow: 0 4px 12px rgba(0,0,0,0.15);
  `

  // Set background color based on type
  const colors = {
    success: "linear-gradient(135deg, #28a745, #20c997)",
    error: "linear-gradient(135deg, #dc3545, #e74c3c)",
    warning: "linear-gradient(135deg, #ffc107, #fd7e14)",
    info: "linear-gradient(135deg, #007bff, #17a2b8)",
  }
  notification.style.background = colors[type] || colors.info

  document.body.appendChild(notification)

  // Show notification
  setTimeout(() => {
    notification.style.transform = "translateX(0)"
  }, 100)

  // Auto remove after 5 seconds
  setTimeout(() => {
    if (notification.parentNode) {
      notification.style.transform = "translateX(400px)"
      setTimeout(() => {
        if (notification.parentNode) {
          notification.remove()
        }
      }, 300)
    }
  }, 5000)
}

function getNotificationIcon(type) {
  const icons = {
    success: "check-circle",
    error: "exclamation-circle",
    warning: "exclamation-triangle",
    info: "info-circle",
  }
  return icons[type] || icons.info
}

// Close modal when clicking outside
window.addEventListener("click", (event) => {
  const modal = document.getElementById("service-modal")
  if (event.target === modal) {
    closeServiceModal()
  }
})

// Service category filtering
function filterServices(category) {
  const serviceCategories = document.querySelectorAll(".service-category")

  serviceCategories.forEach((categoryElement) => {
    if (category === "all" || categoryElement.dataset.category === category) {
      categoryElement.style.display = "block"
    } else {
      categoryElement.style.display = "none"
    }
  })
}

// Search services
function searchServices(query) {
  const serviceCards = document.querySelectorAll(".service-card")
  const searchQuery = query.toLowerCase()

  serviceCards.forEach((card) => {
    const serviceName = card.querySelector("h4").textContent.toLowerCase()
    const serviceDescription = card.querySelector("p").textContent.toLowerCase()

    if (serviceName.includes(searchQuery) || serviceDescription.includes(searchQuery)) {
      card.style.display = "block"
    } else {
      card.style.display = "none"
    }
  })
}

// Export functions for global use
window.showServiceModal = showServiceModal
window.closeServiceModal = closeServiceModal
window.filterServices = filterServices
window.searchServices = searchServices
