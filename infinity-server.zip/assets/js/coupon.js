class CouponManager {
  constructor() {
    this.appliedCoupon = null
    this.init()
  }

  init() {
    const applyCouponBtn = document.getElementById("apply-coupon-btn")
    const removeCouponBtn = document.getElementById("remove-coupon-btn")
    const couponInput = document.getElementById("coupon-code")

    if (applyCouponBtn) {
      applyCouponBtn.addEventListener("click", () => this.applyCoupon())
    }

    if (removeCouponBtn) {
      removeCouponBtn.addEventListener("click", () => this.removeCoupon())
    }

    if (couponInput) {
      couponInput.addEventListener("keypress", (e) => {
        if (e.key === "Enter") {
          e.preventDefault()
          this.applyCoupon()
        }
      })
    }
  }

  async applyCoupon() {
    const couponInput = document.getElementById("coupon-code")
    const couponCode = couponInput.value.trim()

    if (!couponCode) {
      this.showMessage("Please enter a coupon code", "error")
      return
    }

    const cartTotal = this.getCartTotal()
    if (cartTotal <= 0) {
      this.showMessage("Your cart is empty", "error")
      return
    }

    try {
      const response = await fetch("/api/apply_coupon.php", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          coupon_code: couponCode,
          cart_total: cartTotal,
        }),
      })

      const data = await response.json()

      if (data.success) {
        this.appliedCoupon = {
          code: data.coupon_code,
          discount: data.discount_amount,
        }

        this.updateCartDisplay(data.discount_amount, data.new_total)
        this.showCouponApplied(data.coupon_code, data.discount_amount)
        this.showMessage(data.message, "success")

        couponInput.value = ""
        couponInput.disabled = true
        document.getElementById("apply-coupon-btn").style.display = "none"
        document.getElementById("remove-coupon-btn").style.display = "inline-block"
      } else {
        this.showMessage(data.message, "error")
      }
    } catch (error) {
      console.error("Error applying coupon:", error)
      this.showMessage("Failed to apply coupon", "error")
    }
  }

  removeCoupon() {
    this.appliedCoupon = null

    const cartTotal = this.getOriginalCartTotal()
    this.updateCartDisplay(0, cartTotal)
    this.hideCouponApplied()

    const couponInput = document.getElementById("coupon-code")
    couponInput.disabled = false
    couponInput.value = ""

    document.getElementById("apply-coupon-btn").style.display = "inline-block"
    document.getElementById("remove-coupon-btn").style.display = "none"

    this.showMessage("Coupon removed", "info")
  }

  getCartTotal() {
    const totalElement = document.getElementById("cart-total")
    if (totalElement) {
      return Number.parseFloat(totalElement.dataset.total) || 0
    }
    return 0
  }

  getOriginalCartTotal() {
    const totalElement = document.getElementById("cart-total")
    if (totalElement) {
      return Number.parseFloat(totalElement.dataset.originalTotal) || Number.parseFloat(totalElement.dataset.total) || 0
    }
    return 0
  }

  updateCartDisplay(discountAmount, newTotal) {
    const totalElement = document.getElementById("cart-total")
    const discountElement = document.getElementById("discount-amount")

    if (totalElement) {
      if (!totalElement.dataset.originalTotal) {
        totalElement.dataset.originalTotal = totalElement.dataset.total
      }
      totalElement.dataset.total = newTotal
      totalElement.textContent = this.formatCurrency(newTotal)
    }

    if (discountElement) {
      if (discountAmount > 0) {
        discountElement.textContent = "-" + this.formatCurrency(discountAmount)
        discountElement.parentElement.style.display = "block"
      } else {
        discountElement.parentElement.style.display = "none"
      }
    }
  }

  showCouponApplied(code, discount) {
    const appliedCouponDiv = document.getElementById("applied-coupon")
    if (appliedCouponDiv) {
      appliedCouponDiv.innerHTML = `
                <div class="coupon-applied">
                    <span class="coupon-code">${code}</span>
                    <span class="coupon-discount">-${this.formatCurrency(discount)}</span>
                </div>
            `
      appliedCouponDiv.style.display = "block"
    }
  }

  hideCouponApplied() {
    const appliedCouponDiv = document.getElementById("applied-coupon")
    if (appliedCouponDiv) {
      appliedCouponDiv.style.display = "none"
    }
  }

  formatCurrency(amount) {
    return new Intl.NumberFormat("en-US").format(amount) + " MMK"
  }

  showMessage(message, type) {
    const messageDiv = document.getElementById("coupon-message")
    if (messageDiv) {
      messageDiv.textContent = message
      messageDiv.className = `message ${type}`
      messageDiv.style.display = "block"

      setTimeout(() => {
        messageDiv.style.display = "none"
      }, 5000)
    }
  }
}

// Initialize coupon manager when DOM is loaded
document.addEventListener("DOMContentLoaded", () => {
  new CouponManager()
})
