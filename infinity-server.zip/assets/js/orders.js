document.addEventListener("DOMContentLoaded", () => {
  initializeOrders()
})

function initializeOrders() {
  // Initialize order actions
  initializeOrderActions()

  // Initialize filters
  initializeFilters()

  // Initialize pagination
  initializePagination()
}

function initializeOrderActions() {
  // Cancel order buttons
  const cancelButtons = document.querySelectorAll(".btn-warning")
  cancelButtons.forEach((button) => {
    if (button.textContent.includes("Cancel")) {
      button.addEventListener("click", function () {
        const orderId = this.getAttribute("onclick").match(/\d+/)[0]
        cancelOrder(orderId)
      })
    }
  })

  // Download buttons
  const downloadButtons = document.querySelectorAll('a[href*="download.php"]')
  downloadButtons.forEach((button) => {
    button.addEventListener("click", function (e) {
      // Add loading state
      this.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Downloading...'
      this.style.pointerEvents = "none"

      // Reset after 3 seconds
      setTimeout(() => {
        this.innerHTML = '<i class="fas fa-download"></i> Download'
        this.style.pointerEvents = "auto"
      }, 3000)
    })
  })
}

function initializeFilters() {
  const filterTabs = document.querySelectorAll(".filter-tab")

  filterTabs.forEach((tab) => {
    tab.addEventListener("click", function (e) {
      // Add loading state to clicked tab
      const originalText = this.textContent
      this.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Loading...'

      // Let the navigation happen naturally
      // The loading state will be cleared when the page reloads
    })
  })
}

function initializePagination() {
  const pageButtons = document.querySelectorAll(".page-btn")

  pageButtons.forEach((button) => {
    button.addEventListener("click", function (e) {
      if (!this.classList.contains("active")) {
        // Add loading state
        const originalText = this.innerHTML
        this.innerHTML = '<i class="fas fa-spinner fa-spin"></i>'

        // Let the navigation happen naturally
      }
    })
  })
}

function cancelOrder(orderId) {
  if (!confirm("Are you sure you want to cancel this order?")) {
    return
  }

  const button = event.target
  const originalText = button.innerHTML

  // Show loading state
  button.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Cancelling...'
  button.disabled = true

  fetch("api/cancel_order.php", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      order_id: orderId,
    }),
  })
    .then((response) => response.json())
    .then((data) => {
      if (data.success) {
        showNotification("Order cancelled successfully", "success")

        // Update order status in UI
        const orderCard = button.closest(".order-card")
        const statusBadge = orderCard.querySelector(".status-badge")
        statusBadge.className = "status-badge status-cancelled"
        statusBadge.textContent = "Cancelled"

        // Remove cancel button
        button.remove()

        // Add note
        const orderDetails = orderCard.querySelector(".order-details")
        const note = document.createElement("div")
        note.className = "order-note"
        note.innerHTML = `
                <i class="fas fa-info-circle"></i>
                <span>This order has been cancelled.</span>
            `
        orderDetails.appendChild(note)
      } else {
        showNotification(data.message || "Failed to cancel order", "error")

        // Reset button
        button.innerHTML = originalText
        button.disabled = false
      }
    })
    .catch((error) => {
      console.error("Error:", error)
      showNotification("An error occurred while cancelling the order", "error")

      // Reset button
      button.innerHTML = originalText
      button.disabled = false
    })
}

function showNotification(message, type = "info") {
  // Remove existing notifications
  const existingNotifications = document.querySelectorAll(".notification")
  existingNotifications.forEach((notification) => notification.remove())

  // Create notification element
  const notification = document.createElement("div")
  notification.className = `notification ${type}`
  notification.innerHTML = `
        <div class="notification-content">
            <i class="fas fa-${getNotificationIcon(type)}"></i>
            <span>${message}</span>
            <button class="notification-close" onclick="this.parentElement.parentElement.remove()">
                <i class="fas fa-times"></i>
            </button>
        </div>
    `

  // Add styles
  notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        padding: 15px 20px;
        border-radius: 8px;
        color: white;
        font-weight: 500;
        z-index: 10000;
        transform: translateX(400px);
        transition: transform 0.3s ease;
        max-width: 400px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
    `

  // Set background color based on type
  const colors = {
    success: "linear-gradient(135deg, #28a745, #20c997)",
    error: "linear-gradient(135deg, #dc3545, #e74c3c)",
    warning: "linear-gradient(135deg, #ffc107, #fd7e14)",
    info: "linear-gradient(135deg, #007bff, #17a2b8)",
  }
  notification.style.background = colors[type] || colors.info

  document.body.appendChild(notification)

  // Show notification
  setTimeout(() => {
    notification.style.transform = "translateX(0)"
  }, 100)

  // Auto remove after 5 seconds
  setTimeout(() => {
    if (notification.parentNode) {
      notification.style.transform = "translateX(400px)"
      setTimeout(() => {
        if (notification.parentNode) {
          notification.remove()
        }
      }, 300)
    }
  }, 5000)
}

function getNotificationIcon(type) {
  const icons = {
    success: "check-circle",
    error: "exclamation-circle",
    warning: "exclamation-triangle",
    info: "info-circle",
  }
  return icons[type] || icons.info
}

// Order tracking functionality
function trackOrder(orderId) {
  fetch(`api/track_order.php?order_id=${orderId}`)
    .then((response) => response.json())
    .then((data) => {
      if (data.success) {
        showOrderTrackingModal(data.tracking_info)
      } else {
        showNotification("Unable to track order", "error")
      }
    })
    .catch((error) => {
      console.error("Error:", error)
      showNotification("Error tracking order", "error")
    })
}

function showOrderTrackingModal(trackingInfo) {
  const modal = document.createElement("div")
  modal.className = "modal"
  modal.innerHTML = `
        <div class="modal-content">
            <span class="close" onclick="this.parentElement.parentElement.remove()">&times;</span>
            <h3>Order Tracking</h3>
            <div class="tracking-timeline">
                ${trackingInfo
                  .map(
                    (info) => `
                    <div class="tracking-step ${info.completed ? "completed" : ""}">
                        <div class="step-icon">
                            <i class="fas fa-${info.icon}"></i>
                        </div>
                        <div class="step-content">
                            <h4>${info.title}</h4>
                            <p>${info.description}</p>
                            ${info.date ? `<small>${info.date}</small>` : ""}
                        </div>
                    </div>
                `,
                  )
                  .join("")}
            </div>
        </div>
    `

  document.body.appendChild(modal)
  modal.style.display = "block"
}

// Export functions for global use
window.cancelOrder = cancelOrder
window.trackOrder = trackOrder
