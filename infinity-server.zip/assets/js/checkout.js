document.addEventListener("DOMContentLoaded", () => {
  initializeCurrencySelector()
  initializeCheckoutForm()
  initializePaymentMethods()

  // Form validation
  function validateForm() {
    const requiredFields = document.querySelectorAll("#checkout-form [required]")
    let isValid = true

    requiredFields.forEach((field) => {
      if (!field.value.trim()) {
        isValid = false
        field.classList.add("error")
      } else {
        field.classList.remove("error")
      }
    })

    return isValid
  }

  // Payment method selection
  const paymentMethods = document.querySelectorAll('input[name="payment_method"]')
  paymentMethods.forEach((method) => {
    method.addEventListener("change", function () {
      // Remove active class from all payment options
      document.querySelectorAll(".payment-option").forEach((option) => {
        option.classList.remove("active")
      })

      // Add active class to selected option
      this.closest(".payment-option").classList.add("active")
    })
  })

  // Real-time form validation
  const inputs = document.querySelectorAll("#checkout-form input, #checkout-form select, #checkout-form textarea")
  inputs.forEach((input) => {
    input.addEventListener("blur", function () {
      if (this.hasAttribute("required") && !this.value.trim()) {
        this.classList.add("error")
      } else {
        this.classList.remove("error")
      }
    })

    input.addEventListener("input", function () {
      if (this.classList.contains("error") && this.value.trim()) {
        this.classList.remove("error")
      }
    })
  })

  // Email validation
  const emailInput = document.getElementById("email")
  if (emailInput) {
    emailInput.addEventListener("blur", function () {
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
      if (this.value && !emailRegex.test(this.value)) {
        this.classList.add("error")
        showNotification("Please enter a valid email address", "error")
      }
    })
  }

  // Phone validation
  const phoneInput = document.getElementById("phone")
  if (phoneInput) {
    phoneInput.addEventListener("input", function () {
      // Remove non-numeric characters except +, -, (, ), and spaces
      this.value = this.value.replace(/[^0-9+\-\s()]/g, "")
    })
  }

  // Auto-save form data to localStorage
  function saveFormData() {
    const formData = new FormData(document.getElementById("checkout-form"))
    const data = {}

    for (const [key, value] of formData.entries()) {
      if (key !== "csrf_token") {
        data[key] = value
      }
    }

    localStorage.setItem("checkout_form_data", JSON.stringify(data))
  }

  // Load saved form data
  function loadFormData() {
    const savedData = localStorage.getItem("checkout_form_data")
    if (savedData) {
      try {
        const data = JSON.parse(savedData)

        Object.keys(data).forEach((key) => {
          const field = document.querySelector(`#checkout-form [name="${key}"]`)
          if (field && field.type !== "radio" && field.type !== "checkbox") {
            field.value = data[key]
          } else if (field && field.type === "radio" && field.value === data[key]) {
            field.checked = true
            field.dispatchEvent(new Event("change"))
          } else if (field && field.type === "checkbox" && data[key] === "on") {
            field.checked = true
          }
        })
      } catch (e) {
        console.error("Error loading saved form data:", e)
      }
    }
  }

  // Save form data on input
  inputs.forEach((input) => {
    input.addEventListener("input", saveFormData)
    input.addEventListener("change", saveFormData)
  })

  // Load saved data on page load
  loadFormData()

  // Clear saved data on successful submission
  document.getElementById("checkout-form").addEventListener("submit", () => {
    localStorage.removeItem("checkout_form_data")
  })
})

function initializeCurrencySelector() {
  const currencyButtons = document.querySelectorAll(".currency-btn")
  const mmkElements = document.querySelectorAll(".mmk-price, .mmk-total")
  const thbElements = document.querySelectorAll(".thb-price, .thb-total")
  const currencyInput = document.getElementById("selected-currency")

  currencyButtons.forEach((btn) => {
    btn.addEventListener("click", function () {
      const currency = this.dataset.currency

      // Update active button
      currencyButtons.forEach((b) => b.classList.remove("active"))
      this.classList.add("active")

      // Show/hide prices
      if (currency === "MMK") {
        mmkElements.forEach((el) => (el.style.display = "inline"))
        thbElements.forEach((el) => (el.style.display = "none"))
      } else {
        mmkElements.forEach((el) => (el.style.display = "none"))
        thbElements.forEach((el) => (el.style.display = "inline"))
      }

      // Update form currency
      if (currencyInput) {
        currencyInput.value = currency
      }

      // Store preference
      localStorage.setItem("preferred_currency", currency)
    })
  })

  // Load saved preference
  const savedCurrency = localStorage.getItem("preferred_currency") || "MMK"
  const savedCurrencyBtn = document.querySelector(`[data-currency="${savedCurrency}"]`)
  if (savedCurrencyBtn) {
    savedCurrencyBtn.click()
  }
}

function initializeCheckoutForm() {
  const checkoutForm = document.getElementById("checkout-form")
  const checkoutBtn = document.querySelector(".checkout-btn")

  if (checkoutForm) {
    checkoutForm.addEventListener("submit", (e) => {
      e.preventDefault()

      const validateForm = () => {
        const requiredFields = document.querySelectorAll("#checkout-form [required]")
        let isValid = true

        requiredFields.forEach((field) => {
          if (!field.value.trim()) {
            isValid = false
            field.classList.add("error")
          } else {
            field.classList.remove("error")
          }
        })

        return isValid
      }

      if (!validateForm()) {
        showNotification("Please fill in all required fields", "error")
        return
      }

      // Show loading state
      checkoutBtn.classList.add("loading")
      checkoutBtn.disabled = true

      // Create FormData object
      const formData = new FormData(checkoutForm)

      // Submit form
      fetch("api/create_order.php", {
        method: "POST",
        body: formData,
      })
        .then((response) => response.json())
        .then((data) => {
          if (data.success) {
            showNotification("Order placed successfully!", "success")

            // Redirect to order confirmation page
            setTimeout(() => {
              window.location.href = `order_details.php?id=${data.order_id}`
            }, 2000)
          } else {
            throw new Error(data.message || "Failed to place order")
          }
        })
        .catch((error) => {
          console.error("Checkout error:", error)
          showNotification(error.message || "Failed to place order", "error")
        })
        .finally(() => {
          // Remove loading state
          checkoutBtn.classList.remove("loading")
          checkoutBtn.disabled = false
        })
    })
  }
}

function initializePaymentMethods() {
  const paymentMethods = document.querySelectorAll('input[name="payment_method"]')

  paymentMethods.forEach((method) => {
    method.addEventListener("change", function () {
      // Update UI based on selected payment method
      updatePaymentMethodUI(this.value)
    })
  })
}

function updatePaymentMethodUI(method) {
  // Add any specific UI updates based on payment method
  console.log("Selected payment method:", method)
}

function showPaymentModal(orderId, paymentMethod, amount, currency) {
  // Create modal HTML
  const modalHTML = `
      <div id="payment-modal" class="qr-modal">
          <div class="qr-modal-content">
              <span class="close" onclick="closePaymentModal()">&times;</span>
              <h3>ငွေပေးချေမှု</h3>
              <div class="payment-info">
                  <p><strong>အော်ဒါ ID:</strong> ${orderId}</p>
                  <p><strong>ပမာဏ:</strong> ${formatCurrency(amount, currency)}</p>
              </div>
              <div class="qr-code-container">
                  <img src="assets/qr/${paymentMethod}.png" alt="${paymentMethod} QR Code" id="qr-image">
              </div>
              <div class="payment-instructions">
                  <h4>ငွေပေးချေရန် လမ်းညွှန်ချက်များ:</h4>
                  <ol>
                      <li>အထက်ပါ QR Code ကို scan လုပ်ပါ</li>
                      <li>ပမာဏ ${formatCurrency(amount, currency)} ကို ပေးချေပါ</li>
                      <li>ငွေပေးချေပြီးပါက အောက်ပါ "ငွေပေးချေပြီး" ခလုတ်ကို နှိပ်ပါ</li>
                      <li>Admin မှ အတည်ပြုပါမည်</li>
                  </ol>
              </div>
              <button class="confirm-payment-btn" onclick="confirmPayment('${orderId}')">
                  <i class="fas fa-check"></i> ငွေပေးချေပြီး
              </button>
          </div>
      </div>
  `

  // Add modal to page
  document.body.insertAdjacentHTML("beforeend", modalHTML)

  // Show modal
  document.getElementById("payment-modal").style.display = "block"
}

function closePaymentModal() {
  const modal = document.getElementById("payment-modal")
  if (modal) {
    modal.remove()
  }
}

function confirmPayment(orderId) {
  const confirmBtn = document.querySelector(".confirm-payment-btn")
  confirmBtn.disabled = true
  confirmBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> အတည်ပြုနေသည်...'

  fetch("api/confirm_payment.php", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ order_id: orderId }),
  })
    .then((response) => response.json())
    .then((data) => {
      if (data.success) {
        closePaymentModal()
        showOrderSuccess(orderId)
        // Clear cart
        clearCart()
      } else {
        showNotification(data.message || "အမှားတစ်ခု ဖြစ်ပွားခဲ့သည်", "error")
      }
    })
    .catch((error) => {
      console.error("Error:", error)
      showNotification("အမှားတစ်ခု ဖြစ်ပွားခဲ့သည်", "error")
    })
    .finally(() => {
      confirmBtn.disabled = false
      confirmBtn.innerHTML = '<i class="fas fa-check"></i> ငွေပေးချေပြီး'
    })
}

function showOrderSuccess(orderId) {
  const successHTML = `
      <div class="order-success">
          <div class="success-icon">
              <i class="fas fa-check-circle"></i>
          </div>
          <div class="success-message">
              <h3>အော်ဒါ အောင်မြင်ပါသည်!</h3>
              <p>သင့်အော်ဒါကို လက်ခံရရှိပါပြီ</p>
          </div>
          <div class="order-id">
              အော်ဒါ ID: ${orderId}
          </div>
          <div class="success-actions">
              <a href="orders.php" class="btn-primary">
                  <i class="fas fa-list"></i> အော်ဒါများကြည့်ရန်
              </a>
              <a href="index.php" class="btn-secondary">
                  <i class="fas fa-home"></i> ပင်မစာမျက်နှာ
              </a>
          </div>
      </div>
  `

  // Replace checkout content with success message
  const checkoutContainer = document.querySelector(".checkout-content")
  if (checkoutContainer) {
    checkoutContainer.innerHTML = successHTML
  }
}

function clearCart() {
  // Update cart count in header
  const cartCount = document.getElementById("cart-count")
  if (cartCount) {
    cartCount.textContent = "0"
  }
}

function formatCurrency(amount, currency) {
  if (currency === "MMK") {
    return new Intl.NumberFormat("my-MM").format(amount) + " ကျပ်"
  } else {
    return new Intl.NumberFormat("th-TH").format(amount) + " ฿"
  }
}

function showNotification(message, type = "info") {
  // Remove existing notifications
  const existingNotifications = document.querySelectorAll(".notification")
  existingNotifications.forEach((notification) => notification.remove())

  // Create notification element
  const notification = document.createElement("div")
  notification.className = `notification ${type}`
  notification.innerHTML = `
      <div class="notification-content">
          <span class="notification-message">${message}</span>
          <button class="notification-close">&times;</button>
      </div>
  `

  // Add to page
  document.body.appendChild(notification)

  // Auto remove after 5 seconds
  setTimeout(() => {
    if (notification.parentNode) {
      notification.remove()
    }
  }, 5000)

  // Close button functionality
  const closeBtn = notification.querySelector(".notification-close")
  closeBtn.addEventListener("click", () => {
    notification.remove()
  })

  // Show notification
  setTimeout(() => {
    notification.classList.add("show")
  }, 100)
}

// Close modal when clicking outside
window.onclick = (event) => {
  const modal = document.getElementById("payment-modal")
  if (event.target === modal) {
    closePaymentModal()
  }
}

// Add notification styles
const notificationStyles = `
    .notification {
        position: fixed;
        top: 20px;
        right: 20px;
        padding: 15px 20px;
        border-radius: 8px;
        color: white;
        font-weight: 500;
        z-index: 10000;
        transform: translateX(400px);
        transition: transform 0.3s ease;
        max-width: 400px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
    }
    
    .notification.show {
        transform: translateX(0);
    }
    
    .notification.success {
        background: linear-gradient(135deg, #28a745, #20c997);
    }
    
    .notification.error {
        background: linear-gradient(135deg, #dc3545, #e74c3c);
    }
    
    .notification.info {
        background: linear-gradient(135deg, #007bff, #17a2b8);
    }
    
    .notification-content {
        display: flex;
        align-items: center;
        justify-content: space-between;
    }
    
    .notification-close {
        background: none;
        border: none;
        color: white;
        font-size: 20px;
        cursor: pointer;
        margin-left: 15px;
        padding: 0;
        line-height: 1;
    }
    
    .notification-close:hover {
        opacity: 0.8;
    }
    
    .form-group input.error,
    .form-group select.error,
    .form-group textarea.error {
        border-color: #dc3545;
        box-shadow: 0 0 0 3px rgba(220,53,69,0.1);
    }
    
    .payment-option.active {
        border-color: #007bff;
        background-color: #f8f9ff;
    }
    
    @media (max-width: 480px) {
        .notification {
            top: 10px;
            right: 10px;
            left: 10px;
            max-width: none;
            transform: translateY(-100px);
        }
        
        .notification.show {
            transform: translateY(0);
        }
    }
`

// Inject notification styles
const styleSheet = document.createElement("style")
styleSheet.textContent = notificationStyles
document.head.appendChild(styleSheet)
