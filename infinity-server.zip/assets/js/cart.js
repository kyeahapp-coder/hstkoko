// Cart page specific JavaScript
document.addEventListener("DOMContentLoaded", () => {
  initializeCart()
})

function initializeCart() {
  setupCurrencyToggle()
  updateCartDisplay()
}

function setupCurrencyToggle() {
  const currencyButtons = document.querySelectorAll(".currency-btn")

  currencyButtons.forEach((btn) => {
    btn.addEventListener("click", function () {
      const currency = this.dataset.currency

      // Update active button
      currencyButtons.forEach((b) => b.classList.remove("active"))
      this.classList.add("active")

      // Show/hide prices
      if (currency === "MMK") {
        document.querySelectorAll(".price-mmk, .subtotal-mmk, .discount-mmk, .total-mmk, .total-mmk").forEach((el) => {
          el.style.display = "inline"
        })
        document.querySelectorAll(".price-thb, .subtotal-thb, .discount-thb, .total-thb, .total-thb").forEach((el) => {
          el.style.display = "none"
        })
      } else {
        document.querySelectorAll(".price-mmk, .subtotal-mmk, .discount-mmk, .total-mmk, .total-mmk").forEach((el) => {
          el.style.display = "none"
        })
        document.querySelectorAll(".price-thb, .subtotal-thb, .discount-thb, .total-thb, .total-thb").forEach((el) => {
          el.style.display = "inline"
        })
      }
    })
  })
}

function updateQuantity(imageId, change) {
  const cartItem = document.querySelector(`[data-image-id="${imageId}"]`)
  const quantityInput = cartItem.querySelector('input[type="number"]')
  const currentQuantity = Number.parseInt(quantityInput.value)
  const newQuantity = Math.max(1, currentQuantity + change)

  setQuantity(imageId, newQuantity)
}

function setQuantity(imageId, quantity) {
  quantity = Math.max(1, Number.parseInt(quantity))

  fetch("api/update_cart_quantity.php", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      image_id: imageId,
      quantity: quantity,
    }),
  })
    .then((response) => response.json())
    .then((data) => {
      if (data.success) {
        // Update quantity input
        const cartItem = document.querySelector(`[data-image-id="${imageId}"]`)
        const quantityInput = cartItem.querySelector('input[type="number"]')
        quantityInput.value = quantity

        // Reload page to update totals
        location.reload()
      } else {
        showNotification(data.message || "Failed to update quantity", "error")
      }
    })
    .catch((error) => {
      console.error("Error:", error)
      showNotification("An error occurred", "error")
    })
}

function removeFromCart(imageId) {
  if (!confirm("Are you sure you want to remove this item from your cart?")) {
    return
  }

  fetch("api/remove_from_cart.php", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      image_id: imageId,
    }),
  })
    .then((response) => response.json())
    .then((data) => {
      if (data.success) {
        // Remove item from DOM
        const cartItem = document.querySelector(`[data-image-id="${imageId}"]`)
        cartItem.remove()

        // Update cart count
        updateCartCount()

        // Check if cart is empty
        const remainingItems = document.querySelectorAll(".cart-item")
        if (remainingItems.length === 0) {
          location.reload()
        } else {
          // Recalculate totals
          location.reload()
        }

        showNotification("Item removed from cart", "success")
      } else {
        showNotification(data.message || "Failed to remove item", "error")
      }
    })
    .catch((error) => {
      console.error("Error:", error)
      showNotification("An error occurred", "error")
    })
}

function clearCart() {
  if (!confirm("Are you sure you want to clear your entire cart?")) {
    return
  }

  fetch("api/clear_cart.php", {
    method: "POST",
  })
    .then((response) => response.json())
    .then((data) => {
      if (data.success) {
        location.reload()
      } else {
        showNotification(data.message || "Failed to clear cart", "error")
      }
    })
    .catch((error) => {
      console.error("Error:", error)
      showNotification("An error occurred", "error")
    })
}

function updateCartDisplay() {
  // Update cart count in header if exists
  updateCartCount()
}

function updateCartCount() {
  fetch("api/get_cart_count.php")
    .then((response) => response.json())
    .then((data) => {
      if (data.success) {
        const cartCountElements = document.querySelectorAll(".cart-count")
        cartCountElements.forEach((el) => {
          el.textContent = data.count
          el.style.display = data.count > 0 ? "inline" : "none"
        })
      }
    })
    .catch((error) => {
      console.error("Error updating cart count:", error)
    })
}

function showNotification(message, type = "info") {
  // Create notification element
  const notification = document.createElement("div")
  notification.className = `notification ${type}`
  notification.innerHTML = `
      <i class="fas fa-${type === "error" ? "exclamation-circle" : type === "success" ? "check-circle" : "info-circle"}"></i>
      ${message}
  `

  // Add to page
  document.body.appendChild(notification)

  // Show notification
  setTimeout(() => {
    notification.classList.add("show")
  }, 100)

  // Hide after 3 seconds
  setTimeout(() => {
    notification.classList.remove("show")
    setTimeout(() => {
      notification.remove()
    }, 300)
  }, 3000)
}

function loadCartItems() {
  const cartItemsContainer = document.getElementById("cart-items")
  const cart = JSON.parse(localStorage.getItem("cart")) || []

  if (cart.length === 0) {
    cartItemsContainer.innerHTML = `
            <div class="empty-cart">
                <i class="fas fa-shopping-cart" style="font-size: 4rem; color: #bdc3c7; margin-bottom: 1rem;"></i>
                <h3>ခြင်းတောင်းထဲတွင် ပစ္စည်းမရှိပါ</h3>
                <p>ဓာတ်ပုံများကို ရွေးချယ်ပြီး ခြင်းတောင်းထဲ ထည့်ပါ</p>
                <a href="index.php" class="btn-primary">ဓာတ်ပုံများကြည့်ရန်</a>
            </div>
        `
    return
  }

  let cartHTML = ""
  cart.forEach((item, index) => {
    cartHTML += `
            <div class="cart-item" data-image-id="${item.id}">
                <img src="${item.imageSrc}" alt="${item.title}">
                <div class="cart-item-info">
                    <h4>${item.title}</h4>
                    <div class="item-price">
                        <span class="price-mmk">${item.mmkPrice}</span>
                        <span class="price-thb" style="display: none;">${item.thbPrice}</span>
                    </div>
                </div>
                <input type="number" value="${item.quantity}" min="1" onchange="updateQuantity('${item.id}', this.value - ${item.quantity})">
                <button class="remove-item" onclick="removeFromCart('${item.id}')">
                    <i class="fas fa-trash"></i>
                </button>
            </div>
        `
  })

  cartItemsContainer.innerHTML = cartHTML
  calculateTotal()
}

function calculateTotal() {
  const cart = JSON.parse(localStorage.getItem("cart")) || []
  const currency = document.querySelector(".currency-btn.active").dataset.currency

  let subtotal = 0
  cart.forEach((item) => {
    if (currency === "MMK") {
      const price = Number.parseFloat(item.mmkPrice.replace(/[^\d.]/g, ""))
      subtotal += price * item.quantity
    } else {
      const price = Number.parseFloat(item.thbPrice.replace(/[^\d.]/g, ""))
      subtotal += price * item.quantity
    }
  })

  const quantity = cart.reduce((sum, item) => sum + item.quantity, 0)
  const discountPercent = calculateDiscount(quantity)
  const discountAmount = subtotal * (discountPercent / 100)
  const finalTotal = subtotal - discountAmount

  // Update display
  document.getElementById("subtotal").textContent = formatCurrency(subtotal, currency)

  if (discountPercent > 0) {
    document.querySelector(".discount-row").style.display = "flex"
    document.getElementById("discount-percent").textContent = discountPercent
    document.getElementById("discount-amount").textContent = "-" + formatCurrency(discountAmount, currency)
  } else {
    document.querySelector(".discount-row").style.display = "none"
  }

  document.getElementById("final-total").textContent = formatCurrency(finalTotal, currency)

  // Store for checkout
  window.cartTotal = {
    subtotal: subtotal,
    discount: discountAmount,
    total: finalTotal,
    currency: currency,
    quantity: quantity,
  }
}

function initializePaymentButtons() {
  const paymentButtons = document.querySelectorAll(".payment-btn")
  const checkoutBtn = document.getElementById("checkout-btn")

  let selectedPaymentMethod = null

  paymentButtons.forEach((btn) => {
    btn.addEventListener("click", function () {
      paymentButtons.forEach((b) => b.classList.remove("active"))
      this.classList.add("active")
      selectedPaymentMethod = this.dataset.method
      checkoutBtn.disabled = false
    })
  })

  checkoutBtn.addEventListener("click", () => {
    if (!selectedPaymentMethod) {
      showNotification("ငွေပေးချေမှုနည်းလမ်း ရွေးချယ်ပါ", "error")
      return
    }

    const cart = JSON.parse(localStorage.getItem("cart")) || []
    if (cart.length === 0) {
      showNotification("ခြင်းတောင်းထဲတွင် ပစ္စည်းမရှိပါ", "error")
      return
    }

    processCheckout(selectedPaymentMethod)
  })
}

function processCheckout(paymentMethod) {
  const total = window.cartTotal

  // Show QR code modal
  showQRModal(paymentMethod, total.total, total.currency)

  // Create order in database
  createOrder(paymentMethod, total)
}

function createOrder(paymentMethod, total) {
  const cart = JSON.parse(localStorage.getItem("cart")) || []
  const orderData = {
    items: cart,
    payment_method: paymentMethod,
    total: total.total,
    currency: total.currency,
    subtotal: total.subtotal,
    discount: total.discount,
  }

  fetch("api/create_order.php", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(orderData),
  })
    .then((response) => response.json())
    .then((data) => {
      if (data.success) {
        window.currentOrderId = data.order_id
        window.currentOrderUID = data.order_uid
      } else {
        showNotification("အမှားတစ်ခု ဖြစ်ပွားခဲ့သည်", "error")
      }
    })
    .catch((error) => {
      console.error("Error:", error)
      showNotification("အမှားတစ်ခု ဖြစ်ပွားခဲ့သည်", "error")
    })
}

function confirmPayment() {
  if (!window.currentOrderId) {
    showNotification("အမှားတစ်ခု ဖြစ်ပွားခဲ့သည်", "error")
    return
  }

  // Update order status
  fetch("api/confirm_payment.php", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      order_id: window.currentOrderId,
    }),
  })
    .then((response) => response.json())
    .then((data) => {
      if (data.success) {
        // Clear cart
        localStorage.removeItem("cart")

        // Show success message
        showNotification("ငွေပေးချေမှု အောင်မြင်ပါသည်။ Admin မှ အတည်ပြုပြီးပါက ဒေါင်းလုပ်နိုင်ပါမည်။")

        // Redirect to orders page
        setTimeout(() => {
          window.location.href = "orders.php"
        }, 2000)
      } else {
        showNotification("အမှားတစ်ခု ဖြစ်ပွားခဲ့သည်", "error")
      }
    })
    .catch((error) => {
      console.error("Error:", error)
      showNotification("အမှားတစ်ခု ဖြစ်ပွားခဲ့သည်", "error")
    })

  closeQRModal()
}

function calculateDiscount(quantity) {
  if (quantity >= 10) return 15
  if (quantity >= 5) return 10
  if (quantity >= 2) return 5
  return 0
}

function formatCurrency(amount, currency) {
  if (currency === "MMK") {
    return Math.round(amount).toLocaleString() + " ကျပ်"
  } else {
    return amount.toFixed(2) + " ฿"
  }
}

function showQRModal(paymentMethod, total, currency) {
  console.log(`QR Modal for ${paymentMethod}: ${total} ${currency}`)
}

function closeQRModal() {
  console.log("QR Modal closed")
}
