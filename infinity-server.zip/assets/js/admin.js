// Admin Panel JavaScript
document.addEventListener("DOMContentLoaded", () => {
  initializeAdminFeatures()
  initializeBulkActions()
  initializeAdmin()
})

function initializeAdminFeatures() {
  // Initialize tooltips
  initializeTooltips()

  // Initialize file uploads
  initializeFileUploads()

  // Initialize form validations
  initializeFormValidations()

  // Initialize data tables
  initializeDataTables()
}

function approveOrder(orderId) {
  if (!confirm("ဤအော်ဒါကို အတည်ပြုမှာ သေချာပါသလား?")) {
    return
  }

  const button = event.target.closest(".btn-approve")
  const originalText = button.innerHTML
  button.innerHTML = '<span class="loading-spinner"></span> လုပ်ဆောင်နေသည်...'
  button.disabled = true

  fetch("api/approve_order.php", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ order_id: orderId }),
  })
    .then((response) => response.json())
    .then((data) => {
      if (data.success) {
        showAdminNotification("အော်ဒါကို အတည်ပြုပြီးပါပြီ", "success")

        // Update UI
        const row = button.closest("tr")
        const statusCell = row.querySelector(".status-badge")
        statusCell.className = "status-badge approved"
        statusCell.textContent = "အတည်ပြုပြီး"

        // Remove approve button
        button.remove()
      } else {
        showAdminNotification("အမှားတစ်ခု ဖြစ်ပွားခဲ့သည်", "error")
        button.innerHTML = originalText
        button.disabled = false
      }
    })
    .catch((error) => {
      console.error("Error:", error)
      showAdminNotification("အမှားတစ်ခု ဖြစ်ပွားခဲ့သည်", "error")
      button.innerHTML = originalText
      button.disabled = false
    })
}

function showAdminNotification(message, type = "info") {
  const notification = document.createElement("div")
  notification.className = `alert alert-${type}`
  notification.textContent = message

  // Insert at top of admin content
  const adminContent = document.querySelector(".admin-content")
  adminContent.insertBefore(notification, adminContent.firstChild)

  // Auto remove after 5 seconds
  setTimeout(() => {
    notification.remove()
  }, 5000)
}

function initializeFileUploads() {
  const fileInputs = document.querySelectorAll('input[type="file"]')

  fileInputs.forEach((input) => {
    const uploadArea = input.closest(".image-upload")
    if (!uploadArea) return

    // Drag and drop functionality
    uploadArea.addEventListener("dragover", function (e) {
      e.preventDefault()
      this.classList.add("dragover")
    })

    uploadArea.addEventListener("dragleave", function (e) {
      e.preventDefault()
      this.classList.remove("dragover")
    })

    uploadArea.addEventListener("drop", function (e) {
      e.preventDefault()
      this.classList.remove("dragover")

      const files = e.dataTransfer.files
      if (files.length > 0) {
        input.files = files
        handleFilePreview(input, files[0])
      }
    })

    // File input change
    input.addEventListener("change", function () {
      if (this.files.length > 0) {
        handleFilePreview(this, this.files[0])
      }
    })
  })
}

function handleFilePreview(input, file) {
  if (file.type.startsWith("image/")) {
    const reader = new FileReader()
    reader.onload = (e) => {
      let preview = input.parentNode.querySelector(".image-preview")
      if (!preview) {
        preview = document.createElement("div")
        preview.className = "image-preview"
        input.parentNode.appendChild(preview)
      }

      preview.innerHTML = `
                <img src="${e.target.result}" alt="Preview" style="max-width: 200px; max-height: 200px; border-radius: 8px;">
                <p>${file.name}</p>
            `
    }
    reader.readAsDataURL(file)
  }
}

function initializeFormValidations() {
  const forms = document.querySelectorAll(".admin-form")

  forms.forEach((form) => {
    form.addEventListener("submit", function (e) {
      if (!validateAdminForm(this)) {
        e.preventDefault()
      }
    })
  })
}

function validateAdminForm(form) {
  const requiredFields = form.querySelectorAll("[required]")
  let isValid = true

  requiredFields.forEach((field) => {
    if (!field.value.trim()) {
      field.style.borderColor = "#e74c3c"
      isValid = false
    } else {
      field.style.borderColor = "#e9ecef"
    }
  })

  if (!isValid) {
    showAdminNotification("ကျေးဇူးပြု၍ လိုအပ်သော အချက်အလက်များကို ဖြည့်စွက်ပါ", "error")
  }

  return isValid
}

function initializeDataTables() {
  // Add search functionality to tables
  const tables = document.querySelectorAll(".admin-table")

  tables.forEach((table) => {
    const container = table.closest(".table-container")
    if (!container) return

    // Add search input
    const searchContainer = document.createElement("div")
    searchContainer.className = "table-search"
    searchContainer.innerHTML = `
            <input type="text" placeholder="ရှာဖွေရန်..." class="form-control" style="max-width: 300px; margin-bottom: 1rem;">
        `

    container.insertBefore(searchContainer, table)

    const searchInput = searchContainer.querySelector("input")
    searchInput.addEventListener("input", function () {
      filterTable(table, this.value)
    })
  })
}

function filterTable(table, searchTerm) {
  const rows = table.querySelectorAll("tbody tr")

  rows.forEach((row) => {
    const text = row.textContent.toLowerCase()
    if (text.includes(searchTerm.toLowerCase())) {
      row.style.display = ""
    } else {
      row.style.display = "none"
    }
  })
}

function initializeTooltips() {
  // Simple tooltip implementation
  const tooltipElements = document.querySelectorAll("[data-tooltip]")

  tooltipElements.forEach((element) => {
    element.addEventListener("mouseenter", function () {
      const tooltip = document.createElement("div")
      tooltip.className = "tooltip"
      tooltip.textContent = this.dataset.tooltip
      tooltip.style.cssText = `
                position: absolute;
                background: #2c3e50;
                color: white;
                padding: 0.5rem;
                border-radius: 4px;
                font-size: 0.8rem;
                z-index: 1000;
                pointer-events: none;
            `

      document.body.appendChild(tooltip)

      const rect = this.getBoundingClientRect()
      tooltip.style.left = rect.left + "px"
      tooltip.style.top = rect.top - tooltip.offsetHeight - 5 + "px"

      this._tooltip = tooltip
    })

    element.addEventListener("mouseleave", function () {
      if (this._tooltip) {
        this._tooltip.remove()
        this._tooltip = null
      }
    })
  })
}

// Bulk actions
function initializeBulkActions() {
  const selectAllCheckbox = document.getElementById("select-all")
  const itemCheckboxes = document.querySelectorAll(".item-checkbox")
  const bulkActionSelect = document.getElementById("bulk-action")
  const bulkActionButton = document.getElementById("bulk-action-btn")

  if (selectAllCheckbox) {
    selectAllCheckbox.addEventListener("change", function () {
      itemCheckboxes.forEach((checkbox) => {
        checkbox.checked = this.checked
      })
      updateBulkActionButton()
    })
  }

  itemCheckboxes.forEach((checkbox) => {
    checkbox.addEventListener("change", updateBulkActionButton)
  })

  if (bulkActionButton) {
    bulkActionButton.addEventListener("click", () => {
      const selectedItems = Array.from(itemCheckboxes)
        .filter((cb) => cb.checked)
        .map((cb) => cb.value)

      if (selectedItems.length === 0) {
        showAdminNotification("ကျေးဇူးပြု၍ အနည်းဆုံး တစ်ခုကို ရွေးချယ်ပါ", "warning")
        return
      }

      const action = bulkActionSelect.value
      if (!action) {
        showAdminNotification("လုပ်ဆောင်ချက်တစ်ခု ရွေးချယ်ပါ", "warning")
        return
      }

      performBulkAction(action, selectedItems)
    })
  }
}

function updateBulkActionButton() {
  const selectedCount = document.querySelectorAll(".item-checkbox:checked").length
  const bulkActionButton = document.getElementById("bulk-action-btn")

  if (bulkActionButton) {
    if (selectedCount > 0) {
      bulkActionButton.textContent = `လုပ်ဆောင်ရန် (${selectedCount})`
      bulkActionButton.disabled = false
    } else {
      bulkActionButton.textContent = "လုပ်ဆောင်ရန်"
      bulkActionButton.disabled = true
    }
  }
}

function performBulkAction(action, selectedItems) {
  if (!confirm(`ရွေးချယ်ထားသော ${selectedItems.length} ခုအတွက် ${action} လုပ်ဆောင်မှာ သေချာပါသလား?`)) {
    return
  }

  fetch("api/bulk_action.php", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      action: action,
      items: selectedItems,
    }),
  })
    .then((response) => response.json())
    .then((data) => {
      if (data.success) {
        showAdminNotification("လုပ်ဆောင်ချက် အောင်မြင်ပါသည်", "success")
        setTimeout(() => {
          location.reload()
        }, 1500)
      } else {
        showAdminNotification("အမှားတစ်ခု ဖြစ်ပွားခဲ့သည်", "error")
      }
    })
    .catch((error) => {
      console.error("Error:", error)
      showAdminNotification("အမှားတစ်ခု ဖြစ်ပွားခဲ့သည်", "error")
    })
}

function initializeAdmin() {
  setupSidebar()
  setupModals()
  setupTables()
  setupForms()
}

function setupSidebar() {
  const sidebarToggle = document.querySelector(".sidebar-toggle")
  const sidebar = document.querySelector(".admin-sidebar")

  if (sidebarToggle && sidebar) {
    sidebarToggle.addEventListener("click", () => {
      sidebar.classList.toggle("active")
    })
  }

  // Close sidebar when clicking outside on mobile
  document.addEventListener("click", (e) => {
    if (window.innerWidth <= 768) {
      if (!sidebar.contains(e.target) && !sidebarToggle.contains(e.target)) {
        sidebar.classList.remove("active")
      }
    }
  })
}

function setupModals() {
  // Close modal when clicking outside
  window.addEventListener("click", (e) => {
    if (e.target.classList.contains("modal")) {
      e.target.style.display = "none"
    }
  })

  // Close modal with close button
  document.querySelectorAll(".close").forEach((closeBtn) => {
    closeBtn.addEventListener("click", function () {
      this.closest(".modal").style.display = "none"
    })
  })
}

function setupTables() {
  // Add sorting functionality to tables
  document.querySelectorAll(".admin-table th").forEach((header) => {
    if (header.dataset.sortable !== "false") {
      header.style.cursor = "pointer"
      header.addEventListener("click", function () {
        sortTable(this)
      })
    }
  })
}

function sortTable(header) {
  const table = header.closest("table")
  const tbody = table.querySelector("tbody")
  const rows = Array.from(tbody.querySelectorAll("tr"))
  const columnIndex = Array.from(header.parentNode.children).indexOf(header)
  const isAscending = header.classList.contains("sort-asc")

  // Remove existing sort classes
  header.parentNode.querySelectorAll("th").forEach((th) => {
    th.classList.remove("sort-asc", "sort-desc")
  })

  // Add new sort class
  header.classList.add(isAscending ? "sort-desc" : "sort-asc")

  // Sort rows
  rows.sort((a, b) => {
    const aValue = a.children[columnIndex].textContent.trim()
    const bValue = b.children[columnIndex].textContent.trim()

    // Try to parse as numbers
    const aNum = Number.parseFloat(aValue.replace(/[^\d.-]/g, ""))
    const bNum = Number.parseFloat(bValue.replace(/[^\d.-]/g, ""))

    if (!isNaN(aNum) && !isNaN(bNum)) {
      return isAscending ? bNum - aNum : aNum - bNum
    } else {
      return isAscending ? bValue.localeCompare(aValue) : aValue.localeCompare(bValue)
    }
  })

  // Reorder rows in DOM
  rows.forEach((row) => tbody.appendChild(row))
}

function setupForms() {
  // Add form validation
  document.querySelectorAll("form").forEach((form) => {
    form.addEventListener("submit", function (e) {
      if (!validateForm(this)) {
        e.preventDefault()
      }
    })
  })
}

function validateForm(form) {
  let isValid = true

  // Check required fields
  form.querySelectorAll("[required]").forEach((field) => {
    if (!field.value.trim()) {
      showFieldError(field, "This field is required")
      isValid = false
    } else {
      clearFieldError(field)
    }
  })

  // Check email fields
  form.querySelectorAll('input[type="email"]').forEach((field) => {
    if (field.value && !isValidEmail(field.value)) {
      showFieldError(field, "Please enter a valid email address")
      isValid = false
    }
  })

  return isValid
}

function showFieldError(field, message) {
  clearFieldError(field)

  const errorDiv = document.createElement("div")
  errorDiv.className = "field-error"
  errorDiv.textContent = message
  errorDiv.style.color = "#e74c3c"
  errorDiv.style.fontSize = "0.8em"
  errorDiv.style.marginTop = "5px"

  field.parentNode.appendChild(errorDiv)
  field.style.borderColor = "#e74c3c"
}

function clearFieldError(field) {
  const existingError = field.parentNode.querySelector(".field-error")
  if (existingError) {
    existingError.remove()
  }
  field.style.borderColor = ""
}

function isValidEmail(email) {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
  return emailRegex.test(email)
}

function showNotification(message, type = "info") {
  const notification = document.createElement("div")
  notification.className = `notification ${type}`
  notification.innerHTML = `
      <i class="fas fa-${getNotificationIcon(type)}"></i>
      <span>${message}</span>
      <button class="notification-close">&times;</button>
  `

  // Add styles
  notification.style.cssText = `
      position: fixed;
      top: 20px;
      right: 20px;
      padding: 15px 20px;
      border-radius: 8px;
      color: white;
      font-weight: 500;
      z-index: 10000;
      display: flex;
      align-items: center;
      gap: 10px;
      max-width: 400px;
      transform: translateX(400px);
      transition: transform 0.3s ease;
  `

  // Set background color based on type
  const colors = {
    success: "#27ae60",
    error: "#e74c3c",
    warning: "#f39c12",
    info: "#3498db",
  }
  notification.style.backgroundColor = colors[type] || colors.info

  document.body.appendChild(notification)

  // Show notification
  setTimeout(() => {
    notification.style.transform = "translateX(0)"
  }, 100)

  // Auto hide after 5 seconds
  const autoHide = setTimeout(() => {
    hideNotification(notification)
  }, 5000)

  // Close button functionality
  notification.querySelector(".notification-close").addEventListener("click", () => {
    clearTimeout(autoHide)
    hideNotification(notification)
  })
}

function hideNotification(notification) {
  notification.style.transform = "translateX(400px)"
  setTimeout(() => {
    if (notification.parentNode) {
      notification.parentNode.removeChild(notification)
    }
  }, 300)
}

function getNotificationIcon(type) {
  const icons = {
    success: "check-circle",
    error: "exclamation-circle",
    warning: "exclamation-triangle",
    info: "info-circle",
  }
  return icons[type] || icons.info
}

// Utility functions for admin operations
function deleteItem(id, type, callback) {
  if (!confirm(`Are you sure you want to delete this ${type}?`)) {
    return
  }

  fetch(`api/delete_${type}.php`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ id: id }),
  })
    .then((response) => response.json())
    .then((data) => {
      if (data.success) {
        showNotification(`${type} deleted successfully`, "success")
        if (callback) callback()
      } else {
        showNotification(data.message || `Failed to delete ${type}`, "error")
      }
    })
    .catch((error) => {
      console.error("Error:", error)
      showNotification("An error occurred", "error")
    })
}

function updateStatus(id, type, status, callback) {
  fetch(`api/update_${type}_status.php`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ id: id, status: status }),
  })
    .then((response) => response.json())
    .then((data) => {
      if (data.success) {
        showNotification(`${type} status updated`, "success")
        if (callback) callback()
      } else {
        showNotification(data.message || "Failed to update status", "error")
      }
    })
    .catch((error) => {
      console.error("Error:", error)
      showNotification("An error occurred", "error")
    })
}

function bulkAction(ids, action, type, callback) {
  if (ids.length === 0) {
    showNotification("Please select items first", "warning")
    return
  }

  if (!confirm(`Are you sure you want to ${action} ${ids.length} ${type}(s)?`)) {
    return
  }

  fetch(`api/bulk_${action}.php`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ ids: ids, type: type }),
  })
    .then((response) => response.json())
    .then((data) => {
      if (data.success) {
        showNotification(`${action} completed successfully`, "success")
        if (callback) callback()
      } else {
        showNotification(data.message || `Failed to ${action}`, "error")
      }
    })
    .catch((error) => {
      console.error("Error:", error)
      showNotification("An error occurred", "error")
    })
}

// Export functions for global use
window.adminUtils = {
  showNotification,
  deleteItem,
  updateStatus,
  bulkAction,
  validateForm,
}
