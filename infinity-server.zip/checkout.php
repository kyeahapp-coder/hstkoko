<?php
session_start();
require_once 'config/database.php';
require_once 'includes/functions.php';
require_once 'includes/security.php';

requireLogin();

$user_id = $_SESSION['user_id'];

// Get cart items
$stmt = $conn->prepare("
    SELECT c.id as cart_id, c.quantity, i.id, i.title, i.price, i.filename 
    FROM cart c 
    JOIN images i ON c.image_id = i.id 
    WHERE c.user_id = ? AND i.status = 'approved'
    ORDER BY c.added_at DESC
");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$cart_items = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

if (empty($cart_items)) {
    header('Location: cart.php');
    exit();
}

// Calculate totals
$subtotal = 0;
foreach ($cart_items as $item) {
    $subtotal += $item['price'] * $item['quantity'];
}

$tax_rate = 0.05; // 5% tax
$tax = $subtotal * $tax_rate;
$total = $subtotal + $tax;

// Get user info
$stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Checkout - Infinity Gallery</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/checkout.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
    <?php include 'includes/header.php'; ?>

    <div class="checkout-container">
        <div class="checkout-content">
            <h1><i class="fas fa-credit-card"></i> Checkout</h1>
            
            <div class="checkout-grid">
                <!-- Order Summary -->
                <div class="order-summary">
                    <h2>Order Summary</h2>
                    <div class="order-items">
                        <?php foreach ($cart_items as $item): ?>
                        <div class="order-item">
                            <img src="uploads/<?php echo sanitizeOutput($item['filename']); ?>" 
                                 alt="<?php echo sanitizeOutput($item['title']); ?>">
                            <div class="item-details">
                                <h3><?php echo sanitizeOutput($item['title']); ?></h3>
                                <p>Quantity: <?php echo $item['quantity']; ?></p>
                                <p class="price">$<?php echo number_format($item['price'] * $item['quantity'], 2); ?></p>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                    
                    <div class="order-totals">
                        <div class="total-row">
                            <span>Subtotal:</span>
                            <span>$<?php echo number_format($subtotal, 2); ?></span>
                        </div>
                        <div class="total-row">
                            <span>Tax (5%):</span>
                            <span>$<?php echo number_format($tax, 2); ?></span>
                        </div>
                        <div class="total-row final-total">
                            <span>Total:</span>
                            <span>$<?php echo number_format($total, 2); ?></span>
                        </div>
                    </div>
                </div>

                <!-- Checkout Form -->
                <div class="checkout-form">
                    <form id="checkoutForm" method="POST" action="api/create_order.php">
                        <input type="hidden" name="csrf_token" value="<?php echo generateCSRFToken(); ?>">
                        
                        <!-- Billing Information -->
                        <div class="form-section">
                            <h2>Billing Information</h2>
                            <div class="form-grid">
                                <div class="form-group">
                                    <label for="first_name">First Name *</label>
                                    <input type="text" id="first_name" name="first_name" 
                                           value="<?php echo sanitizeOutput($user['first_name'] ?? ''); ?>" required>
                                </div>
                                <div class="form-group">
                                    <label for="last_name">Last Name *</label>
                                    <input type="text" id="last_name" name="last_name" 
                                           value="<?php echo sanitizeOutput($user['last_name'] ?? ''); ?>" required>
                                </div>
                                <div class="form-group full-width">
                                    <label for="email">Email *</label>
                                    <input type="email" id="email" name="email" 
                                           value="<?php echo sanitizeOutput($user['email']); ?>" required>
                                </div>
                                <div class="form-group full-width">
                                    <label for="phone">Phone Number</label>
                                    <input type="tel" id="phone" name="phone" 
                                           value="<?php echo sanitizeOutput($user['phone'] ?? ''); ?>">
                                </div>
                                <div class="form-group full-width">
                                    <label for="address">Address *</label>
                                    <textarea id="address" name="address" rows="3" required><?php echo sanitizeOutput($user['address'] ?? ''); ?></textarea>
                                </div>
                                <div class="form-group">
                                    <label for="city">City *</label>
                                    <input type="text" id="city" name="city" 
                                           value="<?php echo sanitizeOutput($user['city'] ?? ''); ?>" required>
                                </div>
                                <div class="form-group">
                                    <label for="country">Country *</label>
                                    <select id="country" name="country" required>
                                        <option value="">Select Country</option>
                                        <option value="MM" <?php echo ($user['country'] ?? '') === 'MM' ? 'selected' : ''; ?>>Myanmar</option>
                                        <option value="TH" <?php echo ($user['country'] ?? '') === 'TH' ? 'selected' : ''; ?>>Thailand</option>
                                        <option value="US" <?php echo ($user['country'] ?? '') === 'US' ? 'selected' : ''; ?>>United States</option>
                                        <option value="GB" <?php echo ($user['country'] ?? '') === 'GB' ? 'selected' : ''; ?>>United Kingdom</option>
                                    </select>
                                </div>
                            </div>
                        </div>

                        <!-- Payment Method -->
                        <div class="form-section">
                            <h2>Payment Method</h2>
                            <div class="payment-methods">
                                <div class="payment-option">
                                    <input type="radio" id="wave_pay" name="payment_method" value="wave_pay" required>
                                    <label for="wave_pay">
                                        <i class="fas fa-mobile-alt"></i>
                                        Wave Pay
                                    </label>
                                </div>
                                <div class="payment-option">
                                    <input type="radio" id="kbz_pay" name="payment_method" value="kbz_pay" required>
                                    <label for="kbz_pay">
                                        <i class="fas fa-credit-card"></i>
                                        KBZ Pay
                                    </label>
                                </div>
                                <div class="payment-option">
                                    <input type="radio" id="bank_transfer" name="payment_method" value="bank_transfer" required>
                                    <label for="bank_transfer">
                                        <i class="fas fa-university"></i>
                                        Bank Transfer
                                    </label>
                                </div>
                            </div>
                        </div>

                        <!-- Order Notes -->
                        <div class="form-section">
                            <h2>Order Notes (Optional)</h2>
                            <div class="form-group">
                                <textarea id="notes" name="notes" rows="4" 
                                          placeholder="Any special instructions for your order..."></textarea>
                            </div>
                        </div>

                        <!-- Terms and Conditions -->
                        <div class="form-section">
                            <div class="checkbox-group">
                                <input type="checkbox" id="terms" name="terms" required>
                                <label for="terms">
                                    I agree to the <a href="#" target="_blank">Terms and Conditions</a> 
                                    and <a href="#" target="_blank">Privacy Policy</a> *
                                </label>
                            </div>
                        </div>

                        <!-- Submit Button -->
                        <div class="form-section">
                            <button type="submit" class="checkout-btn">
                                <i class="fas fa-lock"></i>
                                Place Order - $<?php echo number_format($total, 2); ?>
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <?php include 'includes/footer.php'; ?>

    <script src="assets/js/checkout.js"></script>
</body>
</html>
