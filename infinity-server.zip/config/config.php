<?php
// Application Configuration
define('APP_NAME', 'Infinity Gallery');
define('APP_VERSION', '1.0.0');
define('APP_URL', 'http://localhost');

// File Upload Settings
define('MAX_FILE_SIZE', 10 * 1024 * 1024); // 10MB
define('ALLOWED_EXTENSIONS', ['jpg', 'jpeg', 'png', 'gif', 'webp']);
define('UPLOAD_PATH', 'uploads/');
define('THUMB_PATH', 'uploads/thumbs/');

// Pagination Settings
define('ITEMS_PER_PAGE', 12);
define('ADMIN_ITEMS_PER_PAGE', 20);

// Email Settings
define('SMTP_HOST', 'smtp.gmail.com');
define('SMTP_PORT', 587);
define('SMTP_USERNAME', 'your-email@gmail.com');
define('SMTP_PASSWORD', 'your-app-password');
define('FROM_EMAIL', 'noreply@infinitygallery.com');
define('FROM_NAME', 'Infinity Gallery');

// Payment Settings
define('PAYMENT_METHODS', ['bank_transfer', 'mobile_payment', 'cash_on_delivery']);
define('DEFAULT_CURRENCY', 'MMK');

// Security Settings
define('SESSION_TIMEOUT', 3600); // 1 hour
define('MAX_LOGIN_ATTEMPTS', 5);
define('LOCKOUT_TIME', 900); // 15 minutes

// Cache Settings
define('CACHE_ENABLED', true);
define('CACHE_DURATION', 3600); // 1 hour

// Backup Settings
define('BACKUP_PATH', 'backups/');
define('AUTO_BACKUP', true);
define('BACKUP_RETENTION_DAYS', 30);
?>
