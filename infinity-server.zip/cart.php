<?php
require_once 'includes/functions.php';

if (!isLoggedIn()) {
    redirect('login.php');
}

$database = new Database();
$db = $database->getConnection();

// Get cart items
$cart_items = getCartItems();
$cart_count = getCartCount();

// Calculate totals
$subtotal_mmk = 0;
$subtotal_thb = 0;

foreach ($cart_items as $item) {
    $subtotal_mmk += $item['price_mmk'] * $item['quantity'];
    $subtotal_thb += $item['price_thb'] * $item['quantity'];
}

$discount_percent = calculateDiscount($cart_count);
$discount_mmk = $subtotal_mmk * ($discount_percent / 100);
$discount_thb = $subtotal_thb * ($discount_percent / 100);

$total_mmk = $subtotal_mmk - $discount_mmk;
$total_thb = $subtotal_thb - $discount_thb;
?>

<!DOCTYPE html>
<html lang="my">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shopping Cart - Infinity Server</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/cart.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body>
    <div class="container">
        <div class="cart-container">
            <div class="cart-header">
                <h1><i class="fas fa-shopping-cart"></i> Shopping Cart</h1>
                <a href="index.php" class="continue-shopping">
                    <i class="fas fa-arrow-left"></i> Continue Shopping
                </a>
            </div>

            <?php if (empty($cart_items)): ?>
                <div class="empty-cart">
                    <i class="fas fa-shopping-cart"></i>
                    <h2>Your cart is empty</h2>
                    <p>Add some images to your cart to get started!</p>
                    <a href="index.php" class="btn-primary">Browse Images</a>
                </div>
            <?php else: ?>
                <div class="cart-content">
                    <div class="cart-items">
                        <?php foreach ($cart_items as $item): ?>
                            <div class="cart-item" data-image-id="<?php echo $item['image_id']; ?>">
                                <div class="item-image">
                                    <img src="<?php echo $item['thumbnail_path'] ?: $item['file_path']; ?>" 
                                         alt="<?php echo htmlspecialchars($item['title']); ?>">
                                </div>
                                
                                <div class="item-details">
                                    <h3><?php echo htmlspecialchars($item['title']); ?></h3>
                                    <p class="item-category"><?php echo htmlspecialchars($item['category']); ?></p>
                                    <div class="item-pricing">
                                        <span class="price-mmk"><?php echo formatCurrency($item['price_mmk']); ?></span>
                                        <span class="price-thb"><?php echo formatCurrency($item['price_thb'], 'THB'); ?></span>
                                    </div>
                                </div>
                                
                                <div class="item-quantity">
                                    <label>Quantity:</label>
                                    <div class="quantity-controls">
                                        <button class="qty-btn" onclick="updateQuantity(<?php echo $item['image_id']; ?>, -1)">-</button>
                                        <input type="number" value="<?php echo $item['quantity']; ?>" min="1" 
                                               onchange="setQuantity(<?php echo $item['image_id']; ?>, this.value)">
                                        <button class="qty-btn" onclick="updateQuantity(<?php echo $item['image_id']; ?>, 1)">+</button>
                                    </div>
                                </div>
                                
                                <div class="item-total">
                                    <div class="total-mmk"><?php echo formatCurrency($item['price_mmk'] * $item['quantity']); ?></div>
                                    <div class="total-thb"><?php echo formatCurrency($item['price_thb'] * $item['quantity'], 'THB'); ?></div>
                                </div>
                                
                                <div class="item-actions">
                                    <button class="remove-btn" onclick="removeFromCart(<?php echo $item['image_id']; ?>)">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                    
                    <div class="cart-summary">
                        <h2>Order Summary</h2>
                        
                        <div class="currency-toggle">
                            <button class="currency-btn active" data-currency="MMK">MMK</button>
                            <button class="currency-btn" data-currency="THB">THB</button>
                        </div>
                        
                        <div class="summary-details">
                            <div class="summary-row">
                                <span>Subtotal:</span>
                                <span class="subtotal-mmk"><?php echo formatCurrency($subtotal_mmk); ?></span>
                                <span class="subtotal-thb" style="display: none;"><?php echo formatCurrency($subtotal_thb, 'THB'); ?></span>
                            </div>
                            
                            <?php if ($discount_percent > 0): ?>
                                <div class="summary-row discount">
                                    <span>Discount (<?php echo $discount_percent; ?>%):</span>
                                    <span class="discount-mmk">-<?php echo formatCurrency($discount_mmk); ?></span>
                                    <span class="discount-thb" style="display: none;">-<?php echo formatCurrency($discount_thb, 'THB'); ?></span>
                                </div>
                            <?php endif; ?>
                            
                            <div class="summary-row total">
                                <span>Total:</span>
                                <span class="total-mmk"><?php echo formatCurrency($total_mmk); ?></span>
                                <span class="total-thb" style="display: none;"><?php echo formatCurrency($total_thb, 'THB'); ?></span>
                            </div>
                        </div>
                        
                        <div class="checkout-actions">
                            <a href="checkout.php" class="btn-primary checkout-btn">
                                <i class="fas fa-credit-card"></i>
                                Proceed to Checkout
                            </a>
                            <button class="btn-secondary" onclick="clearCart()">
                                <i class="fas fa-trash"></i>
                                Clear Cart
                            </button>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <script src="assets/js/main.js"></script>
    <script src="assets/js/cart.js"></script>
</body>
</html>
