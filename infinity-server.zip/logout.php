<?php
session_start();
require_once 'includes/security.php';

// Log the logout event
if (isset($_SESSION['user_id'])) {
    logSecurityEvent('user_logout', 'User ID: ' . $_SESSION['user_id']);
}

// Destroy all session data
$_SESSION = array();

// Delete the session cookie
if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000,
        $params["path"], $params["domain"],
        $params["secure"], $params["httponly"]
    );
}

// Destroy the session
session_destroy();

// Redirect to home page
header('Location: index.php?logged_out=1');
exit();
?>
