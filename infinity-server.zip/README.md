# Infinity Gallery - Myanmar E-commerce Platform

A complete PHP-based image gallery and digital marketplace system with multi-language support (Myanmar/English).

## Features

### User Features
- **Image Gallery**: Browse and search high-quality stock photos
- **User Registration/Login**: Secure authentication system
- **Shopping Cart**: Add images to cart and purchase
- **Digital Services**: Purchase design and development services
- **Download System**: Secure file downloads for purchased items
- **User Profile**: Manage account, view orders, and download history
- **Wishlist**: Save favorite images for later
- **Reviews & Ratings**: Rate and review purchased images
- **Coupon System**: Apply discount coupons during checkout
- **Multi-language**: Myanmar and English language support

### Admin Features
- **Dashboard**: Overview of sales, users, and system stats
- **Image Management**: Approve/reject uploaded images
- **User Management**: Manage user accounts and permissions
- **Order Management**: Process and track orders
- **Service Management**: Manage digital services offered
- **Coupon Management**: Create and manage discount coupons
- **Settings**: Configure site settings and preferences
- **Backup System**: Database backup and restore functionality

### Technical Features
- **Responsive Design**: Mobile-friendly interface
- **Security**: CSRF protection, input sanitization, rate limiting
- **Image Processing**: Automatic thumbnail generation and optimization
- **Payment Integration**: Support for multiple payment methods
- **Notification System**: Real-time notifications for users and admins
- **SEO Friendly**: Clean URLs and meta tags
- **Caching**: Optimized performance with caching
- **Logging**: Comprehensive activity and error logging

## Installation

### Requirements
- PHP 7.4 or higher
- MySQL 5.7 or higher
- Apache/Nginx web server
- GD extension for image processing
- cURL extension for API calls
- PDO MySQL extension

### Setup Steps

1. **Upload Files**
   \`\`\`bash
   # Upload all files to your web server
   # Ensure proper file permissions (755 for directories, 644 for files)
   \`\`\`

2. **Create Database**
   \`\`\`sql
   CREATE DATABASE infinity_gallery;
   \`\`\`

3. **Import Database**
   \`\`\`bash
   # Import the main database structure
   mysql -u username -p infinity_gallery < scripts/database_setup.sql
   
   # Import additional tables
   mysql -u username -p infinity_gallery < scripts/additional_tables.sql
   
   # Import service orders table
   mysql -u username -p infinity_gallery < scripts/add_service_orders_table.sql
   
   # Import password reset table
   mysql -u username -p infinity_gallery < scripts/password_reset_table.sql
   \`\`\`

4. **Configure Database Connection**
   \`\`\`php
   // Edit config/database.php
   $host = 'localhost';
   $dbname = 'infinity_gallery';
   $username = 'your_db_username';
   $password = 'your_db_password';
   \`\`\`

5. **Set File Permissions**
   \`\`\`bash
   chmod 755 uploads/
   chmod 755 uploads/thumbs/
   chmod 755 logs/
   chmod 755 backups/
   chmod 644 config/database.php
   \`\`\`

6. **Configure Settings**
   - Update `config/config.php` with your site details
   - Configure email settings for notifications
   - Set up payment gateway credentials (if using)

## Default Admin Account

- **Username**: admin
- **Password**: admin123
- **Email**: admin@infinitygallery.com

**Important**: Change the default admin password immediately after installation!

## File Structure

\`\`\`
infinity-server/
├── admin/                  # Admin panel files
├── api/                    # API endpoints
├── assets/                 # CSS, JS, and static files
├── config/                 # Configuration files
├── includes/               # PHP includes and functions
├── scripts/                # Database scripts
├── uploads/                # Uploaded images
├── logs/                   # Application logs
├── backups/                # Database backups
├── index.php               # Homepage
├── login.php               # User login
├── register.php            # User registration
├── cart.php                # Shopping cart
├── services.php            # Digital services
├── profile.php             # User profile
├── orders.php              # Order history
└── .htaccess               # Apache configuration
\`\`\`

## Configuration

### Email Settings
Update email configuration in `config/config.php`:
\`\`\`php
define('SMTP_HOST', 'your-smtp-host');
define('SMTP_USERNAME', 'your-email@domain.com');
define('SMTP_PASSWORD', 'your-email-password');
\`\`\`

### Payment Settings
Configure payment methods in `config/config.php`:
\`\`\`php
define('PAYMENT_METHODS', ['bank_transfer', 'mobile_payment', 'cash_on_delivery']);
\`\`\`

### Site Settings
Customize site settings through the admin panel or directly in the database:
- Site name and description
- Contact information
- Commission rates
- Upload limits
- Maintenance mode

## Security Features

- **CSRF Protection**: All forms include CSRF tokens
- **Input Sanitization**: All user inputs are sanitized
- **Rate Limiting**: Prevents abuse of API endpoints
- **File Upload Validation**: Strict file type and size validation
- **SQL Injection Prevention**: Prepared statements used throughout
- **XSS Protection**: Output escaping and content security headers
- **Session Security**: Secure session handling

## Performance Optimization

- **Image Optimization**: Automatic image compression and thumbnail generation
- **Caching**: File-based caching for frequently accessed data
- **Database Indexing**: Optimized database queries with proper indexes
- **Static File Caching**: Browser caching for CSS, JS, and images
- **GZIP Compression**: Compressed content delivery

## Backup and Maintenance

### Database Backup
\`\`\`php
// Automatic backups can be enabled in admin settings
// Manual backup through admin panel: Admin > Backup
\`\`\`

### Log Files
- Application logs: `logs/app.log`
- Error logs: Check server error logs
- Activity logs: Stored in database notifications table

### Maintenance Mode
Enable maintenance mode through admin panel or by setting:
\`\`\`php
// In site_settings table
UPDATE site_settings SET setting_value = '1' WHERE setting_key = 'maintenance_mode';
\`\`\`

## Troubleshooting

### Common Issues

1. **Images not uploading**
   - Check file permissions on uploads/ directory
   - Verify PHP upload limits in php.ini
   - Ensure GD extension is installed

2. **Database connection errors**
   - Verify database credentials in config/database.php
   - Check if MySQL service is running
   - Ensure database exists and is accessible

3. **Email not sending**
   - Verify SMTP settings in config/config.php
   - Check if cURL extension is enabled
   - Test email credentials

4. **Permission denied errors**
   - Set proper file permissions (755 for directories, 644 for files)
   - Ensure web server has write access to uploads/ and logs/

### Support

For technical support or questions:
- Check the logs in `logs/app.log`
- Review database error logs
- Verify server requirements are met

## License

This project is proprietary software. All rights reserved.

## Version History

- **v1.0.0** - Initial release with core functionality
- **v1.1.0** - Added coupon system and reviews
- **v1.2.0** - Enhanced security and performance optimizations
