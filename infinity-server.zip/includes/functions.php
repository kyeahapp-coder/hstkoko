<?php
session_start();
require_once 'config/database.php';
require_once 'includes/security.php';

function isLoggedIn() {
    return isset($_SESSION['user_id']) && !empty($_SESSION['user_id']);
}

function isAdmin() {
    return isset($_SESSION['admin_id']) && !empty($_SESSION['admin_id']);
}

function getCurrentUser() {
    if (!isLoggedIn()) {
        return null;
    }
    
    $database = new Database();
    $db = $database->getConnection();
    
    $query = "SELECT * FROM users WHERE id = ? AND is_active = 1";
    $stmt = $db->prepare($query);
    $stmt->execute([$_SESSION['user_id']]);
    
    return $stmt->fetch(PDO::FETCH_ASSOC);
}

function getCurrentAdmin() {
    if (!isAdmin()) {
        return null;
    }
    
    $database = new Database();
    $db = $database->getConnection();
    
    $query = "SELECT * FROM admin_users WHERE id = ? AND is_active = 1";
    $stmt = $db->prepare($query);
    $stmt->execute([$_SESSION['admin_id']]);
    
    return $stmt->fetch(PDO::FETCH_ASSOC);
}

function redirect($url) {
    header("Location: $url");
    exit();
}

function generateOrderId() {
    return 'ORD' . date('Ymd') . strtoupper(substr(uniqid(), -6));
}

function getCartCount() {
    if (!isLoggedIn()) {
        return 0;
    }
    
    $database = new Database();
    $db = $database->getConnection();
    
    $query = "SELECT SUM(quantity) as total FROM cart WHERE user_id = ?";
    $stmt = $db->prepare($query);
    $stmt->execute([$_SESSION['user_id']]);
    
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    return $result['total'] ?? 0;
}

function getCartItems() {
    if (!isLoggedIn()) {
        return [];
    }
    
    $database = new Database();
    $db = $database->getConnection();
    
    $query = "SELECT c.*, i.title, i.filename, i.price_mmk, i.price_thb, i.thumbnail_path 
              FROM cart c 
              JOIN images i ON c.image_id = i.id 
              WHERE c.user_id = ? AND i.status = 'approved'
              ORDER BY c.added_at DESC";
    $stmt = $db->prepare($query);
    $stmt->execute([$_SESSION['user_id']]);
    
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

function addToCart($image_id, $quantity = 1) {
    if (!isLoggedIn()) {
        return false;
    }
    
    $database = new Database();
    $db = $database->getConnection();
    
    $query = "SELECT id FROM images WHERE id = ? AND status = 'approved'";
    $stmt = $db->prepare($query);
    $stmt->execute([$image_id]);
    
    if (!$stmt->fetch()) {
        return false;
    }
    
    $query = "INSERT INTO cart (user_id, image_id, quantity) VALUES (?, ?, ?) 
              ON DUPLICATE KEY UPDATE quantity = quantity + VALUES(quantity)";
    $stmt = $db->prepare($query);
    return $stmt->execute([$_SESSION['user_id'], $image_id, $quantity]);
}

function removeFromCart($image_id) {
    if (!isLoggedIn()) {
        return false;
    }
    
    $database = new Database();
    $db = $database->getConnection();
    
    $query = "DELETE FROM cart WHERE user_id = ? AND image_id = ?";
    $stmt = $db->prepare($query);
    return $stmt->execute([$_SESSION['user_id'], $image_id]);
}

function clearCart() {
    if (!isLoggedIn()) {
        return false;
    }
    
    $database = new Database();
    $db = $database->getConnection();
    
    $query = "DELETE FROM cart WHERE user_id = ?";
    $stmt = $db->prepare($query);
    return $stmt->execute([$_SESSION['user_id']]);
}

function getNotificationCount() {
    if (!isLoggedIn()) {
        return 0;
    }
    
    $database = new Database();
    $db = $database->getConnection();
    
    $query = "SELECT COUNT(*) FROM notifications WHERE user_id = ? AND is_read = 0";
    $stmt = $db->prepare($query);
    $stmt->execute([$_SESSION['user_id']]);
    
    return $stmt->fetchColumn();
}

function addNotification($user_id, $title, $message, $type = 'info', $related_type = null, $related_id = null) {
    $database = new Database();
    $db = $database->getConnection();
    
    $query = "INSERT INTO notifications (user_id, title, message, type, related_type, related_id) 
              VALUES (?, ?, ?, ?, ?, ?)";
    $stmt = $db->prepare($query);
    return $stmt->execute([$user_id, $title, $message, $type, $related_type, $related_id]);
}

function addAdminNotification($admin_id, $title, $message, $type = 'info', $related_type = null, $related_id = null) {
    $database = new Database();
    $db = $database->getConnection();
    
    $query = "INSERT INTO notifications (admin_id, title, message, type, related_type, related_id) 
              VALUES (?, ?, ?, ?, ?, ?)";
    $stmt = $db->prepare($query);
    return $stmt->execute([$admin_id, $title, $message, $type, $related_type, $related_id]);
}

function formatCurrency($amount, $currency = 'MMK') {
    if ($currency === 'MMK') {
        return number_format($amount, 0) . ' ကျပ်';
    } else {
        return number_format($amount, 2) . ' ฿';
    }
}

function convertCurrency($amount, $from = 'MMK', $to = 'THB') {
    if ($from === $to) {
        return $amount;
    }
    
    $database = new Database();
    $db = $database->getConnection();
    
    $mmk_rate = getSetting('currency_mmk_rate', 1);
    $thb_rate = getSetting('currency_thb_rate', 0.025);
    
    if ($from === 'MMK' && $to === 'THB') {
        return $amount * $thb_rate;
    } elseif ($from === 'THB' && $to === 'MMK') {
        return $amount / $thb_rate;
    }
    
    return $amount;
}

function getSetting($key, $default = '') {
    static $settings = [];
    
    if (empty($settings)) {
        $database = new Database();
        $db = $database->getConnection();
        
        $query = "SELECT setting_key, setting_value FROM site_settings";
        $stmt = $db->prepare($query);
        $stmt->execute();
        
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $settings[$row['setting_key']] = $row['setting_value'];
        }
    }
    
    return isset($settings[$key]) ? $settings[$key] : $default;
}

function updateSetting($key, $value) {
    $database = new Database();
    $db = $database->getConnection();
    
    $query = "INSERT INTO site_settings (setting_key, setting_value) VALUES (?, ?) 
              ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)";
    $stmt = $db->prepare($query);
    return $stmt->execute([$key, $value]);
}

function calculateDiscount($quantity) {
    if ($quantity >= 10) return 15;
    if ($quantity >= 5) return 10;
    if ($quantity >= 2) return 5;
    return 0;
}

function formatFileSize($bytes) {
    $units = ['B', 'KB', 'MB', 'GB'];
    $bytes = max($bytes, 0);
    $pow = floor(($bytes ? log($bytes) : 0) / log(1024));
    $pow = min($pow, count($units) - 1);
    
    $bytes /= pow(1024, $pow);
    
    return round($bytes, 2) . ' ' . $units[$pow];
}

function timeAgo($datetime) {
    $time = time() - strtotime($datetime);
    
    if ($time < 60) return 'just now';
    if ($time < 3600) return floor($time/60) . ' minutes ago';
    if ($time < 86400) return floor($time/3600) . ' hours ago';
    if ($time < 2592000) return floor($time/86400) . ' days ago';
    if ($time < 31536000) return floor($time/2592000) . ' months ago';
    
    return floor($time/31536000) . ' years ago';
}

function paginate($total_items, $items_per_page, $current_page, $base_url) {
    $total_pages = ceil($total_items / $items_per_page);
    
    if ($total_pages <= 1) {
        return '';
    }
    
    $pagination = '<div class="pagination">';
    
    if ($current_page > 1) {
        $prev_page = $current_page - 1;
        $pagination .= '<a href="' . $base_url . '?page=' . $prev_page . '" class="page-btn prev">Previous</a>';
    }
    
    $start = max(1, $current_page - 2);
    $end = min($total_pages, $current_page + 2);
    
    if ($start > 1) {
        $pagination .= '<a href="' . $base_url . '?page=1" class="page-btn">1</a>';
        if ($start > 2) {
            $pagination .= '<span class="page-dots">...</span>';
        }
    }
    
    for ($i = $start; $i <= $end; $i++) {
        $active = ($i == $current_page) ? ' active' : '';
        $pagination .= '<a href="' . $base_url . '?page=' . $i . '" class="page-btn' . $active . '">' . $i . '</a>';
    }
    
    if ($end < $total_pages) {
        if ($end < $total_pages - 1) {
            $pagination .= '<span class="page-dots">...</span>';
        }
        $pagination .= '<a href="' . $base_url . '?page=' . $total_pages . '" class="page-btn">' . $total_pages . '</a>';
    }
    
    if ($current_page < $total_pages) {
        $next_page = $current_page + 1;
        $pagination .= '<a href="' . $base_url . '?page=' . $next_page . '" class="page-btn next">Next</a>';
    }
    
    $pagination .= '</div>';
    
    return $pagination;
}

function hasPurchasedImage($user_id, $image_id) {
    $database = new Database();
    $db = $database->getConnection();
    
    $query = "SELECT COUNT(*) FROM order_items oi 
              JOIN orders o ON oi.order_id = o.id 
              WHERE o.user_id = ? AND oi.image_id = ? AND o.order_status = 'completed'";
    $stmt = $db->prepare($query);
    $stmt->execute([$user_id, $image_id]);
    
    return $stmt->fetchColumn() > 0;
}

function logDownload($user_id, $image_id, $download_type = 'purchased') {
    $database = new Database();
    $db = $database->getConnection();
    
    $query = "INSERT INTO download_history (user_id, image_id, download_type, ip_address, user_agent) 
              VALUES (?, ?, ?, ?, ?)";
    $stmt = $db->prepare($query);
    return $stmt->execute([
        $user_id, 
        $image_id, 
        $download_type, 
        $_SERVER['REMOTE_ADDR'] ?? '', 
        $_SERVER['HTTP_USER_AGENT'] ?? ''
    ]);
}

function incrementImageViews($image_id) {
    $database = new Database();
    $db = $database->getConnection();
    
    $query = "UPDATE images SET views = views + 1 WHERE id = ?";
    $stmt = $db->prepare($query);
    return $stmt->execute([$image_id]);
}

function incrementImageDownloads($image_id) {
    $database = new Database();
    $db = $database->getConnection();
    
    $query = "UPDATE images SET downloads = downloads + 1 WHERE id = ?";
    $stmt = $db->prepare($query);
    return $stmt->execute([$image_id]);
}

function getPopularImages($limit = 10) {
    $database = new Database();
    $db = $database->getConnection();
    
    $query = "SELECT * FROM images 
              WHERE status = 'approved' 
              ORDER BY (views + downloads * 2) DESC 
              LIMIT ?";
    $stmt = $db->prepare($query);
    $stmt->execute([$limit]);
    
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

function getFeaturedImages($limit = 8) {
    $database = new Database();
    $db = $database->getConnection();
    
    $query = "SELECT * FROM images 
              WHERE status = 'approved' AND featured = 1 
              ORDER BY created_at DESC 
              LIMIT ?";
    $stmt = $db->prepare($query);
    $stmt->execute([$limit]);
    
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

function getRecentImages($limit = 12) {
    $database = new Database();
    $db = $database->getConnection();
    
    $query = "SELECT * FROM images 
              WHERE status = 'approved' 
              ORDER BY created_at DESC 
              LIMIT ?";
    $stmt = $db->prepare($query);
    $stmt->execute([$limit]);
    
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

function searchImages($query, $category = '', $min_price = 0, $max_price = 0, $page = 1, $per_page = 12) {
    $database = new Database();
    $db = $database->getConnection();
    
    $sql = "SELECT * FROM images WHERE status = 'approved'";
    $params = [];
    
    if (!empty($query)) {
        $sql .= " AND (title LIKE ? OR description LIKE ? OR tags LIKE ?)";
        $search_term = "%$query%";
        $params[] = $search_term;
        $params[] = $search_term;
        $params[] = $search_term;
    }
    
    if (!empty($category)) {
        $sql .= " AND category = ?";
        $params[] = $category;
    }
    
    if ($min_price > 0) {
        $sql .= " AND price_mmk >= ?";
        $params[] = $min_price;
    }
    
    if ($max_price > 0) {
        $sql .= " AND price_mmk <= ?";
        $params[] = $max_price;
    }
    
    $sql .= " ORDER BY created_at DESC";
    
    $offset = ($page - 1) * $per_page;
    $sql .= " LIMIT ? OFFSET ?";
    $params[] = $per_page;
    $params[] = $offset;
    
    $stmt = $db->prepare($sql);
    $stmt->execute($params);
    
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

function getImageCategories() {
    $database = new Database();
    $db = $database->getConnection();
    
    $query = "SELECT category, COUNT(*) as count 
              FROM images 
              WHERE status = 'approved' AND category IS NOT NULL AND category != '' 
              GROUP BY category 
              ORDER BY count DESC, category ASC";
    $stmt = $db->prepare($query);
    $stmt->execute();
    
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

function validateImageFile($file) {
    $allowed_types = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
    $max_size = getSetting('max_file_size', 10485760); // 10MB default
    
    if (!in_array($file['type'], $allowed_types)) {
        return 'Invalid file type. Only JPG, PNG, GIF, and WebP are allowed.';
    }
    
    if ($file['size'] > $max_size) {
        return 'File size too large. Maximum size is ' . formatFileSize($max_size) . '.';
    }
    
    $image_info = getimagesize($file['tmp_name']);
    if (!$image_info) {
        return 'Invalid image file.';
    }
    
    return true;
}

function generateThumbnail($source_path, $thumb_path, $max_width = 300, $max_height = 300) {
    $image_info = getimagesize($source_path);
    if (!$image_info) {
        return false;
    }
    
    $width = $image_info[0];
    $height = $image_info[1];
    $type = $image_info[2];
    
    $ratio = min($max_width / $width, $max_height / $height);
    $new_width = intval($width * $ratio);
    $new_height = intval($height * $ratio);
    
    switch ($type) {
        case IMAGETYPE_JPEG:
            $source = imagecreatefromjpeg($source_path);
            break;
        case IMAGETYPE_PNG:
            $source = imagecreatefrompng($source_path);
            break;
        case IMAGETYPE_GIF:
            $source = imagecreatefromgif($source_path);
            break;
        case IMAGETYPE_WEBP:
            $source = imagecreatefromwebp($source_path);
            break;
        default:
            return false;
    }
    
    if (!$source) {
        return false;
    }
    
    $thumb = imagecreatetruecolor($new_width, $new_height);
    
    if ($type == IMAGETYPE_PNG || $type == IMAGETYPE_GIF) {
        imagealphablending($thumb, false);
        imagesavealpha($thumb, true);
        $transparent = imagecolorallocatealpha($thumb, 255, 255, 255, 127);
        imagefilledrectangle($thumb, 0, 0, $new_width, $new_height, $transparent);
    }
    
    imagecopyresampled($thumb, $source, 0, 0, 0, 0, $new_width, $new_height, $width, $height);
    
    $result = false;
    switch ($type) {
        case IMAGETYPE_JPEG:
            $result = imagejpeg($thumb, $thumb_path, 85);
            break;
        case IMAGETYPE_PNG:
            $result = imagepng($thumb, $thumb_path);
            break;
        case IMAGETYPE_GIF:
            $result = imagegif($thumb, $thumb_path);
            break;
        case IMAGETYPE_WEBP:
            $result = imagewebp($thumb, $thumb_path, 85);
            break;
    }
    
    imagedestroy($source);
    imagedestroy($thumb);
    
    return $result;
}

function sendEmail($to, $subject, $message, $from_name = null) {
    $from_name = $from_name ?: getSetting('site_name', 'Infinity Server');
    $from_email = getSetting('contact_email', 'noreply@infinityserver.com');
    
    $headers = "MIME-Version: 1.0" . "\r\n";
    $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
    $headers .= "From: $from_name <$from_email>" . "\r\n";
    
    return mail($to, $subject, $message, $headers);
}

function logActivity($user_id, $action, $details = '', $ip_address = null) {
    $database = new Database();
    $db = $database->getConnection();
    
    $ip_address = $ip_address ?: ($_SERVER['REMOTE_ADDR'] ?? '');
    
    $query = "INSERT INTO activity_logs (user_id, action, details, ip_address) VALUES (?, ?, ?, ?)";
    $stmt = $db->prepare($query);
    return $stmt->execute([$user_id, $action, $details, $ip_address]);
}
?>
