<?php
class BackupManager {
    private $db;
    private $backupPath;
    
    public function __construct() {
        $database = new Database();
        $this->db = $database->getConnection();
        $this->backupPath = __DIR__ . '/../' . BACKUP_PATH;
        
        if (!is_dir($this->backupPath)) {
            mkdir($this->backupPath, 0755, true);
        }
    }
    
    public function createDatabaseBackup() {
        $filename = 'db_backup_' . date('Y-m-d_H-i-s') . '.sql';
        $filepath = $this->backupPath . $filename;
        
        try {
            // Get database name from connection
            $dbName = $this->db->query('SELECT DATABASE()')->fetchColumn();
            
            // Get all tables
            $tables = [];
            $result = $this->db->query('SHOW TABLES');
            while ($row = $result->fetch(PDO::FETCH_NUM)) {
                $tables[] = $row[0];
            }
            
            $sql = "-- Database Backup\n";
            $sql .= "-- Generated on: " . date('Y-m-d H:i:s') . "\n\n";
            $sql .= "SET FOREIGN_KEY_CHECKS = 0;\n\n";
            
            foreach ($tables as $table) {
                // Get table structure
                $result = $this->db->query("SHOW CREATE TABLE `$table`");
                $row = $result->fetch(PDO::FETCH_NUM);
                $sql .= "DROP TABLE IF EXISTS `$table`;\n";
                $sql .= $row[1] . ";\n\n";
                
                // Get table data
                $result = $this->db->query("SELECT * FROM `$table`");
                $rows = $result->fetchAll(PDO::FETCH_ASSOC);
                
                if (!empty($rows)) {
                    $columns = array_keys($rows[0]);
                    $sql .= "INSERT INTO `$table` (`" . implode('`, `', $columns) . "`) VALUES\n";
                    
                    $values = [];
                    foreach ($rows as $row) {
                        $rowValues = [];
                        foreach ($row as $value) {
                            if ($value === null) {
                                $rowValues[] = 'NULL';
                            } else {
                                $rowValues[] = "'" . addslashes($value) . "'";
                            }
                        }
                        $values[] = '(' . implode(', ', $rowValues) . ')';
                    }
                    
                    $sql .= implode(",\n", $values) . ";\n\n";
                }
            }
            
            $sql .= "SET FOREIGN_KEY_CHECKS = 1;\n";
            
            file_put_contents($filepath, $sql);
            
            return [
                'success' => true,
                'filename' => $filename,
                'filepath' => $filepath,
                'size' => filesize($filepath)
            ];
            
        } catch (Exception $e) {
            return [
                'success' => false,
                'error' => $e->getMessage()
            ];
        }
    }
    
    public function createFilesBackup() {
        $filename = 'files_backup_' . date('Y-m-d_H-i-s') . '.zip';
        $filepath = $this->backupPath . $filename;
        
        $zip = new ZipArchive();
        if ($zip->open($filepath, ZipArchive::CREATE) !== TRUE) {
            return ['success' => false, 'error' => 'Cannot create ZIP file'];
        }
        
        // Add uploads directory
        $this->addDirectoryToZip($zip, 'uploads/', 'uploads/');
        
        // Add assets directory
        $this->addDirectoryToZip($zip, 'assets/', 'assets/');
        
        $zip->close();
        
        return [
            'success' => true,
            'filename' => $filename,
            'filepath' => $filepath,
            'size' => filesize($filepath)
        ];
    }
    
    private function addDirectoryToZip($zip, $dir, $zipDir) {
        if (!is_dir($dir)) return;
        
        $files = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($dir),
            RecursiveIteratorIterator::LEAVES_ONLY
        );
        
        foreach ($files as $file) {
            if (!$file->isDir()) {
                $filePath = $file->getRealPath();
                $relativePath = $zipDir . substr($filePath, strlen(realpath($dir)) + 1);
                $zip->addFile($filePath, $relativePath);
            }
        }
    }
    
    public function getBackups() {
        $backups = [];
        $files = glob($this->backupPath . '*');
        
        foreach ($files as $file) {
            if (is_file($file)) {
                $backups[] = [
                    'filename' => basename($file),
                    'size' => filesize($file),
                    'created' => filemtime($file),
                    'type' => strpos($file, 'db_backup') !== false ? 'database' : 'files'
                ];
            }
        }
        
        // Sort by creation time (newest first)
        usort($backups, function($a, $b) {
            return $b['created'] - $a['created'];
        });
        
        return $backups;
    }
    
    public function deleteBackup($filename) {
        $filepath = $this->backupPath . $filename;
        if (file_exists($filepath) && is_file($filepath)) {
            return unlink($filepath);
        }
        return false;
    }
    
    public function cleanOldBackups($days = BACKUP_RETENTION_DAYS) {
        $cutoff = time() - ($days * 24 * 60 * 60);
        $deleted = 0;
        
        $files = glob($this->backupPath . '*');
        foreach ($files as $file) {
            if (is_file($file) && filemtime($file) < $cutoff) {
                if (unlink($file)) {
                    $deleted++;
                }
            }
        }
        
        return $deleted;
    }
    
    public function restoreDatabase($filename) {
        $filepath = $this->backupPath . $filename;
        
        if (!file_exists($filepath)) {
            return ['success' => false, 'error' => 'Backup file not found'];
        }
        
        try {
            $sql = file_get_contents($filepath);
            $statements = explode(';', $sql);
            
            $this->db->beginTransaction();
            
            foreach ($statements as $statement) {
                $statement = trim($statement);
                if (!empty($statement)) {
                    $this->db->exec($statement);
                }
            }
            
            $this->db->commit();
            
            return ['success' => true];
            
        } catch (Exception $e) {
            $this->db->rollBack();
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }
}
?>
