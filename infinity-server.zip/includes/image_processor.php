<?php
class ImageProcessor {
    public static function createThumbnail($source_path, $thumb_path, $max_width = 300, $max_height = 300) {
        $image_info = getimagesize($source_path);
        if (!$image_info) {
            return false;
        }
        
        $width = $image_info[0];
        $height = $image_info[1];
        $mime_type = $image_info['mime'];
        
        // Calculate new dimensions
        $ratio = min($max_width / $width, $max_height / $height);
        $new_width = intval($width * $ratio);
        $new_height = intval($height * $ratio);
        
        // Create source image
        switch ($mime_type) {
            case 'image/jpeg':
                $source = imagecreatefromjpeg($source_path);
                break;
            case 'image/png':
                $source = imagecreatefrompng($source_path);
                break;
            case 'image/gif':
                $source = imagecreatefromgif($source_path);
                break;
            case 'image/webp':
                $source = imagecreatefromwebp($source_path);
                break;
            default:
                return false;
        }
        
        if (!$source) {
            return false;
        }
        
        // Create thumbnail
        $thumb = imagecreatetruecolor($new_width, $new_height);
        
        // Preserve transparency for PNG and GIF
        if ($mime_type == 'image/png' || $mime_type == 'image/gif') {
            imagealphablending($thumb, false);
            imagesavealpha($thumb, true);
            $transparent = imagecolorallocatealpha($thumb, 255, 255, 255, 127);
            imagefilledrectangle($thumb, 0, 0, $new_width, $new_height, $transparent);
        }
        
        imagecopyresampled($thumb, $source, 0, 0, 0, 0, $new_width, $new_height, $width, $height);
        
        // Save thumbnail
        $result = false;
        switch ($mime_type) {
            case 'image/jpeg':
                $result = imagejpeg($thumb, $thumb_path, 85);
                break;
            case 'image/png':
                $result = imagepng($thumb, $thumb_path, 8);
                break;
            case 'image/gif':
                $result = imagegif($thumb, $thumb_path);
                break;
            case 'image/webp':
                $result = imagewebp($thumb, $thumb_path, 85);
                break;
        }
        
        imagedestroy($source);
        imagedestroy($thumb);
        
        return $result;
    }
    
    public static function watermarkImage($source_path, $watermark_path, $output_path, $position = 'bottom-right') {
        $source = imagecreatefromjpeg($source_path);
        $watermark = imagecreatefrompng($watermark_path);
        
        if (!$source || !$watermark) {
            return false;
        }
        
        $source_width = imagesx($source);
        $source_height = imagesy($source);
        $watermark_width = imagesx($watermark);
        $watermark_height = imagesy($watermark);
        
        // Calculate position
        switch ($position) {
            case 'top-left':
                $dest_x = 10;
                $dest_y = 10;
                break;
            case 'top-right':
                $dest_x = $source_width - $watermark_width - 10;
                $dest_y = 10;
                break;
            case 'bottom-left':
                $dest_x = 10;
                $dest_y = $source_height - $watermark_height - 10;
                break;
            case 'bottom-right':
            default:
                $dest_x = $source_width - $watermark_width - 10;
                $dest_y = $source_height - $watermark_height - 10;
                break;
            case 'center':
                $dest_x = ($source_width - $watermark_width) / 2;
                $dest_y = ($source_height - $watermark_height) / 2;
                break;
        }
        
        imagecopy($source, $watermark, $dest_x, $dest_y, 0, 0, $watermark_width, $watermark_height);
        
        $result = imagejpeg($source, $output_path, 90);
        
        imagedestroy($source);
        imagedestroy($watermark);
        
        return $result;
    }
    
    public static function optimizeImage($source_path, $output_path, $quality = 85) {
        $image_info = getimagesize($source_path);
        if (!$image_info) {
            return false;
        }
        
        $mime_type = $image_info['mime'];
        
        switch ($mime_type) {
            case 'image/jpeg':
                $image = imagecreatefromjpeg($source_path);
                $result = imagejpeg($image, $output_path, $quality);
                break;
            case 'image/png':
                $image = imagecreatefrompng($source_path);
                $result = imagepng($image, $output_path, 8);
                break;
            case 'image/webp':
                $image = imagecreatefromwebp($source_path);
                $result = imagewebp($image, $output_path, $quality);
                break;
            default:
                return false;
        }
        
        if (isset($image)) {
            imagedestroy($image);
        }
        
        return $result;
    }
}
?>
