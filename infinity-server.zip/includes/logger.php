<?php
class Logger {
    private static $log_file = 'logs/app.log';
    
    public static function log($level, $message, $context = []) {
        if (!file_exists(dirname(self::$log_file))) {
            mkdir(dirname(self::$log_file), 0755, true);
        }
        
        $timestamp = date('Y-m-d H:i:s');
        $context_str = !empty($context) ? json_encode($context) : '';
        $log_entry = "[{$timestamp}] {$level}: {$message} {$context_str}" . PHP_EOL;
        
        file_put_contents(self::$log_file, $log_entry, FILE_APPEND | LOCK_EX);
    }
    
    public static function info($message, $context = []) {
        self::log('INFO', $message, $context);
    }
    
    public static function warning($message, $context = []) {
        self::log('WARNING', $message, $context);
    }
    
    public static function error($message, $context = []) {
        self::log('ERROR', $message, $context);
    }
    
    public static function debug($message, $context = []) {
        self::log('DEBUG', $message, $context);
    }
    
    public static function activity($user_id, $action, $details = []) {
        $message = "User {$user_id} performed action: {$action}";
        self::log('ACTIVITY', $message, $details);
    }
}
?>
