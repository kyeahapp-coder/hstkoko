<?php
session_start();
require_once 'config/database.php';
require_once 'includes/functions.php';
require_once 'includes/security.php';

requireLogin();

$user_id = $_SESSION['user_id'];

// Get filter parameters
$status_filter = isset($_GET['status']) ? sanitizeInput($_GET['status']) : 'all';
$page = isset($_GET['page']) ? max(1, (int)$_GET['page']) : 1;
$per_page = 10;
$offset = ($page - 1) * $per_page;

// Build query based on filters
$where_clause = "WHERE o.user_id = ?";
$params = [$user_id];
$param_types = "i";

if ($status_filter !== 'all') {
    $where_clause .= " AND o.status = ?";
    $params[] = $status_filter;
    $param_types .= "s";
}

// Get total count for pagination
$count_query = "SELECT COUNT(*) as total FROM orders o $where_clause";
$count_stmt = $conn->prepare($count_query);
$count_stmt->bind_param($param_types, ...$params);
$count_stmt->execute();
$total_orders = $count_stmt->get_result()->fetch_assoc()['total'];
$total_pages = ceil($total_orders / $per_page);

// Get orders
$orders_query = "
    SELECT o.*, 
           COUNT(oi.id) as item_count,
           SUM(oi.price * oi.quantity) as total_amount
    FROM orders o 
    LEFT JOIN order_items oi ON o.id = oi.order_id 
    $where_clause 
    GROUP BY o.id 
    ORDER BY o.created_at DESC 
    LIMIT ? OFFSET ?
";

$params[] = $per_page;
$params[] = $offset;
$param_types .= "ii";

$orders_stmt = $conn->prepare($orders_query);
$orders_stmt->bind_param($param_types, ...$params);
$orders_stmt->execute();
$orders = $orders_stmt->get_result()->fetch_all(MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Orders - Infinity Gallery</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/orders.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
    <?php include 'includes/header.php'; ?>

    <div class="orders-container">
        <div class="orders-content">
            <div class="orders-header">
                <h1><i class="fas fa-shopping-bag"></i> My Orders</h1>
                <div class="orders-stats">
                    <div class="stat-item">
                        <span class="stat-number"><?php echo $total_orders; ?></span>
                        <span class="stat-label">Total Orders</span>
                    </div>
                </div>
            </div>

            <!-- Filters -->
            <div class="orders-filters">
                <div class="filter-tabs">
                    <a href="?status=all" class="filter-tab <?php echo $status_filter === 'all' ? 'active' : ''; ?>">
                        All Orders
                    </a>
                    <a href="?status=pending" class="filter-tab <?php echo $status_filter === 'pending' ? 'active' : ''; ?>">
                        Pending
                    </a>
                    <a href="?status=payment_submitted" class="filter-tab <?php echo $status_filter === 'payment_submitted' ? 'active' : ''; ?>">
                        Payment Submitted
                    </a>
                    <a href="?status=completed" class="filter-tab <?php echo $status_filter === 'completed' ? 'active' : ''; ?>">
                        Completed
                    </a>
                    <a href="?status=cancelled" class="filter-tab <?php echo $status_filter === 'cancelled' ? 'active' : ''; ?>">
                        Cancelled
                    </a>
                </div>
            </div>

            <!-- Orders List -->
            <div class="orders-list">
                <?php if (empty($orders)): ?>
                    <div class="empty-orders">
                        <i class="fas fa-shopping-bag"></i>
                        <h3>No orders found</h3>
                        <p>You haven't placed any orders yet.</p>
                        <a href="index.php" class="btn-primary">Start Shopping</a>
                    </div>
                <?php else: ?>
                    <?php foreach ($orders as $order): ?>
                        <div class="order-card">
                            <div class="order-header">
                                <div class="order-info">
                                    <h3>Order #<?php echo sanitizeOutput($order['order_number']); ?></h3>
                                    <p class="order-date">
                                        <i class="fas fa-calendar"></i>
                                        <?php echo date('F j, Y \a\t g:i A', strtotime($order['created_at'])); ?>
                                    </p>
                                </div>
                                <div class="order-status">
                                    <span class="status-badge status-<?php echo $order['status']; ?>">
                                        <?php echo ucfirst(str_replace('_', ' ', $order['status'])); ?>
                                    </span>
                                </div>
                            </div>

                            <div class="order-details">
                                <div class="order-summary">
                                    <div class="summary-item">
                                        <i class="fas fa-images"></i>
                                        <span><?php echo $order['item_count']; ?> item(s)</span>
                                    </div>
                                    <div class="summary-item">
                                        <i class="fas fa-credit-card"></i>
                                        <span><?php echo ucfirst($order['payment_method']); ?></span>
                                    </div>
                                    <div class="summary-item">
                                        <i class="fas fa-dollar-sign"></i>
                                        <span>$<?php echo number_format($order['total_amount'], 2); ?></span>
                                    </div>
                                </div>

                                <div class="order-actions">
                                    <a href="order_details.php?id=<?php echo $order['id']; ?>" class="btn-secondary">
                                        <i class="fas fa-eye"></i> View Details
                                    </a>
                                    
                                    <?php if ($order['status'] === 'completed'): ?>
                                        <a href="download.php?order_id=<?php echo $order['id']; ?>" class="btn-primary">
                                            <i class="fas fa-download"></i> Download
                                        </a>
                                    <?php elseif ($order['status'] === 'pending'): ?>
                                        <button class="btn-warning" onclick="cancelOrder(<?php echo $order['id']; ?>)">
                                            <i class="fas fa-times"></i> Cancel
                                        </button>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <?php if ($order['status'] === 'payment_submitted'): ?>
                                <div class="order-note">
                                    <i class="fas fa-info-circle"></i>
                                    <span>Your payment is being reviewed. You will be notified once approved.</span>
                                </div>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>

            <!-- Pagination -->
            <?php if ($total_pages > 1): ?>
                <div class="pagination">
                    <?php if ($page > 1): ?>
                        <a href="?status=<?php echo $status_filter; ?>&page=<?php echo $page - 1; ?>" class="page-btn">
                            <i class="fas fa-chevron-left"></i> Previous
                        </a>
                    <?php endif; ?>

                    <?php for ($i = max(1, $page - 2); $i <= min($total_pages, $page + 2); $i++): ?>
                        <a href="?status=<?php echo $status_filter; ?>&page=<?php echo $i; ?>" 
                           class="page-btn <?php echo $i === $page ? 'active' : ''; ?>">
                            <?php echo $i; ?>
                        </a>
                    <?php endfor; ?>

                    <?php if ($page < $total_pages): ?>
                        <a href="?status=<?php echo $status_filter; ?>&page=<?php echo $page + 1; ?>" class="page-btn">
                            Next <i class="fas fa-chevron-right"></i>
                        </a>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <?php include 'includes/footer.php'; ?>

    <script src="assets/js/orders.js"></script>
</body>
</html>
