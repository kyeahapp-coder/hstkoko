<?php
require_once 'includes/functions.php';

if (!isLoggedIn()) {
    redirect('login.php');
}

$order_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if (!$order_id) {
    redirect('orders.php');
}

$database = new Database();
$db = $database->getConnection();

// Get order details
$order_query = "SELECT * FROM orders WHERE id = ? AND user_id = ?";
$order_stmt = $db->prepare($order_query);
$order_stmt->execute([$order_id, $_SESSION['user_id']]);
$order = $order_stmt->fetch(PDO::FETCH_ASSOC);

if (!$order) {
    redirect('orders.php');
}

// Get order items (images)
$items_query = "SELECT oi.*, i.title, i.watermark_path 
                FROM order_items oi 
                JOIN images i ON oi.image_id = i.id 
                WHERE oi.order_id = ?";
$items_stmt = $db->prepare($items_query);
$items_stmt->execute([$order_id]);
$order_items = $items_stmt->fetchAll(PDO::FETCH_ASSOC);

// Check if it's a service order
$service_query = "SELECT so.*, s.service_name, s.service_type 
                  FROM service_orders so 
                  JOIN services s ON so.service_id = s.id 
                  WHERE so.order_id = ?";
$service_stmt = $db->prepare($service_query);
$service_stmt->execute([$order_id]);
$service_order = $service_stmt->fetch(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="my">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>အော်ဒါအသေးစိတ် - Infinity Server</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/login.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body>
    <header class="header">
        <div class="container">
            <div class="nav-brand">
                <img src="<?php echo getSetting('site_logo'); ?>" alt="Logo" class="logo">
                <h1>Infinity Server</h1>
            </div>
            <nav class="nav-menu">
                <a href="index.php">ပင်မစာမျက်နှာ</a>
                <a href="services.php">ဝန်ဆောင်မှုများ</a>
                <a href="cart.php" class="cart-link">
                    <i class="fas fa-shopping-cart"></i>
                    <span id="cart-count">0</span>
                </a>
                <a href="profile.php">ကိုယ်ရေးအချက်အလက်</a>
                <a href="orders.php">အော်ဒါများ</a>
                <a href="logout.php">ထွက်ရန်</a>
            </nav>
        </div>
    </header>

    <main class="main-content">
        <div class="container">
            <div class="order-details-container">
                <div class="order-header">
                    <h2><i class="fas fa-receipt"></i> အော်ဒါအသေးစိတ်</h2>
                    <a href="orders.php" class="btn-back">
                        <i class="fas fa-arrow-left"></i> အော်ဒါများသို့ ပြန်သွားရန်
                    </a>
                </div>
                
                <div class="order-info-card">
                    <div class="order-summary">
                        <h3>အော်ဒါ: <?php echo $order['order_uid']; ?></h3>
                        <div class="order-meta">
                            <div class="meta-item">
                                <span class="label">ရက်စွဲ:</span>
                                <span class="value"><?php echo date('Y-m-d H:i', strtotime($order['created_at'])); ?></span>
                            </div>
                            <div class="meta-item">
                                <span class="label">အခြေအနေ:</span>
                                <span class="status-badge <?php echo $order['admin_approved'] ? 'approved' : ($order['payment_status'] === 'pending' ? 'pending' : 'paid'); ?>">
                                    <?php 
                                    if ($order['admin_approved']) {
                                        echo 'အတည်ပြုပြီး';
                                    } elseif ($order['payment_status'] === 'pending') {
                                        echo 'စောင့်ဆိုင်းနေသည်';
                                    } else {
                                        echo 'ငွေပေးချေပြီး';
                                    }
                                    ?>
                                </span>
                            </div>
                            <div class="meta-item">
                                <span class="label">ငွေပေးချေမှုနည်းလမ်း:</span>
                                <span class="value"><?php echo ucfirst($order['payment_method']); ?></span>
                            </div>
                            <div class="meta-item">
                                <span class="label">စုစုပေါင်း:</span>
                                <span class="value total-amount">
                                    <?php 
                                    if ($order['currency'] === 'MMK') {
                                        echo formatCurrency($order['total_mmk'], 'MMK');
                                    } else {
                                        echo formatCurrency($order['total_thb'], 'THB');
                                    }
                                    ?>
                                </span>
                            </div>
                        </div>
                    </div>
                </div>
                
                <?php if ($service_order): ?>
                    <!-- Service Order Details -->
                    <div class="service-details-card">
                        <h3><i class="fas fa-concierge-bell"></i> ဝန်ဆောင်မှုအသေးစိတ်</h3>
                        <div class="service-info">
                            <div class="service-item">
                                <span class="label">ဝန်ဆောင်မှု:</span>
                                <span class="value"><?php echo htmlspecialchars($service_order['service_name']); ?></span>
                            </div>
                            <div class="service-item">
                                <span class="label">ဖုန်းနံပါတ်/Game ID:</span>
                                <span class="value"><?php echo htmlspecialchars($service_order['phone_number']); ?></span>
                            </div>
                            <?php if ($service_order['notes']): ?>
                                <div class="service-item">
                                    <span class="label">မှတ်ချက်:</span>
                                    <span class="value"><?php echo htmlspecialchars($service_order['notes']); ?></span>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endif; ?>
                
                <?php if (!empty($order_items)): ?>
                    <!-- Image Order Details -->
                    <div class="items-details-card">
                        <h3><i class="fas fa-images"></i> ဓာတ်ပုံများ</h3>
                        <div class="order-items-grid">
                            <?php foreach ($order_items as $item): ?>
                                <div class="order-item-card">
                                    <img src="<?php echo $item['watermark_path']; ?>" alt="<?php echo htmlspecialchars($item['title']); ?>">
                                    <div class="item-info">
                                        <h4><?php echo htmlspecialchars($item['title']); ?></h4>
                                        <p class="item-price">
                                            <?php echo formatCurrency($item['price'], $item['currency']); ?>
                                        </p>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                <?php endif; ?>
                
                <?php if ($order['admin_approved']): ?>
                    <div class="download-section">
                        <h3><i class="fas fa-download"></i> ဒေါင်းလုဒ်</h3>
                        <p>သင့်အော်ဒါကို အတည်ပြုပြီးပါပြီ။ ယခု ဒေါင်းလုဒ်လုပ်နိုင်ပါပြီ။</p>
                        <a href="download.php?order=<?php echo $order['id']; ?>" class="btn-primary download-btn">
                            <i class="fas fa-download"></i> ဒေါင်းလုဒ်လုပ်ရန်
                        </a>
                    </div>
                <?php elseif ($order['payment_status'] === 'pending'): ?>
                    <div class="payment-section">
                        <h3><i class="fas fa-credit-card"></i> ငွေပေးချေမှု</h3>
                        <p>ဤအော်ဒါအတွက် ငွေမပေးချေရသေးပါ။</p>
                        <button class="btn-primary" onclick="showPaymentOptions()">
                            <i class="fas fa-credit-card"></i> ငွေပေးချေရန်
                        </button>
                    </div>
                <?php else: ?>
                    <div class="waiting-section">
                        <h3><i class="fas fa-clock"></i> စောင့်ဆိုင်းနေသည်</h3>
                        <p>သင့်ငွေပေးချေမှုကို Admin မှ စစ်ဆေးနေပါသည်။ ခဏစောင့်ပါ။</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </main>

    <footer class="footer">
        <div class="container">
            <p>&copy; 2024 Infinity Server. All rights reserved.</p>
        </div>
    </footer>

    <script src="assets/js/main.js"></script>
</body>
</html>
