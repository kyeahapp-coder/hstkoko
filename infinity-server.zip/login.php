<?php
require_once 'includes/functions.php';

if (isLoggedIn()) {
    redirect('index.php');
}

$error = '';
$admin_login = isset($_GET['admin']);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username']);
    $password = $_POST['password'];
    
    if (empty($username) || empty($password)) {
        $error = 'အသုံးပြုသူအမည်နှင့် စကားဝှက် ဖြည့်စွက်ပါ';
    } else {
        $database = new Database();
        $db = $database->getConnection();
        
        if ($admin_login) {
            // Admin login
            $query = "SELECT * FROM admins WHERE username = ?";
            $stmt = $db->prepare($query);
            $stmt->execute([$username]);
            $admin = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($admin && password_verify($password, $admin['password'])) {
                $_SESSION['admin_id'] = $admin['id'];
                $_SESSION['admin_username'] = $admin['username'];
                redirect('admin/index.php');
            } else {
                $error = 'အသုံးပြုသူအမည် သို့မဟုတ် စကားဝှက် မှားယွင်းနေပါသည်';
            }
        } else {
            // User login
            $query = "SELECT * FROM users WHERE username = ? OR email = ?";
            $stmt = $db->prepare($query);
            $stmt->execute([$username, $username]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($user && password_verify($password, $user['password'])) {
                if ($user['is_banned']) {
                    $error = 'သင့်အကောင့်ကို ပိတ်ပင်ထားပါသည်';
                } else {
                    $_SESSION['user_id'] = $user['id'];
                    $_SESSION['username'] = $user['username'];
                    redirect('index.php');
                }
            } else {
                $error = 'အသုံးပြုသူအမည် သို့မဟုတ် စကားဝှက် မှားယွင်းနေပါသည်';
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="my">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $admin_login ? 'Admin Login' : 'ဝင်ရန်'; ?> - Infinity Server</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body>
    <div class="login-container">
        <div class="form-container">
            <div class="login-header">
                <img src="<?php echo getSetting('site_logo'); ?>" alt="Logo" class="logo">
                <h2><?php echo $admin_login ? 'Admin Panel' : 'အကောင့်ဝင်ရန်'; ?></h2>
            </div>
            
            <?php if ($error): ?>
                <div class="alert alert-error">
                    <i class="fas fa-exclamation-circle"></i>
                    <?php echo $error; ?>
                </div>
            <?php endif; ?>
            
            <form method="POST" class="login-form">
                <div class="form-group">
                    <label for="username">
                        <i class="fas fa-user"></i>
                        <?php echo $admin_login ? 'Admin Username' : 'အသုံးပြုသူအမည် သို့မဟုတ် အီးမေးလ်'; ?>
                    </label>
                    <input type="text" id="username" name="username" class="form-control" required>
                </div>
                
                <div class="form-group">
                    <label for="password">
                        <i class="fas fa-lock"></i>
                        စကားဝှက်
                    </label>
                    <input type="password" id="password" name="password" class="form-control" required>
                </div>
                
                <button type="submit" class="btn-primary login-btn">
                    <i class="fas fa-sign-in-alt"></i>
                    <?php echo $admin_login ? 'Admin Login' : 'ဝင်ရန်'; ?>
                </button>
            </form>
            
            <?php if (!$admin_login): ?>
                <div class="login-footer">
                    <p>အကောင့်မရှိသေးဘူးလား? <a href="register.php">စာရင်းသွင်းရန်</a></p>
                    <p><a href="forgot_password.php">စကားဝှက်မေ့နေပါသလား?</a></p>
                </div>
            <?php else: ?>
                <div class="login-footer">
                    <p><a href="login.php">← အသုံးပြုသူ Login သို့ပြန်သွားရန်</a></p>
                </div>
            <?php endif; ?>
        </div>
    </div>
    
    <script src="assets/js/main.js"></script>
</body>
</html>
