<?php
require_once 'includes/functions.php';

if (!isLoggedIn()) {
    redirect('login.php');
}

$order_id = isset($_GET['order']) ? (int)$_GET['order'] : 0;

if (!$order_id) {
    redirect('orders.php');
}

$database = new Database();
$db = $database->getConnection();

// Verify order belongs to user and is approved
$order_query = "SELECT * FROM orders WHERE id = ? AND user_id = ? AND admin_approved = 1";
$order_stmt = $db->prepare($order_query);
$order_stmt->execute([$order_id, $_SESSION['user_id']]);
$order = $order_stmt->fetch(PDO::FETCH_ASSOC);

if (!$order) {
    redirect('orders.php');
}

// Get downloadable images
$images_query = "SELECT i.* FROM order_items oi 
                 JOIN images i ON oi.image_id = i.id 
                 WHERE oi.order_id = ?";
$images_stmt = $db->prepare($images_query);
$images_stmt->execute([$order_id]);
$images = $images_stmt->fetchAll(PDO::FETCH_ASSOC);

// Handle single image download
if (isset($_GET['image_id'])) {
    $image_id = (int)$_GET['image_id'];
    
    // Verify image is in this order
    $verify_query = "SELECT i.* FROM order_items oi 
                     JOIN images i ON oi.image_id = i.id 
                     WHERE oi.order_id = ? AND i.id = ?";
    $verify_stmt = $db->prepare($verify_query);
    $verify_stmt->execute([$order_id, $image_id]);
    $image = $verify_stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($image && file_exists($image['original_path'])) {
        // Update download count
        $update_query = "UPDATE images SET downloads = downloads + 1 WHERE id = ?";
        $update_stmt = $db->prepare($update_query);
        $update_stmt->execute([$image_id]);
        
        // Force download
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename="' . basename($image['original_path']) . '"');
        header('Content-Length: ' . filesize($image['original_path']));
        readfile($image['original_path']);
        exit();
    }
}

// Handle ZIP download
if (isset($_GET['download_all'])) {
    $zip = new ZipArchive();
    $zip_filename = 'order_' . $order['order_uid'] . '_images.zip';
    $zip_path = sys_get_temp_dir() . '/' . $zip_filename;
    
    if ($zip->open($zip_path, ZipArchive::CREATE) === TRUE) {
        foreach ($images as $image) {
            if (file_exists($image['original_path'])) {
                $zip->addFile($image['original_path'], basename($image['original_path']));
            }
        }
        $zip->close();
        
        if (file_exists($zip_path)) {
            // Update download counts
            foreach ($images as $image) {
                $update_query = "UPDATE images SET downloads = downloads + 1 WHERE id = ?";
                $update_stmt = $db->prepare($update_query);
                $update_stmt->execute([$image['id']]);
            }
            
            header('Content-Type: application/zip');
            header('Content-Disposition: attachment; filename="' . $zip_filename . '"');
            header('Content-Length: ' . filesize($zip_path));
            readfile($zip_path);
            unlink($zip_path); // Delete temp file
            exit();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="my">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ဒေါင်းလုဒ် - Infinity Server</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/login.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body>
    <header class="header">
        <div class="container">
            <div class="nav-brand">
                <img src="<?php echo getSetting('site_logo'); ?>" alt="Logo" class="logo">
                <h1>Infinity Server</h1>
            </div>
            <nav class="nav-menu">
                <a href="index.php">ပင်မစာမျက်နှာ</a>
                <a href="services.php">ဝန်ဆောင်မှုများ</a>
                <a href="cart.php" class="cart-link">
                    <i class="fas fa-shopping-cart"></i>
                    <span id="cart-count">0</span>
                </a>
                <a href="profile.php">ကိုယ်ရေးအချက်အလက်</a>
                <a href="orders.php">အော်ဒါများ</a>
                <a href="logout.php">ထွက်ရန်</a>
            </nav>
        </div>
    </header>

    <main class="main-content">
        <div class="container">
            <div class="download-container">
                <div class="download-header">
                    <h2><i class="fas fa-download"></i> ဒေါင်းလုဒ်</h2>
                    <p>အော်ဒါ: <?php echo $order['order_uid']; ?></p>
                </div>
                
                <?php if (!empty($images)): ?>
                    <div class="download-actions">
                        <a href="?order=<?php echo $order_id; ?>&download_all=1" class="btn-primary download-all">
                            <i class="fas fa-download"></i> အားလုံး ZIP ဖိုင်အဖြစ် ဒေါင်းလုဒ်လုပ်ရန်
                        </a>
                    </div>
                    
                    <div class="download-grid">
                        <?php foreach ($images as $image): ?>
                            <div class="download-item">
                                <div class="download-preview">
                                    <img src="<?php echo $image['watermark_path']; ?>" alt="<?php echo htmlspecialchars($image['title']); ?>">
                                </div>
                                <div class="download-info">
                                    <h4><?php echo htmlspecialchars($image['title']); ?></h4>
                                    <p><?php echo htmlspecialchars($image['description']); ?></p>
                                    <a href="?order=<?php echo $order_id; ?>&image_id=<?php echo $image['id']; ?>" class="btn-download">
                                        <i class="fas fa-download"></i> ဒေါင်းလုဒ်
                                    </a>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <div class="no-downloads">
                        <i class="fas fa-exclamation-circle"></i>
                        <h3>ဒေါင်းလုဒ်လုပ်နိုင်သော ဖိုင်များ မရှိပါ</h3>
                        <p>ဤအော်ဒါတွင် ဒေါင်းလုဒ်လုပ်နိုင်သော ဓာတ်ပုံများ မရှိပါ။</p>
                    </div>
                <?php endif; ?>
                
                <div class="download-footer">
                    <a href="orders.php" class="btn-back">
                        <i class="fas fa-arrow-left"></i> အော်ဒါများသို့ ပြန်သွားရန်
                    </a>
                </div>
            </div>
        </div>
    </main>

    <footer class="footer">
        <div class="container">
            <p>&copy; 2024 Infinity Server. All rights reserved.</p>
        </div>
    </footer>

    <script src="assets/js/main.js"></script>
</body>
</html>
